// Lostly front-end behaviour. Plain JavaScript on top of Bootstrap 5's bundle
// (navbar collapse, dropdown, modal, toasts and collapse come from Bootstrap).

document.addEventListener("DOMContentLoaded", function () {

    var hasBootstrap = typeof bootstrap !== "undefined";

    // ---- light / dark theme (Bootstrap's data-bs-theme) ----------------
    document.querySelectorAll(".js-theme-toggle").forEach(function (button) {
        button.addEventListener("click", function () {
            var root = document.documentElement;
            var next = root.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
            root.setAttribute("data-bs-theme", next);
            try { localStorage.setItem("lostly-theme", next); } catch (err) {}
        });
    });

    // ---- flash messages: Bootstrap toasts that hide themselves ----------
    if (hasBootstrap) {
        document.querySelectorAll(".lostly-toast").forEach(function (el) {
            bootstrap.Toast.getOrCreateInstance(el).show();
        });
    }

    // ---- "are you sure?" on destructive forms (Bootstrap modal) --------
    var modalEl = document.getElementById("confirmModal");
    var pendingForm = null;

    if (hasBootstrap && modalEl) {
        var modal = bootstrap.Modal.getOrCreateInstance(modalEl);

        modalEl.querySelector(".js-confirm-yes").addEventListener("click", function () {
            if (pendingForm) {
                pendingForm.submit();
            }
        });

        modalEl.addEventListener("hidden.bs.modal", function () {
            pendingForm = null;
        });
    }

    document.querySelectorAll("form.js-confirm").forEach(function (form) {
        form.addEventListener("submit", function (e) {
            var message = form.getAttribute("data-confirm-message") || "Are you sure?";

            if (hasBootstrap && modalEl) {
                e.preventDefault();
                pendingForm = form;
                modalEl.querySelector(".js-confirm-text").textContent = message;
                modal.show();
            } else if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // ---- form validation ----------------------------------------------
    // Fields describe their own rules with data attributes:
    //   data-required="message"
    //   data-minlength="6" data-minlength-message="message"
    //   data-match="other field name" data-match-message="message"
    // The first failing rule is shown and stops the submit. The same rules
    // are always re-checked in PHP, so this is only for a faster response.
    document.querySelectorAll("form.js-validate").forEach(function (form) {
        form.addEventListener("submit", function (e) {
            var old = form.querySelector(".js-form-message");
            if (old) { old.remove(); }

            var error = "";
            var badField = null;
            var fields = form.querySelectorAll("input, select, textarea");

            for (var i = 0; i < fields.length && !error; i++) {
                var field = fields[i];
                var value = field.type === "password" ? field.value : field.value.trim();
                var min = parseInt(field.getAttribute("data-minlength"), 10);
                var matchName = field.getAttribute("data-match");

                if (field.hasAttribute("data-required") && value === "") {
                    error = field.getAttribute("data-required");
                } else if (min && value !== "" && value.length < min) {
                    error = field.getAttribute("data-minlength-message") || "Too short";
                } else if (matchName && form.elements[matchName] && form.elements[matchName].value !== field.value) {
                    error = field.getAttribute("data-match-message") || "Fields do not match";
                }

                if (error) { badField = field; }
            }

            if (error) {
                e.preventDefault();

                var box = document.createElement("div");
                box.className = "alert alert-lost form-message js-form-message mt-3";
                box.setAttribute("role", "alert");
                box.textContent = error;

                var submit = form.querySelector("[type=submit]");
                var anchor = submit ? (submit.closest(".form-actions") || submit) : null;

                if (anchor && anchor.parentNode && !form.classList.contains("chat-form")) {
                    anchor.parentNode.insertBefore(box, anchor);
                } else {
                    form.appendChild(box);
                }

                badField.focus();
            }
        });
    });

    // ---- photo previews before uploading (several files) ---------------
    document.querySelectorAll(".js-photos-input").forEach(function (input) {
        input.addEventListener("change", function () {
            var box = document.getElementById(input.getAttribute("data-preview"));
            var max = parseInt(input.getAttribute("data-max"), 10) || 4;
            var files = input.files ? Array.prototype.slice.call(input.files) : [];

            if (box) { box.innerHTML = ""; }

            if (files.length > max) {
                alert("You can add up to " + max + " photos.");
                input.value = "";
                return;
            }

            for (var i = 0; i < files.length; i++) {
                if (files[i].size > 5 * 1024 * 1024) {
                    alert("Each image must be smaller than 5MB");
                    input.value = "";
                    if (box) { box.innerHTML = ""; }
                    return;
                }

                if (box) {
                    var img = document.createElement("img");
                    img.src = URL.createObjectURL(files[i]);
                    img.alt = "Photo preview " + (i + 1);
                    box.appendChild(img);
                }
            }
        });
    });

    // ---- report form: the reward field only applies to Lost reports -----
    var rewardField = document.querySelector(".js-reward-field");

    if (rewardField) {
        document.querySelectorAll('input[name="type"]').forEach(function (radio) {
            radio.addEventListener("change", function () {
                rewardField.hidden = radio.value !== "Lost" || !radio.checked;
            });
        });
    }

    // ---- district suggestions follow the chosen division ----------------
    document.querySelectorAll("datalist[data-districts]").forEach(function (list) {
        var form = list.closest("form");
        var division = form ? form.querySelector('select[name="division"]') : null;
        var districts = {};

        try { districts = JSON.parse(list.getAttribute("data-districts")) || {}; } catch (err) {}

        function fill() {
            var names = division && districts[division.value] ? districts[division.value] : [];

            // No division chosen yet: offer every district.
            if (names.length === 0) {
                Object.keys(districts).forEach(function (key) { names = names.concat(districts[key]); });
            }

            list.innerHTML = "";

            names.forEach(function (name) {
                var option = document.createElement("option");
                option.value = name;
                list.appendChild(option);
            });
        }

        fill();
        if (division) { division.addEventListener("change", fill); }
    });

    // ---- photo gallery on a report --------------------------------------
    var galleryMain = document.querySelector(".js-gallery-main");

    document.querySelectorAll(".js-gallery-thumb").forEach(function (thumb) {
        thumb.addEventListener("click", function () {
            if (!galleryMain) { return; }

            galleryMain.src = thumb.getAttribute("data-src");

            document.querySelectorAll(".js-gallery-thumb").forEach(function (other) {
                other.classList.toggle("active", other === thumb);
            });
        });
    });

    // ---- copy a report's link -------------------------------------------
    document.querySelectorAll(".js-copy-link").forEach(function (button) {
        button.addEventListener("click", function () {
            var link = button.getAttribute("data-link");
            var label = button.textContent;

            function done() {
                button.textContent = "Copied ✓";
                setTimeout(function () { button.textContent = label; }, 1800);
            }

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(link).then(done, function () { prompt("Copy this link:", link); });
            } else {
                prompt("Copy this link:", link);
            }
        });
    });

    // ---- scroll animations ---------------------------------------------
    // Cards, panels and tiles get .reveal (hidden) and then .in (animated in)
    // the first time they scroll into view. Neighbours that appear together
    // are staggered a little so they arrive one after another.
    var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    var revealTargets = document.querySelectorAll(
        ".panel, .stat-tile, .item-card, .how-step, .auth-box, .auth-side, .page-hero, .hero-board, .ticker, .empty, .section-title, .pagination, .category-tile, .reunited-card, .cta-band, .accordion, .division-chip"
    );

    function countUp(el) {
        var target = parseInt(el.getAttribute("data-count"), 10) || 0;

        if (reduceMotion || target <= 0 || el.getAttribute("data-counted")) { return; }

        el.setAttribute("data-counted", "1");

        var start = null;
        var duration = 900;

        function step(now) {
            if (start === null) { start = now; }
            var progress = Math.min(1, (now - start) / duration);
            el.textContent = Math.round(target * (1 - Math.pow(1 - progress, 3)));
            if (progress < 1) { requestAnimationFrame(step); } else { el.textContent = target; }
        }

        el.textContent = "0";
        requestAnimationFrame(step);
    }

    function show(el, delay) {
        el.style.setProperty("--delay", delay + "ms");
        el.classList.add("in");
        el.querySelectorAll(".js-count").forEach(countUp);
    }

    revealTargets.forEach(function (el) {
        // An element inside another revealed element just follows its parent.
        if (!el.parentElement.closest(".reveal")) {
            el.classList.add("reveal");
        }
    });

    var revealed = document.querySelectorAll(".reveal");

    if (reduceMotion || !("IntersectionObserver" in window)) {
        revealed.forEach(function (el) { show(el, 0); });
    } else {
        var observer = new IntersectionObserver(function (entries) {
            var order = 0;

            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    show(entry.target, Math.min(order, 8) * 80);
                    order++;
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0, rootMargin: "0px 0px -30px 0px" });

        revealed.forEach(function (el) { observer.observe(el); });
    }

    // Numbers that are not inside a revealed block still count up.
    document.querySelectorAll(".js-count").forEach(function (el) {
        if (!el.closest(".reveal")) { countUp(el); }
    });

    // ---- chat: live updates -------------------------------------------
    var chat = document.querySelector(".js-chat");

    if (chat) {
        var lastId = parseInt(chat.getAttribute("data-last"), 10) || 0;
        var url = chat.getAttribute("data-url");

        chat.scrollTop = chat.scrollHeight;

        function addBubble(message) {
            var empty = chat.querySelector(".js-chat-empty");
            if (empty) { empty.remove(); }

            var bubble = document.createElement("div");
            bubble.className = "bubble " + (message.mine ? "mine" : "theirs");

            // textContent keeps anything the other person typed as plain text.
            var p = document.createElement("p");
            p.textContent = message.body;
            p.style.whiteSpace = "pre-wrap";

            var time = document.createElement("time");
            time.textContent = message.time;

            bubble.appendChild(p);
            bubble.appendChild(time);
            chat.appendChild(bubble);
            chat.scrollTop = chat.scrollHeight;
        }

        function poll() {
            if (document.hidden) { return; }

            fetch(url + "?after=" + lastId, { credentials: "same-origin" })
                .then(function (response) { return response.ok ? response.json() : []; })
                .then(function (messages) {
                    messages.forEach(function (message) {
                        if (message.id > lastId) {
                            lastId = message.id;
                            addBubble(message);
                        }
                    });
                })
                .catch(function () {});
        }

        setInterval(poll, 4000);
    }

    // Enter sends, Shift+Enter makes a new line.
    document.querySelectorAll(".js-enter-submit").forEach(function (area) {
        area.addEventListener("keydown", function (e) {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                if (area.form.requestSubmit) { area.form.requestSubmit(); } else { area.form.submit(); }
            }
        });
    });
});
