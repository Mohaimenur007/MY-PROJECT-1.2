-- ---------------------------------------------------------------------
-- Lostly — full database (fresh install)
-- Import this file in phpMyAdmin. It creates the `lostly` database,
-- every table, and a little sample data.
--
-- Already have a `lostly` database with real data in it?
-- Import DataBase/upgrade.sql instead — it keeps your existing rows.
-- ---------------------------------------------------------------------

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+06:00";
SET NAMES utf8mb4;

CREATE DATABASE IF NOT EXISTS `lostly` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `lostly`;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS `admin_log`;
DROP TABLE IF EXISTS `settings`;
DROP TABLE IF EXISTS `contact_messages`;
DROP TABLE IF EXISTS `comments`;
DROP TABLE IF EXISTS `search_alerts`;
DROP TABLE IF EXISTS `saved_items`;
DROP TABLE IF EXISTS `item_images`;
DROP TABLE IF EXISTS `flags`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `claims`;
DROP TABLE IF EXISTS `items`;
DROP TABLE IF EXISTS `users`;
SET FOREIGN_KEY_CHECKS = 1;

-- --------------------------------------------------------
-- users
-- --------------------------------------------------------

CREATE TABLE `users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Division` varchar(50) NOT NULL,
  `District` varchar(100) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Role` enum('user','admin') NOT NULL DEFAULT 'user',
  `IsBanned` tinyint(1) NOT NULL DEFAULT 0,
  `ShowContact` tinyint(1) NOT NULL DEFAULT 1,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Demo administrator:  username  admin   password  admin123
-- Change this password from Edit Profile right after your first login.
INSERT INTO `users` (`ID`, `Username`, `Email`, `Phone`, `Division`, `District`, `Password`, `Role`) VALUES
(1, 'Didar', 'thisisshaifulislam@gmail.com', '01911031925', 'Dhaka', 'Mirpur', '123123', 'user'),
(3, 'dadsa', 'minditblablabla444@gmail.com', '191103', 'Dhaka', 'Dhaka', '$2y$10$mLInawIJpom0798OtHkSQeUoU9Qje42afzQ4BqBK4hQP6bRZa0X7a', 'user'),
(4, 'faah', 'asdasdad@gmail.com', '123123123123', 'Dhaka', 'Dhaka', '$2y$10$ncNzQ81qT1R/CEMnT/G1lejEuBUvl0evXeSRGeHBX3RJkR4wi0euS', 'user'),
(5, 'admin', 'admin@lostly.local', '01700000000', 'Dhaka', 'Dhaka', '$2y$10$wwnKgKOwuoEjDuyq4w6/vOPCAc8cbhTaPJuBhg8ZHuf5o4J5c2rVK', 'admin');

-- --------------------------------------------------------
-- items
-- --------------------------------------------------------

CREATE TABLE `items` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NOT NULL,
  `Type` enum('Lost','Found') NOT NULL,
  `ItemName` varchar(100) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `Description` text DEFAULT NULL,
  `Division` varchar(50) NOT NULL,
  `District` varchar(50) NOT NULL,
  `EventDate` date NOT NULL,
  `ImagePath` varchar(255) DEFAULT NULL,
  `Status` enum('Active','Resolved') NOT NULL DEFAULT 'Active',
  `Views` int(11) NOT NULL DEFAULT 0,
  `Reward` int(10) unsigned DEFAULT NULL,
  `ResolvedNote` varchar(500) DEFAULT NULL,
  `ResolvedAt` datetime DEFAULT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `fk_items_user` (`UserID`),
  KEY `idx_items_division` (`Division`),
  KEY `idx_items_type_status` (`Type`,`Status`),
  CONSTRAINT `fk_items_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `items` (`ID`, `UserID`, `Type`, `ItemName`, `Category`, `Description`, `Division`, `District`, `EventDate`, `ImagePath`, `Status`, `CreatedAt`) VALUES
(5, 3, 'Lost', 'Mobile', 'Electronics', 'ADFS', 'Dhaka', 'Dhaka', '2026-08-28', 'uploads/items/item_6a9194451a9007.17548928.jpg', 'Resolved', '2026-08-28 13:59:33'),
(6, 4, 'Lost', 'Tom', 'Pets', 'Dekhte bhodro', 'Dhaka', 'Dhaka', '2026-09-01', 'uploads/items/item_6a9912ac22b8e4.01675223.jpg', 'Active', '2026-08-31 18:40:29');

-- --------------------------------------------------------
-- claims  ("this is mine" / "I found it" requests on a report)
-- --------------------------------------------------------

CREATE TABLE `claims` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `ClaimantID` int(11) NOT NULL,
  `Message` text NOT NULL,
  `Status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `uq_claim_item_user` (`ItemID`,`ClaimantID`),
  KEY `fk_claims_user` (`ClaimantID`),
  CONSTRAINT `fk_claims_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_claims_user` FOREIGN KEY (`ClaimantID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- messages  (private chat between two users about one item)
-- --------------------------------------------------------

CREATE TABLE `messages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `SenderID` int(11) NOT NULL,
  `ReceiverID` int(11) NOT NULL,
  `Body` text NOT NULL,
  `IsRead` tinyint(1) NOT NULL DEFAULT 0,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `idx_messages_receiver` (`ReceiverID`,`IsRead`),
  KEY `idx_messages_thread` (`ItemID`,`SenderID`,`ReceiverID`),
  KEY `fk_messages_sender` (`SenderID`),
  CONSTRAINT `fk_messages_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_messages_sender` FOREIGN KEY (`SenderID`) REFERENCES `users` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_messages_receiver` FOREIGN KEY (`ReceiverID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- notifications
-- --------------------------------------------------------

CREATE TABLE `notifications` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NOT NULL,
  `Type` varchar(30) NOT NULL,
  `Body` varchar(255) NOT NULL,
  `Link` varchar(255) NOT NULL,
  `IsRead` tinyint(1) NOT NULL DEFAULT 0,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `idx_notifications_user` (`UserID`,`IsRead`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- flags  (users reporting a suspicious post to the admins)
-- --------------------------------------------------------

CREATE TABLE `flags` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Reason` varchar(255) NOT NULL,
  `Status` enum('Open','Dismissed') NOT NULL DEFAULT 'Open',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `uq_flag_item_user` (`ItemID`,`UserID`),
  KEY `fk_flags_user` (`UserID`),
  CONSTRAINT `fk_flags_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_flags_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- item_images  (extra photos; the cover photo stays in items.ImagePath)
-- --------------------------------------------------------

CREATE TABLE `item_images` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `Path` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_item_images_item` (`ItemID`),
  CONSTRAINT `fk_item_images_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- saved_items  (a member's watchlist)
-- --------------------------------------------------------

CREATE TABLE `saved_items` (
  `UserID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`UserID`,`ItemID`),
  KEY `fk_saved_item` (`ItemID`),
  CONSTRAINT `fk_saved_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_saved_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- search_alerts  (saved searches: "tell me when a report like this appears")
-- --------------------------------------------------------

CREATE TABLE `search_alerts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NOT NULL,
  `Type` varchar(10) NOT NULL DEFAULT '',
  `Category` varchar(50) NOT NULL DEFAULT '',
  `Division` varchar(50) NOT NULL DEFAULT '',
  `Keyword` varchar(100) NOT NULL DEFAULT '',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `fk_search_alerts_user` (`UserID`),
  CONSTRAINT `fk_search_alerts_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- comments  (public sightings and tips on a report)
-- --------------------------------------------------------

CREATE TABLE `comments` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Body` text NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `fk_comments_item` (`ItemID`),
  KEY `fk_comments_user` (`UserID`),
  CONSTRAINT `fk_comments_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_comments_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- contact_messages  (the public Contact form, read by admins)
-- --------------------------------------------------------

CREATE TABLE `contact_messages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Subject` varchar(150) NOT NULL,
  `Body` text NOT NULL,
  `IsRead` tinyint(1) NOT NULL DEFAULT 0,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- settings  (site-wide values such as the announcement banner)
-- --------------------------------------------------------

CREATE TABLE `settings` (
  `Name` varchar(50) NOT NULL,
  `Value` text NOT NULL,
  PRIMARY KEY (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------
-- admin_log  (who did what in the admin panel)
-- --------------------------------------------------------

CREATE TABLE `admin_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) NOT NULL,
  `Action` varchar(60) NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `fk_admin_log_user` (`AdminID`),
  CONSTRAINT `fk_admin_log_user` FOREIGN KEY (`AdminID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
