-- ---------------------------------------------------------------------
-- Lostly — upgrade an EXISTING `lostly` database to the newest version.
-- Keeps all of your current users and items. Safe to run more than once,
-- from any earlier version of Lostly.
-- (phpMyAdmin: select the `lostly` database, open Import, choose this file.)
-- ---------------------------------------------------------------------

SET NAMES utf8mb4;

ALTER TABLE `users`
  ADD COLUMN IF NOT EXISTS `Role` enum('user','admin') NOT NULL DEFAULT 'user',
  ADD COLUMN IF NOT EXISTS `IsBanned` tinyint(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `ShowContact` tinyint(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp();

ALTER TABLE `items`
  ADD COLUMN IF NOT EXISTS `Views` int(11) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `Reward` int(10) unsigned DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `ResolvedNote` varchar(500) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `ResolvedAt` datetime DEFAULT NULL;

CREATE TABLE IF NOT EXISTS `claims` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `ClaimantID` int(11) NOT NULL,
  `Message` text NOT NULL,
  `Status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `uq_claim_item_user` (`ItemID`,`ClaimantID`),
  KEY `fk_claims_user` (`ClaimantID`),
  CONSTRAINT `fk_claims_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_claims_user` FOREIGN KEY (`ClaimantID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `messages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `SenderID` int(11) NOT NULL,
  `ReceiverID` int(11) NOT NULL,
  `Body` text NOT NULL,
  `IsRead` tinyint(1) NOT NULL DEFAULT 0,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `idx_messages_receiver` (`ReceiverID`,`IsRead`),
  KEY `idx_messages_thread` (`ItemID`,`SenderID`,`ReceiverID`),
  KEY `fk_messages_sender` (`SenderID`),
  CONSTRAINT `fk_messages_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_messages_sender` FOREIGN KEY (`SenderID`) REFERENCES `users` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_messages_receiver` FOREIGN KEY (`ReceiverID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `notifications` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NOT NULL,
  `Type` varchar(30) NOT NULL,
  `Body` varchar(255) NOT NULL,
  `Link` varchar(255) NOT NULL,
  `IsRead` tinyint(1) NOT NULL DEFAULT 0,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `idx_notifications_user` (`UserID`,`IsRead`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `flags` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Reason` varchar(255) NOT NULL,
  `Status` enum('Open','Dismissed') NOT NULL DEFAULT 'Open',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  UNIQUE KEY `uq_flag_item_user` (`ItemID`,`UserID`),
  KEY `fk_flags_user` (`UserID`),
  CONSTRAINT `fk_flags_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_flags_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `item_images` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `Path` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_item_images_item` (`ItemID`),
  CONSTRAINT `fk_item_images_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `saved_items` (
  `UserID` int(11) NOT NULL,
  `ItemID` int(11) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`UserID`,`ItemID`),
  KEY `fk_saved_item` (`ItemID`),
  CONSTRAINT `fk_saved_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_saved_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `search_alerts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `UserID` int(11) NOT NULL,
  `Type` varchar(10) NOT NULL DEFAULT '',
  `Category` varchar(50) NOT NULL DEFAULT '',
  `Division` varchar(50) NOT NULL DEFAULT '',
  `Keyword` varchar(100) NOT NULL DEFAULT '',
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `fk_search_alerts_user` (`UserID`),
  CONSTRAINT `fk_search_alerts_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `comments` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ItemID` int(11) NOT NULL,
  `UserID` int(11) NOT NULL,
  `Body` text NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `fk_comments_item` (`ItemID`),
  KEY `fk_comments_user` (`UserID`),
  CONSTRAINT `fk_comments_item` FOREIGN KEY (`ItemID`) REFERENCES `items` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `fk_comments_user` FOREIGN KEY (`UserID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `contact_messages` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Subject` varchar(150) NOT NULL,
  `Body` text NOT NULL,
  `IsRead` tinyint(1) NOT NULL DEFAULT 0,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `settings` (
  `Name` varchar(50) NOT NULL,
  `Value` text NOT NULL,
  PRIMARY KEY (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS `admin_log` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `AdminID` int(11) NOT NULL,
  `Action` varchar(60) NOT NULL,
  `Detail` varchar(255) NOT NULL,
  `CreatedAt` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`ID`),
  KEY `fk_admin_log_user` (`AdminID`),
  CONSTRAINT `fk_admin_log_user` FOREIGN KEY (`AdminID`) REFERENCES `users` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Demo administrator:  username  admin   password  admin123
-- (skipped automatically if that username or email is already taken)
INSERT INTO `users` (`Username`, `Email`, `Phone`, `Division`, `District`, `Password`, `Role`)
SELECT 'admin', 'admin@lostly.local', '01700000000', 'Dhaka', 'Dhaka', '$2y$10$wwnKgKOwuoEjDuyq4w6/vOPCAc8cbhTaPJuBhg8ZHuf5o4J5c2rVK', 'admin'
FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `users` WHERE `Username` = 'admin' OR `Email` = 'admin@lostly.local');

-- To make one of your own accounts an administrator instead, run:
--   UPDATE `users` SET `Role` = 'admin' WHERE `Username` = 'your-username';
