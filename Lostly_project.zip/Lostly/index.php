<?php

// ---------------------------------------------------------------------
// Lostly front controller.
// Every request enters here; the Router decides which controller runs.
//   /Lostly/index.php/items/7   ->   ItemController::show(7)
// ---------------------------------------------------------------------

define("ROOT", __DIR__);
define("APP", ROOT . "/app");

require(APP . "/bootstrap.php");

$router = new Router();
require(APP . "/routes.php");

$router->dispatch($_SERVER["REQUEST_METHOD"], Request::path());
