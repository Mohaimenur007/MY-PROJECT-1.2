<?php

class ClaimController extends Controller
{
    // Send a claim on someone else's report.
    public function store($item_id)
    {
        $this->requireLogin();

        $item = Item::find($item_id);

        if(!$item || $item["IsBanned"])
        {
            flash("That report is no longer available.", "error");
            redirect("items");
        }

        $me = Auth::user();
        $message = Request::post("claim_message");

        if($item["UserID"] == $me["ID"])
        {
            flash("You can't claim your own report.", "error");
        }
        else if($item["Status"] != "Active")
        {
            flash("This report is already resolved.", "error");
        }
        else if(Claim::byUserOnItem($item_id, $me["ID"]))
        {
            flash("You have already sent a claim for this report.", "error");
        }
        else if(strlen($message) < 10)
        {
            flash("Please describe your proof in at least 10 characters.", "error");
        }
        else if(strlen($message) > 1000)
        {
            flash("Please keep your claim under 1000 characters.", "error");
        }
        else
        {
            Claim::create($item_id, $me["ID"], $message);

            Notification::send($item["UserID"], "claim",
                $me["Username"] . " sent a claim on your report \"" . $item["ItemName"] . "\"",
                "items/" . $item_id);

            flash("Claim sent. The reporter has been notified.");
        }

        redirect("items/" . $item_id);
    }

    // The report's owner approves or rejects a claim.
    public function decide($claim_id)
    {
        $this->requireLogin();

        $claim = Claim::find($claim_id);
        $item = $claim ? Item::findOwned($claim["ItemID"], Auth::id()) : null;

        // Only the owner of the report may decide, and only while the claim is waiting.
        if(!$item || $claim["Status"] != "Pending")
        {
            flash("That claim can't be changed.", "error");
            redirect("dashboard");
        }

        $link = "items/" . $item["ID"];
        $decision = Request::post("decision") == "approve" ? "Approved" : "Rejected";

        Claim::setStatus($claim_id, $decision);

        Notification::send($claim["ClaimantID"], "claim",
            "Your claim on \"" . $item["ItemName"] . "\" was " . strtolower($decision), $link);

        if($decision == "Approved")
        {
            // One approved claim settles the report: resolve it and close the others.
            Item::resolve($item["ID"]);

            foreach(Claim::pendingForItem($item["ID"]) as $other)
            {
                Notification::send($other["ClaimantID"], "claim",
                    "Your claim on \"" . $item["ItemName"] . "\" was rejected", $link);
            }

            Claim::rejectPending($item["ID"]);

            flash("Claim approved and report marked as resolved.");
        }
        else
        {
            flash("Claim rejected.");
        }

        redirect($link);
    }
}
