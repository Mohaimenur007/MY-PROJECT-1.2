<?php

// Public "sightings & tips" on a report.
class CommentController extends Controller
{
    public function store($item_id)
    {
        $this->requireLogin();

        $item = Item::find($item_id);

        if(!$item || $item["IsBanned"])
        {
            flash("That report is no longer available.", "error");
            redirect("items");
        }

        $me = Auth::user();
        $body = Request::post("body");

        if(strlen($body) < 3)
        {
            flash("Write a little more before posting.", "error");
        }
        else if(strlen($body) > 500)
        {
            flash("Tips can be up to 500 characters.", "error");
        }
        else
        {
            Comment::create($item_id, $me["ID"], $body);

            if($item["UserID"] != $me["ID"])
            {
                Notification::send($item["UserID"], "tip",
                    $me["Username"] . " left a tip on your report \"" . $item["ItemName"] . "\"",
                    "items/" . $item_id);
            }

            flash("Tip posted. Thank you for helping.");
        }

        redirect("items/" . $item_id);
    }

    // The writer, the report's owner or an admin can remove a tip.
    public function destroy($id)
    {
        $this->requireLogin();

        $comment = Comment::find($id);

        if(!$comment)
        {
            redirect("items");
        }

        $item = Item::find($comment["ItemID"]);
        $allowed = $comment["UserID"] == Auth::id() || ($item && $item["UserID"] == Auth::id()) || Auth::isAdmin();

        if($allowed)
        {
            Comment::delete($id);

            if(Auth::isAdmin() && $comment["UserID"] != Auth::id())
            {
                AdminLog::add("Removed tip", "On report #" . $comment["ItemID"]);
            }

            flash("Tip removed.");
        }
        else
        {
            flash("You can't remove that tip.", "error");
        }

        redirect("items/" . $comment["ItemID"]);
    }
}
