<?php

class DashboardController extends Controller
{
    public function index()
    {
        $this->requireLogin();

        $user_id = Auth::id();
        $my_items = Item::byUser($user_id);

        $stats = ["total" => count($my_items), "active" => 0, "resolved" => 0, "views" => 0];
        $match_groups = [];
        $checked = 0;

        foreach($my_items as $item)
        {
            $stats["views"] += (int)$item["Views"];
            $stats[$item["Status"] == "Active" ? "active" : "resolved"]++;

            // Smart matches for my (first few) active reports.
            if($item["Status"] == "Active" && $checked < 6)
            {
                $checked++;
                $found = Item::matches($item, 3);

                if(count($found) > 0)
                {
                    $match_groups[] = ["item" => $item, "matches" => $found];
                }
            }
        }

        $this->view("dashboard/index", [
            "page_title" => "Dashboard",
            "page" => "dashboard",
            "me" => Auth::user(),
            "my_items" => $my_items,
            "stats" => $stats,
            "match_groups" => $match_groups,
            "incoming_claims" => Claim::incomingFor($user_id),
            "my_claims" => Claim::sentBy($user_id)
        ]);
    }
}
