<?php

class AuthController extends Controller
{
    public function loginForm($username = "", $error = "")
    {
        $this->requireGuest();

        $this->view("auth/login", [
            "page_title" => "Login",
            "page" => "login",
            "username" => $username,
            "error" => $error
        ]);
    }

    public function login()
    {
        $this->requireGuest();

        $username = Request::post("username");
        $password = Request::raw("password");
        $error = "";

        // Slow down password guessing: 5 wrong tries locks this browser for a minute.
        $locked_until = isset($_SESSION["login_locked_until"]) ? (int)$_SESSION["login_locked_until"] : 0;

        if(time() < $locked_until)
        {
            $error = "Too many attempts. Try again in " . ($locked_until - time()) . " seconds.";
        }
        else if($username == "")
        {
            $error = "Enter Username";
        }
        else if($password == "")
        {
            $error = "Enter Password";
        }
        else
        {
            $user = User::findByUsername($username);

            if($user && User::passwordMatches($user, $password))
            {
                if($user["IsBanned"])
                {
                    $error = "This account has been suspended by an administrator.";
                }
                else
                {
                    $intended = isset($_SESSION["intended"]) ? $_SESSION["intended"] : null;

                    Auth::login($user);
                    unset($_SESSION["intended"]);

                    flash("Welcome back, " . $user["Username"] . "!");

                    // Back to the page they were trying to open, if there was one.
                    if(is_array($intended) && is_string($intended["path"]) && is_array($intended["query"]))
                    {
                        redirect($intended["path"], $intended["query"]);
                    }

                    redirect("dashboard");
                }
            }
            else
            {
                $attempts = (isset($_SESSION["login_attempts"]) ? (int)$_SESSION["login_attempts"] : 0) + 1;
                $_SESSION["login_attempts"] = $attempts;

                if($attempts >= 5)
                {
                    $_SESSION["login_locked_until"] = time() + 60;
                    $_SESSION["login_attempts"] = 0;
                }

                $error = "Invalid Username or Password";
            }
        }

        $this->loginForm($username, $error);
    }

    public function registerForm($old = [], $error = "")
    {
        $this->requireGuest();

        $this->view("auth/register", [
            "page_title" => "Create account",
            "page" => "register",
            "old" => $old + ["username" => "", "email" => "", "phone" => "", "division" => "", "district" => ""],
            "error" => $error
        ]);
    }

    public function register()
    {
        $this->requireGuest();

        $data = [
            "username" => Request::post("username"),
            "email" => Request::post("email"),
            "phone" => Request::post("phone"),
            "division" => Request::post("division"),
            "district" => Request::post("district"),
            "password" => Request::raw("password")
        ];

        $error = ProfileController::validateDetails($data);

        if($error == "")
        {
            if($data["password"] == "")
            {
                $error = "Enter Password";
            }
            else if(strlen($data["password"]) < 6)
            {
                $error = "Password must be at least 6 characters";
            }
            else if($data["password"] != Request::raw("confirm_password"))
            {
                $error = "Passwords do not match";
            }
            else if(User::taken($data["username"], $data["email"]))
            {
                $error = "Username or email already exists";
            }
        }

        if($error == "" && User::create($data))
        {
            flash("Account created! You can now log in.");
            redirect("login");
        }

        unset($data["password"]);
        $this->registerForm($data, $error != "" ? $error : "Registration failed");
    }

    // Logging out is POST-only, so a link on another site can't do it for you.
    public function logout()
    {
        Auth::logout();
        redirect("login");
    }
}
