<?php

class ProfileController extends Controller
{
    public function edit($old = null, $error = "")
    {
        $this->requireLogin();

        $me = Auth::user();

        $this->view("profile/edit", [
            "page_title" => "Edit profile",
            "page" => "profile",
            "me" => $me,
            "old" => $old ? $old : [
                "username" => $me["Username"],
                "email" => $me["Email"],
                "phone" => $me["Phone"],
                "division" => $me["Division"],
                "district" => $me["District"],
                "show_contact" => (bool)$me["ShowContact"]
            ],
            "error" => $error
        ]);
    }

    public function update()
    {
        $this->requireLogin();

        $me = Auth::user();

        $data = [
            "username" => Request::post("username"),
            "email" => Request::post("email"),
            "phone" => Request::post("phone"),
            "division" => Request::post("division"),
            "district" => Request::post("district"),
            "show_contact" => Request::post("show_contact") == "1"
        ];

        $new_password = Request::raw("new_password");
        $error = self::validateDetails($data);

        if($error == "")
        {
            if($new_password != "" && strlen($new_password) < 6)
            {
                $error = "New password must be at least 6 characters";
            }
            else if($new_password != Request::raw("confirm_password"))
            {
                $error = "New passwords do not match";
            }
            else if($new_password != "" && !password_verify(Request::raw("current_password"), $me["Password"]))
            {
                // Changing the password needs the current one, so a borrowed session can't lock you out.
                $error = "Your current password is not correct";
            }
            else if(User::taken($data["username"], $data["email"], $me["ID"]))
            {
                $error = "Username or email already taken";
            }
        }

        if($error != "")
        {
            $this->edit($data, $error);
            return;
        }

        User::updateProfile($me["ID"], $data);

        if($new_password != "")
        {
            User::updatePassword($me["ID"], $new_password);
        }

        $_SESSION["username"] = $data["username"];

        flash("Profile updated successfully.");
        redirect("profile");
    }

    // Rules shared by registration and profile editing. Returns "" when all is fine.
    public static function validateDetails($data)
    {
        if($data["username"] == "") return "Enter Username";
        if(strlen($data["username"]) > 100) return "Username is too long";
        if($data["email"] == "") return "Enter Email";
        if(!filter_var($data["email"], FILTER_VALIDATE_EMAIL) || strlen($data["email"]) > 150) return "Enter a valid Email";
        if($data["phone"] == "") return "Enter Phone Number";
        if(!preg_match('/^[0-9+\- ]{6,20}$/', $data["phone"])) return "Enter a valid Phone Number";
        if(!in_array($data["division"], config("divisions"))) return "Select Division";
        if($data["district"] == "") return "Enter District";
        if(strlen($data["district"]) > 100) return "District is too long";

        return "";
    }
}
