<?php

class MessageController extends Controller
{
    // Inbox.
    public function index()
    {
        $this->requireLogin();

        $this->view("messages/index", [
            "page_title" => "Messages",
            "page" => "messages",
            "threads" => Message::inbox(Auth::id())
        ]);
    }

    // One conversation about $item_id with member $other_id.
    public function thread($item_id, $other_id)
    {
        list($item, $other) = $this->conversation($item_id, $other_id);

        Message::markRead($item_id, Auth::id(), $other_id);

        $this->view("messages/thread", [
            "page_title" => "Chat with " . $other["Username"],
            "page" => "messages",
            "item" => $item,
            "other" => $other,
            "messages" => Message::thread($item_id, Auth::id(), $other_id)
        ]);
    }

    public function send($item_id, $other_id)
    {
        $this->conversation($item_id, $other_id);

        $body = Request::post("body");

        if($body == "")
        {
            flash("Type a message first.", "error");
        }
        else if(strlen($body) > 2000)
        {
            flash("Messages can be up to 2000 characters.", "error");
        }
        else
        {
            Message::send($item_id, Auth::id(), $other_id, $body);
        }

        redirect("messages/" . $item_id . "/" . $other_id);
    }

    // The chat window asks for new messages every few seconds (returns JSON).
    public function poll($item_id, $other_id)
    {
        $this->conversation($item_id, $other_id);

        Message::markRead($item_id, Auth::id(), $other_id);

        $out = [];

        foreach(Message::thread($item_id, Auth::id(), $other_id, (int)Request::query("after", "0")) as $row)
        {
            $out[] = [
                "id" => (int)$row["ID"],
                "mine" => $row["SenderID"] == Auth::id(),
                "body" => $row["Body"],
                "time" => date("M j, g:i a", strtotime($row["CreatedAt"]))
            ];
        }

        $this->json($out);
    }

    // Checks the conversation is allowed and returns [item, other member].
    // A conversation is always between a report's owner and one other member.
    private function conversation($item_id, $other_id)
    {
        $this->requireLogin();

        $me = Auth::id();
        $item = Item::find($item_id);
        $other = User::find($other_id);

        $allowed = $item && $other && !$other["IsBanned"] && $other_id != $me
            && ($item["UserID"] == $other_id || $item["UserID"] == $me);

        if(!$allowed)
        {
            flash("That conversation isn't available.", "error");
            redirect("messages");
        }

        return [$item, $other];
    }
}
