<?php

class NotificationController extends Controller
{
    public function index()
    {
        $this->requireLogin();

        $list = Notification::forUser(Auth::id());

        // Opening the page marks everything read (the list above still shows what was new).
        Notification::markAllRead(Auth::id());

        $this->view("notifications/index", [
            "page_title" => "Alerts",
            "page" => "alerts",
            "list" => $list,
            "searches" => SearchAlert::forUser(Auth::id())
        ]);
    }

    // Save the current browse filters as a search to be alerted about.
    public function subscribe()
    {
        $this->requireLogin();

        $filters = [
            "type" => Request::post("type"),
            "category" => Request::post("category"),
            "division" => Request::post("division"),
            "keyword" => Request::post("keyword")
        ];

        if(!in_array($filters["type"], ["Lost", "Found"])) { $filters["type"] = ""; }
        if(!in_array($filters["category"], config("categories"))) { $filters["category"] = ""; }
        if(!in_array($filters["division"], config("divisions"))) { $filters["division"] = ""; }

        if(implode("", $filters) == "")
        {
            flash("Choose at least one filter or keyword first, then save the search.", "error");
        }
        else if(strlen($filters["keyword"]) > 100)
        {
            flash("That keyword is too long.", "error");
        }
        else if(SearchAlert::exists(Auth::id(), $filters))
        {
            flash("You already saved this search.", "error");
        }
        else if(SearchAlert::countFor(Auth::id()) >= config("max_search_alerts"))
        {
            flash("You can save up to " . config("max_search_alerts") . " searches. Remove one first.", "error");
        }
        else
        {
            SearchAlert::create(Auth::id(), $filters);
            flash("Search saved. We'll alert you when a matching report is posted.");
        }

        redirect("alerts");
    }

    public function unsubscribe($id)
    {
        $this->requireLogin();

        SearchAlert::delete($id, Auth::id());
        flash("Saved search removed.");
        redirect("alerts");
    }

    public function clear()
    {
        $this->requireLogin();

        Notification::clear(Auth::id());
        flash("Alerts cleared.");
        redirect("alerts");
    }
}
