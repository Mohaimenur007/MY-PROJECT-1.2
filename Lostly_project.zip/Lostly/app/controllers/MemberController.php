<?php

class MemberController extends Controller
{
    // A member's public profile.
    public function show($id)
    {
        $member = User::find($id);

        // Suspended accounts have no public profile (admins can still look).
        if(!$member || ($member["IsBanned"] && !Auth::isAdmin()))
        {
            Router::notFound();
        }

        $this->view("members/show", [
            "page_title" => $member["Username"],
            "page" => "member",
            "member" => $member,
            "stats" => User::stats($id),
            "items" => Item::activeByUser($id)
        ]);
    }
}
