<?php

class AdminController extends Controller
{
    const TABS = ["overview", "items", "users", "flags", "inbox", "log", "settings"];

    public function index()
    {
        $this->requireAdmin();

        $tab = Request::query("tab", "overview");

        if(!in_array($tab, self::TABS))
        {
            $tab = "overview";
        }

        $data = [
            "page_title" => "Admin",
            "page" => "admin",
            "tab" => $tab,
            "open_flags" => Flag::openCount(),
            "unread_inbox" => ContactMessage::unreadCount()
        ];

        if($tab == "overview")
        {
            $reports = Item::count();
            $resolved = Item::count("resolved");
            $lost = Item::count("lost");

            $data["totals"] = [
                "Members" => User::count(),
                "Reports" => $reports,
                "Active" => Item::count("active"),
                "Resolved" => $resolved,
                "Claims" => Claim::count(),
                "Messages" => Message::count()
            ];

            $data["lost_count"] = $lost;
            $data["found_count"] = $reports - $lost;
            $data["resolve_rate"] = $reports > 0 ? round($resolved * 100 / $reports) : 0;
            $data["by_category"] = Item::countBy("Category");
            $data["by_division"] = Item::countBy("Division");
            $data["days"] = Item::lastSevenDays();
        }
        else if($tab == "items")
        {
            $data["q"] = Request::query("q");
            $data["rows"] = Item::adminSearch($data["q"]);
        }
        else if($tab == "users")
        {
            $data["rows"] = User::allWithReportCounts();
        }
        else if($tab == "flags")
        {
            $data["rows"] = Flag::open();
        }
        else if($tab == "inbox")
        {
            $data["rows"] = ContactMessage::all();

            // Opening the inbox marks everything read (the list still shows what was new).
            ContactMessage::markAllRead();
        }
        else if($tab == "log")
        {
            $data["rows"] = AdminLog::recent();
        }
        else
        {
            $data["announcement"] = Setting::get("announcement");
        }

        $this->view("admin/index", $data);
    }

    public function deleteItem($id)
    {
        $this->requireAdmin();

        $item = Item::find($id);

        if($item)
        {
            Item::delete($item);
            AdminLog::add("Removed report", "#" . $id . " \"" . $item["ItemName"] . "\" by " . $item["Username"]);

            if($item["UserID"] != Auth::id())
            {
                Notification::send($item["UserID"], "admin",
                    "Your report \"" . $item["ItemName"] . "\" was removed by an administrator", "dashboard");
            }

            flash("Report removed.");
        }

        $tab = Request::post("tab");
        redirect("admin", ["tab" => in_array($tab, ["items", "flags"]) ? $tab : "items"]);
    }

    public function dismissFlag($id)
    {
        $this->requireAdmin();

        Flag::dismiss($id);
        AdminLog::add("Dismissed flag", "Flag #" . $id);
        flash("Flag dismissed.");
        redirect("admin", ["tab" => "flags"]);
    }

    public function deleteMessage($id)
    {
        $this->requireAdmin();

        ContactMessage::delete($id);
        flash("Message deleted.");
        redirect("admin", ["tab" => "inbox"]);
    }

    // The banner shown at the top of every page (empty = no banner).
    public function saveAnnouncement()
    {
        $this->requireAdmin();

        $text = Request::post("announcement");

        if(strlen($text) > 300)
        {
            flash("Keep the announcement under 300 characters.", "error");
        }
        else
        {
            Setting::set("announcement", $text);
            AdminLog::add($text == "" ? "Cleared announcement" : "Set announcement", $text);
            flash($text == "" ? "Announcement removed." : "Announcement published.");
        }

        redirect("admin", ["tab" => "settings"]);
    }

    // Download every report as a spreadsheet-friendly CSV file.
    public function export()
    {
        $this->requireAdmin();

        AdminLog::add("Exported reports", "CSV download");

        header("Content-Type: text/csv; charset=utf-8");
        header("Content-Disposition: attachment; filename=\"lostly-reports-" . date("Y-m-d") . ".csv\"");

        $out = fopen("php://output", "w");

        // The BOM makes Excel read Bangla and other non-English text correctly.
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ["Reference", "Type", "Status", "Item", "Category", "Division", "District", "Date", "Reward", "Reporter", "Views", "Posted"]);

        foreach(Item::all() as $row)
        {
            fputcsv($out, array_map([$this, "csvSafe"], [
                Item::code($row["ID"]), $row["Type"], $row["Status"], $row["ItemName"], $row["Category"],
                $row["Division"], $row["District"], $row["EventDate"], $row["Reward"], $row["Username"],
                $row["Views"], $row["CreatedAt"]
            ]));
        }

        fclose($out);
        exit();
    }

    // Text that starts with = + - @ would run as a formula in Excel, so neutralise it.
    private function csvSafe($value)
    {
        $value = (string)$value;
        return preg_match('/^[=+\-@\t\r]/', $value) ? "'" . $value : $value;
    }

    public function ban($id)
    {
        $user = $this->otherUser($id);

        if($user["Role"] == "admin")
        {
            flash("Remove their admin role before suspending them.", "error");
        }
        else
        {
            User::setBanned($id, true);
            AdminLog::add("Suspended member", $user["Username"]);
            flash($user["Username"] . " was suspended. Their reports are now hidden.");
        }

        redirect("admin", ["tab" => "users"]);
    }

    public function unban($id)
    {
        $user = $this->otherUser($id);

        User::setBanned($id, false);
        AdminLog::add("Unsuspended member", $user["Username"]);
        flash($user["Username"] . " can log in again.");
        redirect("admin", ["tab" => "users"]);
    }

    public function promote($id)
    {
        $user = $this->otherUser($id);

        User::setRole($id, "admin");
        AdminLog::add("Made admin", $user["Username"]);
        flash($user["Username"] . " is now an administrator.");
        redirect("admin", ["tab" => "users"]);
    }

    public function demote($id)
    {
        $user = $this->otherUser($id);

        User::setRole($id, "user");
        AdminLog::add("Removed admin", $user["Username"]);
        flash($user["Username"] . " is a regular member again.");
        redirect("admin", ["tab" => "users"]);
    }

    // The member an admin action targets. Admins can't change their own
    // account here, which stops them locking themselves out by accident.
    private function otherUser($id)
    {
        $this->requireAdmin();

        $user = User::find($id);

        if(!$user)
        {
            flash("User not found.", "error");
            redirect("admin", ["tab" => "users"]);
        }

        if($user["ID"] == Auth::id())
        {
            flash("You can't change your own account here.", "error");
            redirect("admin", ["tab" => "users"]);
        }

        return $user;
    }
}
