<?php

// Information pages, the Reunited wall and the Contact form.
class PageController extends Controller
{
    public function about()   { $this->page("about", "About Lostly", "Why Lostly exists and how it helps people in Bangladesh get their things back."); }
    public function safety()  { $this->page("safety", "Safety tips", "How to meet, hand over and claim items safely on Lostly."); }
    public function faq()     { $this->page("faq", "Questions & answers", "Answers to common questions about reporting, matching, claims and privacy on Lostly."); }
    public function terms()   { $this->page("terms", "Terms of use", "The rules for using Lostly."); }
    public function privacy() { $this->page("privacy", "Privacy", "What Lostly stores about you and who can see it."); }

    private function page($name, $title, $description)
    {
        $this->view("pages/" . $name, [
            "page_title" => $title,
            "page_description" => $description,
            "page" => $name
        ]);
    }

    // Wall of resolved reports and thank-you notes.
    public function reunited()
    {
        $this->view("pages/reunited", [
            "page_title" => "Reunited",
            "page_description" => "Items that found their way home through Lostly.",
            "page" => "reunited",
            "items" => Item::reunited(30),
            "total" => Item::publicCount(true)
        ]);
    }

    public function contactForm($old = [], $error = "")
    {
        $me = Auth::user();

        $this->view("pages/contact", [
            "page_title" => "Contact",
            "page_description" => "Send a message to the Lostly team.",
            "page" => "contact",
            "old" => $old + [
                "name" => $me ? $me["Username"] : "",
                "email" => $me ? $me["Email"] : "",
                "subject" => "",
                "message" => ""
            ],
            "error" => $error
        ]);
    }

    public function contactSend()
    {
        $data = [
            "name" => Request::post("name"),
            "email" => Request::post("email"),
            "subject" => Request::post("subject"),
            "message" => Request::post("message")
        ];

        $last = isset($_SESSION["contact_last"]) ? (int)$_SESSION["contact_last"] : 0;
        $error = "";

        // "website" is a hidden field people never see; only bots fill it in.
        if(Request::post("website") != "")
        {
            flash("Thanks! Your message was sent.");
            redirect("contact");
        }

        if($data["name"] == "" || strlen($data["name"]) > 100) { $error = "Enter your name"; }
        else if(!filter_var($data["email"], FILTER_VALIDATE_EMAIL) || strlen($data["email"]) > 150) { $error = "Enter a valid email"; }
        else if($data["subject"] == "" || strlen($data["subject"]) > 150) { $error = "Enter a subject (up to 150 characters)"; }
        else if(strlen($data["message"]) < 10) { $error = "Write a message of at least 10 characters"; }
        else if(strlen($data["message"]) > 3000) { $error = "Please keep your message under 3000 characters"; }
        else if(time() - $last < 60) { $error = "Please wait a minute before sending another message"; }

        if($error != "")
        {
            $this->contactForm($data, $error);
            return;
        }

        ContactMessage::create($data["name"], $data["email"], $data["subject"], $data["message"]);
        $_SESSION["contact_last"] = time();

        flash("Thanks! Your message was sent to the Lostly team.");
        redirect("contact");
    }
}
