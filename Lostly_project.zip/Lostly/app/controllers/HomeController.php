<?php

class HomeController extends Controller
{
    // Public landing page.
    public function index()
    {
        $this->view("home/index", [
            "page_title" => "Lost & found for Bangladesh",
            "page_description" => "Lostly is the lost and found notice board for Bangladesh. Report what you lost or found, get matched automatically and message the other person safely.",
            "page" => "home",
            "total_reports" => Item::publicCount(),
            "total_resolved" => Item::publicCount(true),
            "total_members" => User::count(true),
            "recent" => Item::recent(8),
            "reunited" => Item::reunited(3),
            "category_counts" => Item::activeCounts("Category"),
            "division_counts" => Item::activeCounts("Division")
        ]);
    }
}
