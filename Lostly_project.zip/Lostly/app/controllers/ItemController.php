<?php

class ItemController extends Controller
{
    // Browse (public): search, filters, sorting, pagination.
    public function index()
    {
        $filters = [
            "search" => Request::query("search"),
            "type" => Request::query("type"),
            "division" => Request::query("division"),
            "category" => Request::query("category"),
            "status" => Request::query("status", "Active"),
            "sort" => Request::query("sort", "newest")
        ];

        // Typing a reference such as LF-00042 jumps straight to that report.
        if(preg_match('/^LF-?0*(\d{1,9})$/i', $filters["search"], $match) && Item::find((int)$match[1]))
        {
            redirect("items/" . (int)$match[1]);
        }

        // Anything not on the allowed lists falls back to the default.
        if(!in_array($filters["type"], ["Lost", "Found"])) { $filters["type"] = ""; }
        if(!in_array($filters["division"], config("divisions"))) { $filters["division"] = ""; }
        if(!in_array($filters["category"], config("categories"))) { $filters["category"] = ""; }
        if(!in_array($filters["status"], ["Active", "Resolved", "All"])) { $filters["status"] = "Active"; }
        if(!in_array($filters["sort"], ["newest", "oldest", "date", "popular"])) { $filters["sort"] = "newest"; }

        $per_page = config("per_page");
        $current = max(1, (int)Request::query("page", "1"));

        $result = Item::search($filters, $current, $per_page);
        $pages = max(1, (int)ceil($result["total"] / $per_page));

        // Asked for a page past the end (for example after changing a filter): show the last one.
        if($current > $pages)
        {
            $current = $pages;
            $result = Item::search($filters, $current, $per_page);
        }

        $this->view("items/browse", [
            "page_title" => "Browse",
            "page_description" => "Search lost and found reports across Bangladesh by keyword, category and division.",
            "page" => "browse",
            "filters" => $filters,
            "items" => $result["items"],
            "total" => $result["total"],
            "current" => $current,
            "pages" => $pages
        ]);
    }

    // One report (public). Contact details, claims and messages need a login.
    public function show($id)
    {
        $item = $this->visibleItem($id);
        $me = Auth::id();
        $is_owner = $me && $item["UserID"] == $me;

        // Count one view per visitor per session (the owner's own visits don't count).
        if(!$is_owner && empty($_SESSION["viewed"][$id]))
        {
            $_SESSION["viewed"][$id] = true;
            Item::addView($id);
            $item["Views"]++;
        }

        $this->view("items/show", [
            "page_title" => $item["ItemName"] . " (" . $item["Type"] . ")",
            "page_description" => $item["Type"] . " in " . $item["District"] . ", " . $item["Division"] . ": " . shorten((string)$item["Description"], 140),
            "page_image" => $item["ImagePath"],
            "page" => "item",
            "item" => $item,
            "photos" => Item::photos($item),
            "is_owner" => $is_owner,
            "is_lost" => $item["Type"] == "Lost",
            "matches" => $item["Status"] == "Active" ? Item::matches($item, 3) : [],
            "claims" => $is_owner ? Claim::forItem($id) : [],
            "my_claim" => ($me && !$is_owner) ? Claim::byUserOnItem($id, $me) : null,
            "is_saved" => $me ? Saved::has($me, $id) : false,
            "comments" => Comment::forItem($id)
        ]);
    }

    public function create()
    {
        $this->requireLogin();

        $me = Auth::user();

        $this->form([
            "type" => Request::query("type") == "found" ? "Found" : "Lost",
            "item_name" => "",
            "category" => "",
            "description" => "",
            "division" => $me["Division"],
            "district" => $me["District"],
            "event_date" => date("Y-m-d"),
            "reward" => null
        ], 0, [], "");
    }

    public function store()
    {
        $this->requireLogin();

        $data = $this->input();
        $error = $this->validate($data);
        $paths = [];

        if($error == "" && Upload::countSent("photos") > config("max_photos"))
        {
            $error = "You can add up to " . config("max_photos") . " photos";
        }

        if($error == "")
        {
            list($paths, $error) = Upload::storeMany("photos");
        }

        if($error != "")
        {
            $this->form($data, 0, [], $error);
            return;
        }

        $data["image_path"] = count($paths) > 0 ? $paths[0] : null;

        $id = Item::create(Auth::id(), $data);
        Item::setPhotos($id, $paths);

        $item = Item::find($id);
        $notified = [];

        // Look for matching reports straight away and alert their owners.
        $matches = $item ? Item::matches($item, 5) : [];

        foreach($matches as $match)
        {
            $notified[$match["UserID"]] = true;

            Notification::send($match["UserID"], "match",
                "A new " . strtolower($data["type"]) . " report \"" . $data["item_name"] . "\" may match your \"" . $match["ItemName"] . "\"",
                "items/" . $id);
        }

        // Then everyone whose saved search fits this report.
        foreach($item ? SearchAlert::subscribersFor($item) : [] as $user_id)
        {
            if(empty($notified[$user_id]))
            {
                Notification::send($user_id, "search",
                    "New " . strtolower($data["type"]) . " report \"" . $data["item_name"] . "\" fits one of your saved searches",
                    "items/" . $id);
            }
        }

        if(count($matches) > 0)
        {
            flash("Posted! We found " . count($matches) . " possible match" . (count($matches) == 1 ? "" : "es") . " for you below.");
        }
        else
        {
            flash("Posted! We'll alert you as soon as a matching report appears.");
        }

        redirect("items/" . $id);
    }

    public function edit($id)
    {
        $this->requireLogin();

        $item = $this->ownedItem($id);

        $this->form([
            "type" => $item["Type"],
            "item_name" => $item["ItemName"],
            "category" => $item["Category"],
            "description" => $item["Description"],
            "division" => $item["Division"],
            "district" => $item["District"],
            "event_date" => $item["EventDate"],
            "reward" => $item["Reward"]
        ], $id, Item::photos($item), "");
    }

    public function update($id)
    {
        $this->requireLogin();

        $item = $this->ownedItem($id);
        $existing = Item::photos($item);

        // Photos ticked for removal arrive as their position in the current list.
        $remove = isset($_POST["remove_photos"]) && is_array($_POST["remove_photos"]) ? array_map("intval", $_POST["remove_photos"]) : [];
        $kept = [];
        $removed = [];

        foreach($existing as $index => $path)
        {
            if(in_array($index, $remove, true))
            {
                $removed[] = $path;
            }
            else
            {
                $kept[] = $path;
            }
        }

        $data = $this->input();
        $error = $this->validate($data);
        $new = [];

        if($error == "" && count($kept) + Upload::countSent("photos") > config("max_photos"))
        {
            $error = "A report can have up to " . config("max_photos") . " photos. Remove one before adding more.";
        }

        if($error == "")
        {
            list($new, $error) = Upload::storeMany("photos");
        }

        if($error != "")
        {
            $this->form($data, $id, $existing, $error);
            return;
        }

        $photos = array_merge($kept, $new);
        $data["image_path"] = count($photos) > 0 ? $photos[0] : null;

        Item::update($id, Auth::id(), $data);
        Item::setPhotos($id, $photos);

        foreach($removed as $path)
        {
            Upload::delete($path);
        }

        flash("Report updated.");
        redirect("items/" . $id);
    }

    public function destroy($id)
    {
        $this->requireLogin();

        // findOwned() only returns the report to its owner, so nobody can delete someone else's.
        $item = Item::findOwned($id, Auth::id());

        if($item)
        {
            Item::delete($item);
            flash("Report deleted.");
        }

        redirect("dashboard");
    }

    // The owner marks the report resolved, optionally with a public thank-you note.
    public function resolve($id)
    {
        $this->requireLogin();

        $item = $this->ownedItem($id);
        $note = Request::post("note");

        if(strlen($note) > 500)
        {
            flash("Please keep your note under 500 characters.", "error");
            redirect("items/" . $id);
        }

        Item::resolve($id, $note != "" ? $note : null);

        // Tell everyone who was watching this report.
        foreach(Saved::watchers($id) as $user_id)
        {
            if($user_id != Auth::id())
            {
                Notification::send($user_id, "saved",
                    "A report you saved, \"" . $item["ItemName"] . "\", has been resolved", "items/" . $id);
            }
        }

        flash("Marked as resolved. Glad it worked out!");
        redirect("items/" . $id);
    }

    public function reopen($id)
    {
        $this->requireLogin();
        $this->ownedItem($id);

        Item::reopen($id);
        flash("Report is active again.");
        redirect("items/" . $id);
    }

    // Report a suspicious post to the admins.
    public function flag($id)
    {
        $this->requireLogin();

        $item = $this->visibleItem($id);
        $reason = Request::post("reason");

        if($item["UserID"] == Auth::id())
        {
            flash("You can't report your own post.", "error");
        }
        else if($reason == "" || strlen($reason) > 255)
        {
            flash("Tell the admins what's wrong (up to 255 characters).", "error");
        }
        else if(Flag::exists($id, Auth::id()))
        {
            flash("You already reported this post. An admin will look at it.", "error");
        }
        else
        {
            Flag::create($id, Auth::id(), $reason);
            flash("Thanks. An admin will review this post.");
        }

        redirect("items/" . $id);
    }

    // Add the report to, or remove it from, the member's saved list.
    public function save($id)
    {
        $this->requireLogin();
        $this->visibleItem($id);

        flash(Saved::toggle(Auth::id(), $id)
            ? "Saved. You'll be told when this report is resolved."
            : "Removed from your saved reports.");

        redirect("items/" . $id);
    }

    public function saved()
    {
        $this->requireLogin();

        $this->view("items/saved", [
            "page_title" => "Saved reports",
            "page" => "saved",
            "items" => Saved::forUser(Auth::id())
        ]);
    }

    // A printable A4 poster of the owner's own report.
    public function poster($id)
    {
        $this->requireLogin();

        $item = $this->ownedItem($id);

        View::bare("items/poster", [
            "item" => $item,
            "owner" => Auth::user()
        ]);
    }

    // ---- helpers --------------------------------------------------------

    // A report the current visitor is allowed to see, or back to the board.
    private function visibleItem($id)
    {
        $item = Item::find($id);

        // Missing, or posted by a suspended account (admins can still see those).
        if(!$item || ($item["IsBanned"] && !Auth::isAdmin()))
        {
            flash("That report is no longer available.", "error");
            redirect("items");
        }

        return $item;
    }

    // A report that belongs to the current user, or back to the dashboard.
    private function ownedItem($id)
    {
        $item = Item::findOwned($id, Auth::id());

        if(!$item)
        {
            flash("You can only change your own reports.", "error");
            redirect("dashboard");
        }

        return $item;
    }

    private function input()
    {
        $type = Request::post("type") == "Found" ? "Found" : "Lost";
        $reward = Request::post("reward");

        return [
            "type" => $type,
            "item_name" => Request::post("item_name"),
            "category" => Request::post("category"),
            "description" => Request::post("description"),
            "division" => Request::post("division"),
            "district" => Request::post("district"),
            "event_date" => Request::post("event_date"),
            // A reward only makes sense on a Lost report. "" means none.
            "reward" => ($type == "Lost" && $reward !== "") ? $reward : null
        ];
    }

    // Returns "" when the report is valid, otherwise the message to show.
    private function validate(&$data)
    {
        $date = DateTime::createFromFormat("Y-m-d", $data["event_date"]);

        if($data["item_name"] == "") return "Enter the item name";
        if(strlen($data["item_name"]) > 100) return "Item name must be 100 characters or fewer";
        if(!in_array($data["category"], config("categories"))) return "Select a valid category";
        if(!in_array($data["division"], config("divisions"))) return "Select a valid division";
        if($data["district"] == "") return "Enter a district";
        if(strlen($data["district"]) > 50) return "District must be 50 characters or fewer";
        if(strlen($data["description"]) > 2000) return "Description must be 2000 characters or fewer";
        if(!$date || $date->format("Y-m-d") != $data["event_date"]) return "Select a date";
        if($data["event_date"] > date("Y-m-d")) return "The date can't be in the future";

        if($data["reward"] !== null)
        {
            if(!preg_match('/^[0-9]{1,8}$/', (string)$data["reward"]) || (int)$data["reward"] < 1 || (int)$data["reward"] > 10000000)
            {
                return "Reward must be a whole number of taka (1 to 10,000,000)";
            }

            $data["reward"] = (int)$data["reward"];
        }

        return "";
    }

    private function form($data, $id, $photos, $error)
    {
        $this->view("items/form", [
            "page_title" => $id ? "Edit report" : "Report an item",
            "page" => "report",
            "data" => $data,
            "id" => $id,
            "photos" => $photos,
            "error" => $error
        ]);
    }
}
