<?php

// Lostly settings. Change the database values if your MySQL setup differs.

return [
    "db" => [
        "host" => "localhost",
        "user" => "root",
        "password" => "",
        "name" => "lostly"
    ],

    "timezone" => "Asia/Dhaka",
    "mysql_timezone" => "+06:00",

    "per_page" => 9,
    "match_threshold" => 55,
    "max_upload_bytes" => 5 * 1024 * 1024,
    "max_photos" => 4,
    "max_search_alerts" => 10,

    "categories" => [
        "Electronics", "Documents", "Bags & Wallets", "Jewelry",
        "Keys", "Pets", "Clothing", "Other"
    ],

    "divisions" => [
        "Dhaka", "Chattogram", "Rajshahi", "Khulna",
        "Barishal", "Sylhet", "Rangpur", "Mymensingh"
    ],

    // The 64 districts, used as suggestions in the District field.
    "districts" => [
        "Dhaka" => ["Dhaka", "Faridpur", "Gazipur", "Gopalganj", "Kishoreganj", "Madaripur", "Manikganj",
                    "Munshiganj", "Narayanganj", "Narsingdi", "Rajbari", "Shariatpur", "Tangail"],
        "Chattogram" => ["Bandarban", "Brahmanbaria", "Chandpur", "Chattogram", "Cox's Bazar", "Cumilla",
                         "Feni", "Khagrachhari", "Lakshmipur", "Noakhali", "Rangamati"],
        "Rajshahi" => ["Bogura", "Chapainawabganj", "Joypurhat", "Naogaon", "Natore", "Pabna", "Rajshahi", "Sirajganj"],
        "Khulna" => ["Bagerhat", "Chuadanga", "Jashore", "Jhenaidah", "Khulna", "Kushtia", "Magura",
                     "Meherpur", "Narail", "Satkhira"],
        "Barishal" => ["Barguna", "Barishal", "Bhola", "Jhalokathi", "Patuakhali", "Pirojpur"],
        "Sylhet" => ["Habiganj", "Moulvibazar", "Sunamganj", "Sylhet"],
        "Rangpur" => ["Dinajpur", "Gaibandha", "Kurigram", "Lalmonirhat", "Nilphamari", "Panchagarh",
                      "Rangpur", "Thakurgaon"],
        "Mymensingh" => ["Jamalpur", "Mymensingh", "Netrokona", "Sherpur"]
    ]
];
