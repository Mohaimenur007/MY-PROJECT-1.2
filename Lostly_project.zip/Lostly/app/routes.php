<?php

// Every address the site answers to, and the controller method behind it.
// {id} style placeholders are passed to the method as numbers.

$router->get("", "HomeController@index");

// accounts
$router->get("login", "AuthController@loginForm");
$router->post("login", "AuthController@login");
$router->get("register", "AuthController@registerForm");
$router->post("register", "AuthController@register");
$router->post("logout", "AuthController@logout");

$router->get("dashboard", "DashboardController@index");

$router->get("profile", "ProfileController@edit");
$router->post("profile", "ProfileController@update");

// lost & found reports
$router->get("items", "ItemController@index");
$router->get("items/new", "ItemController@create");
$router->post("items", "ItemController@store");
$router->get("items/{id}", "ItemController@show");
$router->get("items/{id}/edit", "ItemController@edit");
$router->post("items/{id}", "ItemController@update");
$router->post("items/{id}/delete", "ItemController@destroy");
$router->post("items/{id}/resolve", "ItemController@resolve");
$router->post("items/{id}/reopen", "ItemController@reopen");
$router->post("items/{id}/flag", "ItemController@flag");
$router->post("items/{id}/save", "ItemController@save");
$router->get("items/{id}/poster", "ItemController@poster");
$router->get("saved", "ItemController@saved");

// public sightings & tips on a report
$router->post("items/{id}/comments", "CommentController@store");
$router->post("comments/{id}/delete", "CommentController@destroy");

// public member profiles
$router->get("members/{id}", "MemberController@show");

// claims
$router->post("items/{id}/claims", "ClaimController@store");
$router->post("claims/{id}/decide", "ClaimController@decide");

// private messages: {item}/{user} = which report, and who you are talking to
$router->get("messages", "MessageController@index");
$router->get("messages/{item}/{user}", "MessageController@thread");
$router->post("messages/{item}/{user}", "MessageController@send");
$router->get("messages/{item}/{user}/poll", "MessageController@poll");

// alerts
$router->get("alerts", "NotificationController@index");
$router->post("alerts/clear", "NotificationController@clear");
$router->post("alerts/searches", "NotificationController@subscribe");
$router->post("alerts/searches/{id}/delete", "NotificationController@unsubscribe");

// information pages
$router->get("reunited", "PageController@reunited");
$router->get("about", "PageController@about");
$router->get("safety", "PageController@safety");
$router->get("faq", "PageController@faq");
$router->get("terms", "PageController@terms");
$router->get("privacy", "PageController@privacy");
$router->get("contact", "PageController@contactForm");
$router->post("contact", "PageController@contactSend");

// admin panel
$router->get("admin", "AdminController@index");
$router->post("admin/items/{id}/delete", "AdminController@deleteItem");
$router->post("admin/flags/{id}/dismiss", "AdminController@dismissFlag");
$router->get("admin/export", "AdminController@export");
$router->post("admin/announcement", "AdminController@saveAnnouncement");
$router->post("admin/inbox/{id}/delete", "AdminController@deleteMessage");
$router->post("admin/users/{id}/ban", "AdminController@ban");
$router->post("admin/users/{id}/unban", "AdminController@unban");
$router->post("admin/users/{id}/promote", "AdminController@promote");
$router->post("admin/users/{id}/demote", "AdminController@demote");
