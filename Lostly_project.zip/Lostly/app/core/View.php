<?php

// Draws a view file inside the shared page layout.
class View
{
    // $view is a path under app/views, e.g. "items/show".
    public static function render($view, $data = [])
    {
        extract($data);

        ob_start();
        require(APP . "/views/" . $view . ".php");
        $content = ob_get_clean();

        require(APP . "/views/layouts/main.php");
    }

    // A whole page of its own, without the site layout (the printable poster).
    public static function bare($view, $data = [])
    {
        extract($data);
        require(APP . "/views/" . $view . ".php");
    }

    // A reusable piece (no layout), e.g. View::partial("partials/item_card", [...]).
    public static function partial($view, $data = [])
    {
        extract($data);
        require(APP . "/views/" . $view . ".php");
    }
}
