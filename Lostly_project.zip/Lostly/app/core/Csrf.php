<?php

// Protects forms: every POST must send back the secret token stored in the session.
class Csrf
{
    public static function token()
    {
        if(empty($_SESSION["csrf"]))
        {
            $_SESSION["csrf"] = bin2hex(random_bytes(32));
        }

        return $_SESSION["csrf"];
    }

    public static function verify()
    {
        if($_SERVER["REQUEST_METHOD"] != "POST")
        {
            return;
        }

        $sent = isset($_POST["csrf"]) && is_string($_POST["csrf"]) ? $_POST["csrf"] : "";

        if(empty($_SESSION["csrf"]) || !hash_equals($_SESSION["csrf"], $sent))
        {
            http_response_code(400);
            die("Your session expired or the form was invalid. Please go back, refresh the page and try again.");
        }
    }
}
