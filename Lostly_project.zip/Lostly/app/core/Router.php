<?php

// Maps an address to a controller method.
//   $router->get("items/{id}", "ItemController@show");
class Router
{
    private $routes = [];

    public function get($pattern, $action)
    {
        $this->routes[] = ["GET", $pattern, $action];
    }

    public function post($pattern, $action)
    {
        $this->routes[] = ["POST", $pattern, $action];
    }

    public function dispatch($method, $path)
    {
        if($method == "HEAD")
        {
            $method = "GET";
        }

        foreach($this->routes as $route)
        {
            list($route_method, $pattern, $action) = $route;

            // {id} style placeholders only ever match whole numbers.
            $regex = "#^" . preg_replace('/\{[a-z_]+\}/', '(\d{1,9})', $pattern) . "$#";

            if($route_method == $method && preg_match($regex, $path, $matches))
            {
                array_shift($matches);
                $params = array_map("intval", $matches);

                list($class, $function) = explode("@", $action);

                $controller = new $class();
                $controller->$function(...$params);
                return;
            }
        }

        self::notFound();
    }

    public static function notFound()
    {
        http_response_code(404);

        View::render("partials/error", [
            "page_title" => "Page not found",
            "heading" => "This notice fell off the board",
            "text" => "The page you asked for doesn't exist or has been removed."
        ]);

        exit();
    }
}
