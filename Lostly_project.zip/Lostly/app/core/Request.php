<?php

// Reads the incoming request: which route was asked for, and form input.
class Request
{
    // Folder the site lives in, e.g. "/Lostly" ("" when it is the web root).
    public static function base()
    {
        return rtrim(str_replace("\\", "/", dirname($_SERVER["SCRIPT_NAME"])), "/");
    }

    // The route part of the address, e.g. "items/7".
    public static function path()
    {
        if(!empty($_SERVER["PATH_INFO"]))
        {
            return trim($_SERVER["PATH_INFO"], "/");
        }

        // Some servers don't set PATH_INFO, so work it out from the full address.
        $uri = rawurldecode((string)strtok($_SERVER["REQUEST_URI"], "?"));
        $script = $_SERVER["SCRIPT_NAME"];

        if(strpos($uri, $script) === 0)
        {
            $uri = substr($uri, strlen($script));
        }
        else if(self::base() != "" && strpos($uri, self::base()) === 0)
        {
            $uri = substr($uri, strlen(self::base()));
        }

        return trim($uri, "/");
    }

    // Trimmed text from the submitted form.
    public static function post($key, $default = "")
    {
        return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : $default;
    }

    // Untrimmed (for passwords, where spaces matter).
    public static function raw($key)
    {
        return isset($_POST[$key]) && is_string($_POST[$key]) ? $_POST[$key] : "";
    }

    public static function query($key, $default = "")
    {
        return isset($_GET[$key]) && is_string($_GET[$key]) ? trim($_GET[$key]) : $default;
    }
}
