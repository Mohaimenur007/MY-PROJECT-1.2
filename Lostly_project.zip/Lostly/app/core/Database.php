<?php

// Thin wrapper around mysqli. Every query is a prepared statement.
class Database
{
    private static $conn;

    public static function connect($settings)
    {
        self::$conn = mysqli_connect($settings["host"], $settings["user"], $settings["password"], $settings["name"]);

        if(!self::$conn)
        {
            die("Connection Failed");
        }

        mysqli_set_charset(self::$conn, "utf8mb4");

        // Keep MySQL on the same clock as PHP so "5 min ago" is always right.
        mysqli_query(self::$conn, "SET time_zone = '" . config("mysql_timezone") . "'");
    }

    // $types is the mysqli type string ("i" integer, "s" string), one letter per value.
    public static function run($sql, $types = "", $params = [])
    {
        $stmt = mysqli_prepare(self::$conn, $sql);

        if(!$stmt)
        {
            error_log("Lostly SQL prepare failed: " . $sql);
            return false;
        }

        if($types !== "")
        {
            mysqli_stmt_bind_param($stmt, $types, ...$params);
        }

        mysqli_stmt_execute($stmt);
        return $stmt;
    }

    public static function all($sql, $types = "", $params = [])
    {
        $rows = [];
        $stmt = self::run($sql, $types, $params);

        if($stmt)
        {
            $result = mysqli_stmt_get_result($stmt);

            while($result && $row = mysqli_fetch_assoc($result))
            {
                $rows[] = $row;
            }
        }

        return $rows;
    }

    public static function one($sql, $types = "", $params = [])
    {
        $rows = self::all($sql, $types, $params);
        return count($rows) > 0 ? $rows[0] : null;
    }

    // First column of the first row (handy for COUNT(*)).
    public static function value($sql, $types = "", $params = [])
    {
        $row = self::one($sql, $types, $params);
        return $row ? array_values($row)[0] : null;
    }

    public static function insert($sql, $types = "", $params = [])
    {
        $stmt = self::run($sql, $types, $params);
        return $stmt ? mysqli_insert_id(self::$conn) : 0;
    }
}
