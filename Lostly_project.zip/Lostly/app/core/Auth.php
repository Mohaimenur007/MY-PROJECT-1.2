<?php

// Who is logged in.
class Auth
{
    private static $user = null;

    public static function boot()
    {
        if(isset($_SESSION["id"]))
        {
            self::$user = User::find($_SESSION["id"]);

            // Account deleted or suspended while logged in: end the session.
            if(!self::$user || self::$user["IsBanned"])
            {
                $_SESSION = [];
                self::$user = null;
            }
        }
    }

    public static function user()
    {
        return self::$user;
    }

    public static function id()
    {
        return self::$user ? (int)self::$user["ID"] : 0;
    }

    public static function check()
    {
        return self::$user !== null;
    }

    public static function isAdmin()
    {
        return self::$user && self::$user["Role"] == "admin";
    }

    public static function login($user)
    {
        // A fresh session ID on login stops session fixation.
        session_regenerate_id(true);
        unset($_SESSION["login_attempts"], $_SESSION["login_locked_until"]);

        $_SESSION["id"] = $user["ID"];
        $_SESSION["username"] = $user["Username"];
    }

    public static function logout()
    {
        $_SESSION = [];
        session_destroy();
        self::$user = null;
    }
}
