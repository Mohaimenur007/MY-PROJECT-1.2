<?php

// Small functions used by controllers and views everywhere.

function config($key)
{
    return $GLOBALS["config"][$key];
}

function e($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

// Link to a route:  url("items/7")  ->  /Lostly/index.php/items/7
function url($path = "", $query = [])
{
    $link = Request::base() . "/index.php" . ($path != "" ? "/" . ltrim($path, "/") : "");

    if(count($query) > 0)
    {
        $link .= "?" . http_build_query($query);
    }

    return $link;
}

// Link to a file:  asset("css/style.css")  ->  /Lostly/css/style.css
function asset($path)
{
    return Request::base() . "/" . ltrim($path, "/");
}

// Full address including http://host, for share links and posters.
function absolute_url($path = "", $query = [])
{
    $https = !empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] != "off";
    $host = isset($_SERVER["HTTP_HOST"]) ? preg_replace('/[^A-Za-z0-9.\-:\[\]]/', "", $_SERVER["HTTP_HOST"]) : "localhost";

    return ($https ? "https" : "http") . "://" . $host . url($path, $query);
}

// Full address of a file such as an uploaded photo.
function absolute_asset($path)
{
    return preg_replace('#/index\.php$#', "", absolute_url("")) . "/" . ltrim($path, "/");
}

function taka($amount)
{
    return "৳" . number_format((int)$amount);
}

function redirect($path, $query = [])
{
    header("Location: " . url($path, $query));
    exit();
}

function flash($message, $type = "success")
{
    $_SESSION["flash"][] = ["type" => $type, "message" => $message];
}

function take_flashes()
{
    $list = isset($_SESSION["flash"]) ? $_SESSION["flash"] : [];
    unset($_SESSION["flash"]);
    return $list;
}

function csrf_field()
{
    return '<input type="hidden" name="csrf" value="' . Csrf::token() . '">';
}

function selected($a, $b)
{
    return $a == $b ? "selected" : "";
}

function initial($name)
{
    $first = function_exists("mb_substr") ? mb_substr($name, 0, 1, "UTF-8") : substr($name, 0, 1);
    return function_exists("mb_strtoupper") ? mb_strtoupper($first, "UTF-8") : strtoupper($first);
}

function shorten($text, $length)
{
    if(function_exists("mb_strimwidth"))
    {
        return mb_strimwidth($text, 0, $length, "…", "UTF-8");
    }

    return strlen($text) > $length ? substr($text, 0, $length) . "…" : $text;
}

function time_ago($datetime)
{
    $diff = time() - strtotime($datetime);

    if($diff < 60) return "just now";
    if($diff < 3600) return floor($diff / 60) . " min ago";
    if($diff < 86400) return floor($diff / 3600) . " hr ago";
    if($diff < 86400 * 7) return floor($diff / 86400) . " day" . (floor($diff / 86400) == 1 ? "" : "s") . " ago";

    return date("M j, Y", strtotime($datetime));
}

function category_icon($category)
{
    $icons = [
        "Electronics" => "📱",
        "Documents" => "📄",
        "Bags & Wallets" => "👜",
        "Jewelry" => "💍",
        "Keys" => "🔑",
        "Pets" => "🐾",
        "Clothing" => "🧥",
        "Other" => "📦"
    ];

    return isset($icons[$category]) ? $icons[$category] : "📦";
}
