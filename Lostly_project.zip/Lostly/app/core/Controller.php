<?php

// Base class every controller extends.
class Controller
{
    protected function view($view, $data = [])
    {
        View::render($view, $data);
    }

    protected function json($data)
    {
        header("Content-Type: application/json; charset=utf-8");
        echo json_encode($data);
        exit();
    }

    protected function requireLogin()
    {
        if(!Auth::check())
        {
            // Remember where they were going, so login can send them back there.
            if($_SERVER["REQUEST_METHOD"] == "GET")
            {
                $_SESSION["intended"] = ["path" => Request::path(), "query" => $_GET];
            }

            flash("Please log in to continue.", "error");
            redirect("login");
        }
    }

    protected function requireGuest()
    {
        if(Auth::check())
        {
            redirect("dashboard");
        }
    }

    protected function requireAdmin()
    {
        $this->requireLogin();

        if(!Auth::isAdmin())
        {
            flash("That page is for administrators only.", "error");
            redirect("dashboard");
        }
    }
}
