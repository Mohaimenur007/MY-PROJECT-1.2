<div class="container-xl auth-container">
    <div class="row align-items-center gy-5 gx-lg-5">

        <div class="col-lg-6 auth-side">
            <p class="eyebrow">Welcome back</p>
            <h1>The board missed you.</h1>
            <p>Check your matches, answer claims and see if anyone has spotted your item.</p>
        </div>

        <div class="col-lg-5 offset-lg-1">
            <div class="auth-box">
                <span class="tape"></span>

                <h2>Login</h2>
                <p class="text-body-secondary">Use your Lostly username</p>

                <form method="post" action="<?= url("login") ?>" class="js-validate">
                    <?= csrf_field() ?>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" class="form-control" id="username" name="username" value="<?= e($username) ?>" data-required="Enter Username" autocomplete="username">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" data-required="Enter Password" autocomplete="current-password">
                    </div>

                    <?php if($error != "") { ?>
                    <div class="alert alert-lost form-message" role="alert"><?= e($error) ?></div>
                    <?php } ?>

                    <button type="submit" class="btn btn-ink w-100">Login</button>
                </form>

                <p class="switch-link">Don't have an account? <a href="<?= url("register") ?>">Create one</a></p>
            </div>
        </div>

    </div>
</div>
