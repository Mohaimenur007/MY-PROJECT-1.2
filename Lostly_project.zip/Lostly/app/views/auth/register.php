<div class="container-xl auth-container">
    <div class="row align-items-center gy-5 gx-lg-5">

        <div class="col-lg-5 auth-side">
            <p class="eyebrow">Join Lostly Bangladesh</p>
            <h1>One account. Every notice board.</h1>
            <p>Post reports, get automatic matches and message other members without sharing your number first.</p>
        </div>

        <div class="col-lg-7">
            <div class="auth-box">
                <span class="tape"></span>

                <h2>Create Account</h2>
                <p class="text-body-secondary">It's free and takes a minute</p>

                <form method="post" action="<?= url("register") ?>" class="js-validate">
                    <?= csrf_field() ?>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" maxlength="100" value="<?= e($old["username"]) ?>" data-required="Enter Username" autocomplete="username">
                        </div>

                        <div class="col-md-6">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" maxlength="150" value="<?= e($old["email"]) ?>" data-required="Enter Email" autocomplete="email">
                        </div>

                        <div class="col-md-6">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="text" class="form-control" id="phone" name="phone" maxlength="20" value="<?= e($old["phone"]) ?>" data-required="Enter Phone Number" autocomplete="tel">
                        </div>

                        <div class="col-md-6">
                            <label for="division" class="form-label">Division</label>
                            <select class="form-select" id="division" name="division" data-required="Select Division">
                                <option value="">Select Division</option>
                                <?php foreach(config("divisions") as $div) { ?>
                                <option value="<?= e($div) ?>" <?= selected($old["division"], $div) ?>><?= e($div) ?></option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="col-12">
                            <label for="district" class="form-label">District</label>
                            <input type="text" class="form-control" id="district" name="district" maxlength="100" list="district-list" value="<?= e($old["district"]) ?>" data-required="Enter District" autocomplete="off">
                            <?php View::partial("partials/district_list"); ?>
                        </div>

                        <div class="col-md-6">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" data-required="Enter Password" data-minlength="6" data-minlength-message="Password must be at least 6 characters" autocomplete="new-password">
                        </div>

                        <div class="col-md-6">
                            <label for="confirm_password" class="form-label">Confirm Password</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" data-match="password" data-match-message="Passwords do not match" autocomplete="new-password">
                        </div>
                    </div>

                    <?php if($error != "") { ?>
                    <div class="alert alert-lost form-message mt-3" role="alert"><?= e($error) ?></div>
                    <?php } ?>

                    <button type="submit" class="btn btn-ink w-100 mt-3">Create Account</button>
                </form>

                <p class="switch-link">Already have an account? <a href="<?= url("login") ?>">Login</a></p>
            </div>
        </div>

    </div>
</div>
