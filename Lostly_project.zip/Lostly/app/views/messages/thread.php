<?php $route = "messages/" . (int)$item["ID"] . "/" . (int)$other["ID"]; ?>
<div class="container-xl page page-narrow">

    <a href="<?= url("messages") ?>" class="text-link back-link">← All conversations</a>

    <section class="panel chat">
        <div class="chat-head">
            <span class="avatar"><?= e(initial($other["Username"])) ?></span>
            <div>
                <strong><?= e($other["Username"]) ?></strong>
                <span class="text-body-secondary">about
                    <a href="<?= url("items/" . (int)$item["ID"]) ?>"><?= e($item["ItemName"]) ?></a>
                    <span class="badge rounded-pill badge-<?= strtolower($item["Type"]) ?>"><?= e($item["Type"]) ?></span>
                </span>
            </div>
        </div>

        <div class="chat-body js-chat"
             data-url="<?= e(url($route . "/poll")) ?>"
             data-last="<?= count($messages) > 0 ? (int)$messages[count($messages) - 1]["ID"] : 0 ?>">

            <?php if(count($messages) == 0) { ?>
            <p class="text-body-secondary chat-empty js-chat-empty">No messages yet. Say hello and explain why you're writing.</p>
            <?php } ?>

            <?php foreach($messages as $row) { ?>
            <div class="bubble <?= $row["SenderID"] == Auth::id() ? "mine" : "theirs" ?>">
                <p><?= nl2br(e($row["Body"])) ?></p>
                <time><?= date("M j, g:i a", strtotime($row["CreatedAt"])) ?></time>
            </div>
            <?php } ?>
        </div>

        <form method="post" action="<?= url($route) ?>" class="chat-form js-validate">
            <?= csrf_field() ?>
            <textarea class="form-control js-enter-submit" name="body" rows="2" maxlength="2000" placeholder="Write a message…" aria-label="Message" data-required="Type a message first."></textarea>
            <button type="submit" class="btn btn-ink">Send</button>
        </form>
    </section>

</div>
