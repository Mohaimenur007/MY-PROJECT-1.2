<div class="container-xl page page-narrow">

    <section class="page-hero">
        <p class="eyebrow">Inbox</p>
        <h1>Messages</h1>
        <p>Private conversations about lost and found items.</p>
    </section>

    <section class="panel">
        <?php if(count($threads) == 0) { ?>

        <div class="empty">
            <span class="empty-icon">💬</span>
            <p>No conversations yet. Open a notice and press “Send a private message”.</p>
        </div>

        <?php } else { ?>

        <div class="list-rows">
            <?php foreach($threads as $thread) { ?>
            <a class="list-row list-row-link <?= $thread["unread"] > 0 ? "unread" : "" ?>"
               href="<?= url("messages/" . (int)$thread["item_id"] . "/" . (int)$thread["other_id"]) ?>">
                <span class="avatar"><?= e(initial($thread["other_name"])) ?></span>
                <div class="list-row-info">
                    <strong><?= e($thread["other_name"]) ?>
                        <?php if($thread["unread"] > 0) { ?><span class="badge rounded-pill badge-count"><?= (int)$thread["unread"] ?> new</span><?php } ?>
                    </strong>
                    <span>About: <?= e($thread["item_name"]) ?> (<?= e($thread["type"]) ?>)</span>
                    <span class="quote"><?= $thread["last_mine"] ? "You: " : "" ?><?= e(shorten($thread["last_body"], 90)) ?></span>
                </div>
                <span class="text-body-secondary small"><?= time_ago($thread["last_time"]) ?></span>
            </a>
            <?php } ?>
        </div>

        <?php } ?>
    </section>

</div>
