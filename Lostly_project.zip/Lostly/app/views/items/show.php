<?php
$base = "items/" . (int)$item["ID"];
$logged_in = Auth::check();
$share_url = absolute_url($base);
$share_text = $item["Type"] . ": " . $item["ItemName"] . " (" . $item["District"] . ", " . $item["Division"] . ")";
?>
<div class="container-xl page">

    <a href="<?= url("items") ?>" class="text-link back-link">← Back to the board</a>

    <div class="row g-4">

        <div class="col-lg-7">
            <article class="panel">

                <div class="detail-media">
                    <?php if(count($photos) > 0) { ?>
                    <img src="<?= e(asset($photos[0])) ?>" alt="<?= e($item["ItemName"]) ?>" class="js-gallery-main">
                    <?php } else { ?>
                    <div class="item-card-placeholder large"><?= category_icon($item["Category"]) ?></div>
                    <?php } ?>

                    <span class="stamp stamp-<?= strtolower($item["Type"]) ?>"><?= e($item["Type"]) ?></span>
                    <?php if($item["Status"] == "Resolved") { ?>
                    <span class="stamp stamp-resolved">Resolved</span>
                    <?php } ?>
                </div>

                <?php if(count($photos) > 1) { ?>
                <div class="gallery-thumbs">
                    <?php foreach($photos as $index => $path) { ?>
                    <button type="button" class="gallery-thumb js-gallery-thumb <?= $index == 0 ? "active" : "" ?>" data-src="<?= e(asset($path)) ?>" aria-label="Show photo <?= $index + 1 ?>">
                        <img src="<?= e(asset($path)) ?>" alt="">
                    </button>
                    <?php } ?>
                </div>
                <?php } ?>

                <p class="ref-line">
                    <span class="ref-code"><?= Item::code($item["ID"]) ?></span>
                    <?php if($is_lost && !empty($item["Reward"]) && $item["Status"] == "Active") { ?>
                    <span class="reward-chip static">Reward <?= taka($item["Reward"]) ?></span>
                    <?php } ?>
                </p>

                <h1 class="detail-title"><?= e($item["ItemName"]) ?></h1>

                <p class="text-body-secondary">
                    Posted by <a href="<?= url("members/" . (int)$item["UserID"]) ?>"><b><?= e($item["Username"]) ?></b></a>
                    · <?= time_ago($item["CreatedAt"]) ?> · <?= (int)$item["Views"] ?> views
                </p>

                <div class="row row-cols-1 row-cols-sm-2 g-3 my-2">
                    <div class="col"><div class="info-item"><span>Category</span><strong><?= category_icon($item["Category"]) ?> <?= e($item["Category"]) ?></strong></div></div>
                    <div class="col"><div class="info-item"><span>Date <?= $is_lost ? "lost" : "found" ?></span><strong><?= date("F j, Y", strtotime($item["EventDate"])) ?></strong></div></div>
                    <div class="col"><div class="info-item"><span>Location</span><strong><?= e($item["District"]) ?>, <?= e($item["Division"]) ?></strong></div></div>
                    <div class="col"><div class="info-item"><span>Status</span><strong><?= e($item["Status"]) ?><?= $item["Status"] == "Resolved" && $item["ResolvedAt"] ? " · " . date("M j, Y", strtotime($item["ResolvedAt"])) : "" ?></strong></div></div>
                </div>

                <?php if($item["Description"]) { ?>
                <h2 class="sub-heading">Description</h2>
                <p class="text-break"><?= nl2br(e($item["Description"])) ?></p>
                <?php } ?>

                <?php if($item["Status"] == "Resolved" && !empty($item["ResolvedNote"])) { ?>
                <div class="thanks-note">
                    <span class="thanks-label">A note from <?= e($item["Username"]) ?></span>
                    <p class="quote mb-0">“<?= nl2br(e($item["ResolvedNote"])) ?>”</p>
                </div>
                <?php } ?>

                <div class="action-bar">
                    <?php if($is_owner) { ?>

                    <a href="<?= url($base . "/edit") ?>" class="btn btn-ghost btn-sm">Edit</a>
                    <a href="<?= url($base . "/poster") ?>" class="btn btn-ghost btn-sm">🖨 Print poster</a>

                    <?php if($item["Status"] == "Active") { ?>
                    <button type="button" class="btn btn-found btn-sm" data-bs-toggle="modal" data-bs-target="#resolveModal">Mark as resolved</button>
                    <?php } else { ?>
                    <form method="post" action="<?= url($base . "/reopen") ?>">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-ghost btn-sm">Reopen report</button>
                    </form>
                    <?php } ?>

                    <form method="post" action="<?= url($base . "/delete") ?>" class="js-confirm" data-confirm-message="Delete this report? This cannot be undone.">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-danger-ghost btn-sm">Delete</button>
                    </form>

                    <?php } else if($logged_in) { ?>

                    <form method="post" action="<?= url($base . "/save") ?>">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn <?= $is_saved ? "btn-warn" : "btn-ghost" ?> btn-sm"><?= $is_saved ? "🔖 Saved" : "🔖 Save" ?></button>
                    </form>

                    <?php } ?>

                    <span class="share-group">
                        <span class="share-label">Share</span>
                        <button type="button" class="btn btn-ghost btn-sm js-copy-link" data-link="<?= e($share_url) ?>">Copy link</button>
                        <a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" href="https://wa.me/?text=<?= e(rawurlencode($share_text . " " . $share_url)) ?>">WhatsApp</a>
                        <a class="btn btn-ghost btn-sm" target="_blank" rel="noopener" href="https://www.facebook.com/sharer/sharer.php?u=<?= e(rawurlencode($share_url)) ?>">Facebook</a>
                    </span>
                </div>

            </article>

            <section class="panel" id="tips">
                <div class="section-header">
                    <h2>Sightings &amp; tips <span class="badge rounded-pill badge-count"><?= count($comments) ?></span></h2>
                    <span class="text-body-secondary small">Public. Don't post phone numbers here.</span>
                </div>

                <?php if(count($comments) == 0) { ?>
                <p class="text-body-secondary">No tips yet. Seen something that could help? Say where and when.</p>
                <?php } ?>

                <div class="list-rows">
                    <?php foreach($comments as $comment) { ?>
                    <?php $can_delete = $logged_in && ($comment["UserID"] == Auth::id() || $is_owner || Auth::isAdmin()); ?>
                    <div class="list-row align-items-start">
                        <span class="avatar avatar-sm"><?= e(initial($comment["Username"])) ?></span>
                        <div class="list-row-info">
                            <strong>
                                <a href="<?= url("members/" . (int)$comment["UserID"]) ?>"><?= e($comment["Username"]) ?></a>
                                <?php if($comment["UserID"] == $item["UserID"]) { ?><span class="badge rounded-pill badge-resolved">Reporter</span><?php } ?>
                                <span class="text-body-secondary fw-normal small">· <?= time_ago($comment["CreatedAt"]) ?></span>
                            </strong>
                            <span class="tip-body"><?= nl2br(e($comment["Body"])) ?></span>
                        </div>
                        <?php if($can_delete) { ?>
                        <form method="post" action="<?= url("comments/" . (int)$comment["ID"] . "/delete") ?>" class="js-confirm" data-confirm-message="Remove this tip?">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-danger-ghost btn-sm" aria-label="Remove tip">✕</button>
                        </form>
                        <?php } ?>
                    </div>
                    <?php } ?>
                </div>

                <?php if($logged_in) { ?>
                <form method="post" action="<?= url($base . "/comments") ?>" class="tip-form js-validate">
                    <?= csrf_field() ?>
                    <textarea class="form-control" name="body" rows="2" maxlength="500" placeholder="e.g. I saw one like this near the lake on Friday evening…" aria-label="Your tip" data-required="Write a little more before posting." data-minlength="3" data-minlength-message="Write a little more before posting."></textarea>
                    <button type="submit" class="btn btn-ink btn-sm">Post tip</button>
                </form>
                <?php } else { ?>
                <p class="mb-0"><a href="<?= url("login") ?>" class="text-link">Log in</a> to leave a tip.</p>
                <?php } ?>
            </section>
        </div>

        <aside class="col-lg-5">

            <?php if($is_owner) { ?>

            <section class="panel" id="claims">
                <h2>Claims <span class="badge rounded-pill badge-count"><?= count($claims) ?></span></h2>

                <?php if(count($claims) == 0) { ?>
                <p class="text-body-secondary mb-0">No one has claimed this yet. You'll get an alert when someone does.</p>
                <?php } ?>

                <?php foreach($claims as $claim) { ?>
                <div class="claim-card">
                    <div class="d-flex justify-content-between align-items-center gap-2 mb-1">
                        <strong><a href="<?= url("members/" . (int)$claim["ClaimantID"]) ?>"><?= e($claim["Username"]) ?></a></strong>
                        <span class="badge rounded-pill badge-<?= strtolower($claim["Status"]) ?>"><?= e($claim["Status"]) ?></span>
                    </div>

                    <p class="quote mb-1">“<?= nl2br(e($claim["Message"])) ?>”</p>
                    <p class="text-body-secondary small"><?= time_ago($claim["CreatedAt"]) ?></p>

                    <div class="d-flex flex-wrap gap-2">
                        <a href="<?= url("messages/" . (int)$item["ID"] . "/" . (int)$claim["ClaimantID"]) ?>" class="btn btn-ghost btn-sm">Message</a>

                        <?php if($claim["Status"] == "Pending") { ?>
                        <form method="post" action="<?= url("claims/" . (int)$claim["ID"] . "/decide") ?>" class="d-flex gap-2">
                            <?= csrf_field() ?>
                            <button type="submit" name="decision" value="approve" class="btn btn-found btn-sm">Approve</button>
                            <button type="submit" name="decision" value="reject" class="btn btn-danger-ghost btn-sm">Reject</button>
                        </form>
                        <?php } ?>
                    </div>
                </div>
                <?php } ?>
            </section>

            <?php } else if(!$logged_in) { ?>

            <section class="panel panel-alert">
                <h2><?= $is_lost ? "Found this item?" : "Is this yours?" ?></h2>
                <p>Log in to send a claim, message <?= e($item["Username"]) ?> privately or see their contact details.</p>
                <div class="d-flex flex-wrap gap-3">
                    <a href="<?= url("login") ?>" class="btn btn-ink">Log in</a>
                    <a href="<?= url("register") ?>" class="btn btn-ghost">Create free account</a>
                </div>
            </section>

            <?php } else { ?>

            <section class="panel">
                <h2><?= $is_lost ? "Found this item?" : "Is this yours?" ?></h2>

                <?php if($my_claim) { ?>

                <p>Your claim is
                    <span class="badge rounded-pill badge-<?= strtolower($my_claim["Status"]) ?>"><?= e($my_claim["Status"]) ?></span>
                </p>
                <p class="quote mb-0">“<?= nl2br(e($my_claim["Message"])) ?>”</p>

                <?php } else if($item["Status"] == "Active") { ?>

                <p class="text-body-secondary"><?= $is_lost
                    ? "Tell the owner where you found it and describe it so they know it's real."
                    : "Describe something only the owner would know (marks, contents, lock screen…)." ?></p>

                <form method="post" action="<?= url($base . "/claims") ?>" class="js-validate">
                    <?= csrf_field() ?>
                    <textarea class="form-control mb-3" name="claim_message" rows="3" maxlength="1000" placeholder="Your proof or details…" aria-label="Your proof or details" data-required="Please describe your proof" data-minlength="10" data-minlength-message="Please describe your proof in at least 10 characters."></textarea>
                    <button type="submit" class="btn btn-ink w-100"><?= $is_lost ? "I found it — send claim" : "This is mine — send claim" ?></button>
                </form>

                <?php } else { ?>

                <p class="text-body-secondary mb-0">This report has been resolved, so it no longer accepts claims.</p>

                <?php } ?>
            </section>

            <section class="panel">
                <h2>Talk to <?= e($item["Username"]) ?></h2>

                <a href="<?= url("messages/" . (int)$item["ID"] . "/" . (int)$item["UserID"]) ?>" class="btn btn-ink w-100">💬 Send a private message</a>

                <?php if($item["Status"] == "Active" && $item["ShowContact"]) { ?>
                <button type="button" class="btn btn-ghost w-100 mt-3" data-bs-toggle="collapse" data-bs-target="#contact-info" aria-expanded="false" aria-controls="contact-info">Show contact information</button>

                <div id="contact-info" class="collapse">
                    <div class="contact-info">
                        <p><span>Phone</span> <a href="tel:<?= e($item["Phone"]) ?>"><?= e($item["Phone"]) ?></a></p>
                        <p><span>Email</span> <a href="mailto:<?= e($item["Email"]) ?>"><?= e($item["Email"]) ?></a></p>
                    </div>
                </div>
                <?php } else if($item["Status"] == "Active") { ?>
                <p class="text-body-secondary small mt-3 mb-0"><?= e($item["Username"]) ?> prefers to be contacted by private message.</p>
                <?php } ?>
            </section>

            <section class="panel flag-box">
                <button type="button" class="btn btn-link flag-toggle" data-bs-toggle="collapse" data-bs-target="#flag-form" aria-expanded="false" aria-controls="flag-form">🚩 Report this post to admins</button>

                <div id="flag-form" class="collapse">
                    <form method="post" action="<?= url($base . "/flag") ?>" class="js-validate mt-3">
                        <?= csrf_field() ?>
                        <input type="text" class="form-control mb-3" name="reason" maxlength="255" placeholder="What's wrong with it? (spam, fake, offensive…)" aria-label="Reason" data-required="Tell the admins what's wrong">
                        <button type="submit" class="btn btn-danger-ghost btn-sm">Send report</button>
                    </form>
                </div>
            </section>

            <?php } ?>

            <section class="panel safety-box">
                <h2>Stay safe</h2>
                <ul class="mb-2">
                    <li>Ask for proof before you meet.</li>
                    <li>Meet in a public place, in daylight.</li>
                    <li>Never pay a fee or deposit in advance.</li>
                </ul>
                <a href="<?= url("safety") ?>" class="text-link">All safety tips →</a>
            </section>

        </aside>

    </div>

    <?php if(count($matches) > 0) { ?>
    <section class="panel mt-4">
        <div class="section-header">
            <h2>Possible matches ✨</h2>
            <span class="text-body-secondary"><?= $is_lost ? "Found reports that look like this" : "Lost reports that look like this" ?></span>
        </div>

        <div class="item-grid">
            <?php foreach($matches as $match) { View::partial("partials/item_card", ["item" => $match, "score" => $match["Score"]]); } ?>
        </div>
    </section>
    <?php } ?>

</div>

<?php if($is_owner && $item["Status"] == "Active") { ?>
<!-- Resolve dialog: optional thank-you note shown on the Reunited wall -->
<div class="modal fade" id="resolveModal" tabindex="-1" aria-labelledby="resolveModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form method="post" action="<?= url($base . "/resolve") ?>" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h2 class="modal-title fs-5" id="resolveModalTitle">Mark as resolved</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Good news! Want to leave a short note? It appears on this report and on the Reunited wall.</p>
                <label for="resolve-note" class="form-label">Thank-you note (optional)</label>
                <textarea class="form-control" id="resolve-note" name="note" rows="3" maxlength="500" placeholder="e.g. A rickshaw puller found it and called me the same evening. Thank you!"></textarea>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-found">Mark as resolved</button>
            </div>
        </form>
    </div>
</div>
<?php } ?>
