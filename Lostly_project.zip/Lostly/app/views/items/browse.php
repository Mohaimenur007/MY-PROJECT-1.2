<?php
// Link to another page of results, keeping every filter.
$page_link = function ($number) use ($filters) {
    return e(url("items", array_filter($filters, "strlen") + ["page" => $number]));
};
?>
<div class="container-xl page">

    <section class="page-hero">
        <p class="eyebrow">Community board</p>
        <h1>Browse Lost &amp; Found</h1>
        <p>Search for an item, check reports from your area, and connect with the person who posted it.</p>
    </section>

    <form method="get" action="<?= url("items") ?>" class="panel filter-bar">
        <div class="row g-3">
            <div class="col-md-8 col-lg-9">
                <input type="search" class="form-control" name="search" placeholder="Search item, description, location or LF number…" value="<?= e($filters["search"]) ?>" aria-label="Search">
            </div>

            <div class="col-md-4 col-lg-3 d-flex gap-3">
                <button type="submit" class="btn btn-ink flex-grow-1">Search</button>
                <a href="<?= url("items") ?>" class="btn btn-ghost" title="Clear filters">Reset</a>
            </div>

            <div class="col-6 col-md-4 col-lg">
                <select class="form-select" name="type" aria-label="Type">
                    <option value="">All Types</option>
                    <option value="Lost" <?= selected($filters["type"], "Lost") ?>>Lost</option>
                    <option value="Found" <?= selected($filters["type"], "Found") ?>>Found</option>
                </select>
            </div>

            <div class="col-6 col-md-4 col-lg">
                <select class="form-select" name="division" aria-label="Division">
                    <option value="">All Divisions</option>
                    <?php foreach(config("divisions") as $div) { ?>
                    <option value="<?= e($div) ?>" <?= selected($filters["division"], $div) ?>><?= e($div) ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="col-6 col-md-4 col-lg">
                <select class="form-select" name="category" aria-label="Category">
                    <option value="">All Categories</option>
                    <?php foreach(config("categories") as $cat) { ?>
                    <option value="<?= e($cat) ?>" <?= selected($filters["category"], $cat) ?>><?= e($cat) ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="col-6 col-md-4 col-lg">
                <select class="form-select" name="status" aria-label="Status">
                    <option value="Active" <?= selected($filters["status"], "Active") ?>>Active only</option>
                    <option value="Resolved" <?= selected($filters["status"], "Resolved") ?>>Resolved only</option>
                    <option value="All" <?= selected($filters["status"], "All") ?>>Active + resolved</option>
                </select>
            </div>

            <div class="col-6 col-md-4 col-lg">
                <select class="form-select" name="sort" aria-label="Sort by">
                    <option value="newest" <?= selected($filters["sort"], "newest") ?>>Newest first</option>
                    <option value="oldest" <?= selected($filters["sort"], "oldest") ?>>Oldest first</option>
                    <option value="date" <?= selected($filters["sort"], "date") ?>>Latest lost/found date</option>
                    <option value="popular" <?= selected($filters["sort"], "popular") ?>>Most viewed</option>
                </select>
            </div>
        </div>
    </form>

    <?php if($filters["search"] . $filters["type"] . $filters["division"] . $filters["category"] != "") { ?>
    <form method="post" action="<?= url("alerts/searches") ?>" class="save-search">
        <?= csrf_field() ?>
        <input type="hidden" name="keyword" value="<?= e($filters["search"]) ?>">
        <input type="hidden" name="type" value="<?= e($filters["type"]) ?>">
        <input type="hidden" name="division" value="<?= e($filters["division"]) ?>">
        <input type="hidden" name="category" value="<?= e($filters["category"]) ?>">
        <span>Not here yet?</span>
        <button type="submit" class="btn btn-ghost btn-sm">🔔 Alert me about new reports like this</button>
    </form>
    <?php } ?>

    <?php if($total == 0) { ?>

    <div class="empty">
        <span class="empty-icon">🔍</span>
        <h2>No items found</h2>
        <p>Try a different keyword or remove one of the filters.</p>
    </div>

    <?php } else { ?>

    <p class="browse-summary">
        <b><?= $total ?></b> report<?= $total == 1 ? "" : "s" ?> · page <?= $current ?> of <?= $pages ?>
    </p>

    <div class="item-grid">
        <?php foreach($items as $item) { View::partial("partials/item_card", ["item" => $item]); } ?>
    </div>

    <?php if($pages > 1) { ?>
    <nav aria-label="Pages" class="mt-5">
        <ul class="pagination justify-content-center flex-wrap">
            <li class="page-item <?= $current == 1 ? "disabled" : "" ?>">
                <a class="page-link" href="<?= $page_link(max(1, $current - 1)) ?>">← Prev</a>
            </li>

            <?php for($i = 1; $i <= $pages; $i++) { ?>
                <?php if($i == 1 || $i == $pages || abs($i - $current) <= 2) { ?>
                <li class="page-item <?= $i == $current ? "active" : "" ?>">
                    <a class="page-link" href="<?= $page_link($i) ?>" <?= $i == $current ? 'aria-current="page"' : "" ?>><?= $i ?></a>
                </li>
                <?php } else if(abs($i - $current) == 3) { ?>
                <li class="page-item disabled"><span class="page-link">…</span></li>
                <?php } ?>
            <?php } ?>

            <li class="page-item <?= $current == $pages ? "disabled" : "" ?>">
                <a class="page-link" href="<?= $page_link(min($pages, $current + 1)) ?>">Next →</a>
            </li>
        </ul>
    </nav>
    <?php } ?>

    <?php } ?>

</div>
