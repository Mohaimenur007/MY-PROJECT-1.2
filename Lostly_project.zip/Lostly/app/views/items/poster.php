<?php
// A printable A4 poster for the owner's report. Stands alone (no site layout).
$is_lost = $item["Type"] == "Lost";
$link = absolute_url("items/" . (int)$item["ID"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title><?= e($item["Type"]) ?>: <?= e($item["ItemName"]) ?> · Lostly poster</title>
<link rel="icon" type="image/svg+xml" href="<?= e(asset("favicon.svg")) ?>">
<style>
    * { box-sizing: border-box; }
    body { margin: 0; padding: 24px; background: #e9e4d8; color: #15130f; font-family: "Segoe UI", system-ui, -apple-system, Arial, sans-serif; }
    .toolbar { max-width: 210mm; margin: 0 auto 16px; display: flex; gap: 10px; justify-content: space-between; align-items: center; flex-wrap: wrap; }
    .toolbar a { color: #15130f; font-weight: 700; }
    .toolbar button { font: inherit; font-weight: 700; padding: 10px 20px; background: #15130f; color: #fff; border: 0; border-radius: 10px; cursor: pointer; }
    .poster-sheet { max-width: 210mm; min-height: 280mm; margin: 0 auto; padding: 14mm; background: #fff; border: 3px solid #15130f; display: flex; flex-direction: column; text-align: center; }
    .banner { font-size: 30mm; font-weight: 900; letter-spacing: 0.04em; line-height: 1; padding: 6mm 0; color: #fff; background: <?= $is_lost ? "#e0321a" : "#108a50" ?>; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    h1 { font-size: 13mm; line-height: 1.05; margin: 8mm 0 4mm; overflow-wrap: anywhere; }
    .photo { margin: 0 auto 6mm; max-width: 100%; max-height: 95mm; border: 2px solid #15130f; }
    .facts { display: grid; grid-template-columns: 1fr 1fr; gap: 4mm; margin: 2mm 0 6mm; text-align: left; }
    .facts div { border: 2px solid #15130f; padding: 3mm 4mm; }
    .facts span { display: block; font-size: 3.2mm; text-transform: uppercase; letter-spacing: 0.08em; color: #555; }
    .facts strong { font-size: 5.2mm; overflow-wrap: anywhere; }
    .description { font-size: 5mm; line-height: 1.4; margin: 0 0 6mm; overflow-wrap: anywhere; }
    .reward { font-size: 9mm; font-weight: 900; margin: 0 0 6mm; padding: 3mm; background: #ffd23f; border: 2px solid #15130f; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .contact { margin-top: auto; border-top: 3px dashed #15130f; padding-top: 6mm; }
    .contact p { margin: 0 0 2mm; font-size: 5mm; }
    .contact .phone { font-size: 13mm; font-weight: 900; letter-spacing: 0.02em; }
    .contact small { display: block; font-size: 3.6mm; color: #444; overflow-wrap: anywhere; }
    @page { size: A4; margin: 8mm; }
    @media print {
        body { padding: 0; background: #fff; }
        .toolbar { display: none; }
        .poster-sheet { border: 0; max-width: none; min-height: 0; height: 277mm; padding: 6mm; }
    }
</style>
</head>
<body>

<div class="toolbar">
    <a href="<?= url("items/" . (int)$item["ID"]) ?>">← Back to the report</a>
    <button type="button" onclick="window.print()">Print poster</button>
</div>

<div class="poster-sheet">
    <div class="banner"><?= $is_lost ? "LOST" : "FOUND" ?></div>

    <h1><?= e($item["ItemName"]) ?></h1>

    <?php if($item["ImagePath"]) { ?>
    <img class="photo" src="<?= e(asset($item["ImagePath"])) ?>" alt="<?= e($item["ItemName"]) ?>">
    <?php } ?>

    <div class="facts">
        <div><span><?= $is_lost ? "Last seen" : "Found at" ?></span><strong><?= e($item["District"]) ?>, <?= e($item["Division"]) ?></strong></div>
        <div><span>Date</span><strong><?= date("F j, Y", strtotime($item["EventDate"])) ?></strong></div>
    </div>

    <?php if($item["Description"]) { ?>
    <p class="description"><?= nl2br(e(shorten($item["Description"], 400))) ?></p>
    <?php } ?>

    <?php if($is_lost && !empty($item["Reward"])) { ?>
    <p class="reward">REWARD <?= taka($item["Reward"]) ?></p>
    <?php } ?>

    <div class="contact">
        <p><?= $is_lost ? "If you have seen or found it, please call" : "If this is yours, please call" ?> <b><?= e($owner["Username"]) ?></b></p>
        <p class="phone"><?= e($owner["Phone"]) ?></p>
        <small>or search <b><?= Item::code($item["ID"]) ?></b> on Lostly · <?= e($link) ?></small>
    </div>
</div>

</body>
</html>
