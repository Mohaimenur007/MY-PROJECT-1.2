<div class="container-xl page">

    <section class="page-hero">
        <p class="eyebrow">Watchlist</p>
        <h1>Saved reports</h1>
        <p>Reports you are keeping an eye on. You get an alert when one of them is resolved.</p>
    </section>

    <?php if(count($items) == 0) { ?>

    <div class="empty">
        <span class="empty-icon">🔖</span>
        <h2>Nothing saved yet</h2>
        <p>Open any report and press “Save” to keep it here.</p>
        <a href="<?= url("items") ?>" class="btn btn-ink mt-2">Browse the board</a>
    </div>

    <?php } else { ?>

    <div class="item-grid">
        <?php foreach($items as $item) { View::partial("partials/item_card", ["item" => $item]); } ?>
    </div>

    <?php } ?>

</div>
