<?php $edit = $id > 0; ?>
<div class="container-xl page page-narrow">

    <section class="page-hero">
        <p class="eyebrow"><?= $edit ? "Edit notice" : "New notice" ?></p>
        <h1><?= $edit ? "Edit your report" : "Pin a new notice" ?></h1>
        <p>The more detail you give, the better Lostly can match it with other reports.</p>
    </section>

    <form method="post" action="<?= url($edit ? "items/" . (int)$id : "items") ?>" enctype="multipart/form-data" class="panel js-validate">
        <?= csrf_field() ?>

        <span class="form-label d-block">What happened?</span>
        <div class="row g-3 mb-4">
            <div class="col-sm-6">
                <input type="radio" class="btn-check" name="type" id="type-lost" value="Lost" <?= $data["type"] == "Lost" ? "checked" : "" ?>>
                <label class="type-option type-lost" for="type-lost"><b>I lost it</b><small>Let others help you find it</small></label>
            </div>
            <div class="col-sm-6">
                <input type="radio" class="btn-check" name="type" id="type-found" value="Found" <?= $data["type"] == "Found" ? "checked" : "" ?>>
                <label class="type-option type-found" for="type-found"><b>I found it</b><small>Help return it to its owner</small></label>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-12">
                <label for="item_name" class="form-label">Item name</label>
                <input type="text" class="form-control" id="item_name" name="item_name" maxlength="100" placeholder="e.g. Black leather wallet" value="<?= e($data["item_name"]) ?>" data-required="Enter the item name">
            </div>

            <div class="col-md-6">
                <label for="category" class="form-label">Category</label>
                <select class="form-select" id="category" name="category" data-required="Select a valid category">
                    <option value="">Select Category</option>
                    <?php foreach(config("categories") as $cat) { ?>
                    <option value="<?= e($cat) ?>" <?= selected($data["category"], $cat) ?>><?= e($cat) ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="col-md-6">
                <label for="event_date" class="form-label">Date it happened</label>
                <input type="date" class="form-control" id="event_date" name="event_date" max="<?= date("Y-m-d") ?>" value="<?= e($data["event_date"]) ?>" data-required="Select a date">
            </div>

            <div class="col-md-6">
                <label for="division" class="form-label">Division</label>
                <select class="form-select" id="division" name="division" data-required="Select a valid division">
                    <option value="">Select Division</option>
                    <?php foreach(config("divisions") as $div) { ?>
                    <option value="<?= e($div) ?>" <?= selected($data["division"], $div) ?>><?= e($div) ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="col-md-6">
                <label for="district" class="form-label">District / area</label>
                <input type="text" class="form-control" id="district" name="district" maxlength="50" list="district-list" value="<?= e($data["district"]) ?>" data-required="Enter a district" autocomplete="off">
                <?php View::partial("partials/district_list"); ?>
            </div>

            <div class="col-md-6 js-reward-field" <?= $data["type"] == "Found" ? "hidden" : "" ?>>
                <label for="reward" class="form-label">Reward in taka (optional)</label>
                <div class="input-group">
                    <span class="input-group-text">৳</span>
                    <input type="number" class="form-control" id="reward" name="reward" min="1" max="10000000" step="1" inputmode="numeric" placeholder="e.g. 2000" value="<?= e($data["reward"]) ?>">
                </div>
            </div>

            <div class="col-12">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="4" maxlength="2000" placeholder="Colour, brand, marks, where exactly…"><?= e($data["description"]) ?></textarea>
            </div>

            <div class="col-12">
                <label for="photos" class="form-label">Photos (optional · up to <?= config("max_photos") ?> · JPG, PNG or WEBP · max 5MB each)</label>

                <?php if(count($photos) > 0) { ?>
                <div class="photo-manage">
                    <?php foreach($photos as $index => $path) { ?>
                    <label class="photo-manage-item">
                        <img src="<?= e(asset($path)) ?>" alt="Photo <?= $index + 1 ?>">
                        <?php if($index == 0) { ?><span class="photo-cover">Cover</span><?php } ?>
                        <span class="form-check">
                            <input class="form-check-input" type="checkbox" name="remove_photos[]" value="<?= $index ?>">
                            <span class="form-check-label">Remove</span>
                        </span>
                    </label>
                    <?php } ?>
                </div>
                <?php } ?>

                <div class="upload-drop">
                    <input type="file" class="form-control js-photos-input" id="photos" name="photos[]" multiple accept="image/png, image/jpeg, image/webp" data-max="<?= config("max_photos") ?>" data-preview="photo-previews">
                    <div id="photo-previews" class="photo-previews"></div>
                </div>
            </div>
        </div>

        <?php if($error != "") { ?>
        <div class="alert alert-lost form-message mt-3" role="alert"><?= e($error) ?></div>
        <?php } ?>

        <div class="d-flex flex-wrap justify-content-end gap-3 mt-4 form-actions">
            <a href="<?= url($edit ? "items/" . (int)$id : "dashboard") ?>" class="btn btn-ghost">Cancel</a>
            <button type="submit" class="btn btn-ink"><?= $edit ? "Save changes" : "Post notice" ?></button>
        </div>
    </form>

</div>
