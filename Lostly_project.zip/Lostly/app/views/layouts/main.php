<?php

// Shared page layout. $content is the rendered view; $page_title and $page come from the controller.

$page_title = isset($page_title) ? $page_title : "Lostly";
$page = isset($page) ? $page : "";
$page_description = isset($page_description) ? $page_description : "Lostly — the lost and found notice board for Bangladesh.";
$page_image = !empty($page_image) ? $page_image : "";
$announcement = Setting::get("announcement");
$me = Auth::user();
$unread_messages = $me ? Message::unreadCount($me["ID"]) : 0;
$unread_alerts = $me ? Notification::unreadCount($me["ID"]) : 0;
$active = function ($name) use ($page) { return $name == $page ? " active" : ""; };

?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title) ?> · Lostly</title>
<meta name="description" content="<?= e($page_description) ?>">
<meta property="og:site_name" content="Lostly">
<meta property="og:title" content="<?= e($page_title) ?> · Lostly">
<meta property="og:description" content="<?= e($page_description) ?>">
<meta property="og:type" content="website">
<?php if($page_image != "") { ?>
<meta property="og:image" content="<?= e(absolute_asset($page_image)) ?>">
<?php } ?>
<meta name="theme-color" content="#ffd23f">
<link rel="icon" type="image/svg+xml" href="<?= e(asset("favicon.svg")) ?>">
<script>
// Apply the saved theme before the page paints (no flash of the wrong theme).
(function () {
    // Tells the stylesheet that JavaScript is running, so scroll animations can start hidden.
    document.documentElement.classList.add("js");
    try {
        var saved = localStorage.getItem("lostly-theme");
        if (!saved && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) { saved = "dark"; }
        if (saved === "dark" || saved === "light") { document.documentElement.setAttribute("data-bs-theme", saved); }
    } catch (err) {}
})();
</script>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=DM+Sans:wght@400;500;700&family=Space+Mono:wght@400;700&display=swap" rel="stylesheet">
<!-- Bootstrap 5 from the CDN; if you are offline it falls back to the copy in vendor/. -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      onerror="this.onerror=null;this.href='<?= e(asset("vendor/bootstrap/bootstrap-fallback.min.css")) ?>';">
<link rel="stylesheet" href="<?= asset("css/style.css") ?>">
</head>
<body data-page="<?= e($page) ?>">

<nav class="navbar navbar-expand-lg sticky-top lostly-nav">
    <div class="container-xl">
        <a href="<?= url("") ?>" class="navbar-brand logo">
            <span class="logo-pin"></span>Lostly
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav"
                aria-controls="mainNav" aria-expanded="false" aria-label="Toggle menu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-1">
                <?php if($me) { ?>
                <li class="nav-item"><a class="nav-link<?= $active("dashboard") ?>" href="<?= url("dashboard") ?>">Dashboard</a></li>
                <?php } ?>

                <li class="nav-item"><a class="nav-link<?= $active("browse") ?>" href="<?= url("items") ?>">Browse</a></li>
                <li class="nav-item"><a class="nav-link<?= $active("reunited") ?>" href="<?= url("reunited") ?>">Reunited</a></li>

                <?php if($me) { ?>

                <li class="nav-item">
                    <a class="nav-link<?= $active("messages") ?>" href="<?= url("messages") ?>">
                        Messages<?php if($unread_messages > 0) { ?> <span class="badge rounded-pill badge-count"><?= $unread_messages ?></span><?php } ?>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link<?= $active("alerts") ?>" href="<?= url("alerts") ?>">
                        Alerts<?php if($unread_alerts > 0) { ?> <span class="badge rounded-pill badge-count"><?= $unread_alerts ?></span><?php } ?>
                    </a>
                </li>
                <?php if(Auth::isAdmin()) { ?>
                <li class="nav-item"><a class="nav-link<?= $active("admin") ?>" href="<?= url("admin") ?>">Admin</a></li>
                <?php } ?>
                <li class="nav-item"><a class="btn btn-warn btn-sm nav-cta" href="<?= url("items/new") ?>">+ Report</a></li>
                <li class="nav-item">
                    <button type="button" class="theme-toggle js-theme-toggle" aria-label="Switch light and dark theme"></button>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Account menu">
                        <span class="avatar avatar-sm"><?= e(initial($me["Username"])) ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><span class="dropdown-item-text small text-body-secondary">Signed in as <b><?= e($me["Username"]) ?></b></span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?= url("members/" . (int)$me["ID"]) ?>">My public profile</a></li>
                        <li><a class="dropdown-item" href="<?= url("saved") ?>">Saved reports</a></li>
                        <li><a class="dropdown-item" href="<?= url("profile") ?>">Account settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="post" action="<?= url("logout") ?>">
                                <?= csrf_field() ?>
                                <button type="submit" class="dropdown-item">Logout</button>
                            </form>
                        </li>
                    </ul>
                </li>

                <?php } else { ?>

                <li class="nav-item"><a class="nav-link<?= $active("safety") ?>" href="<?= url("safety") ?>">Safety</a></li>
                <li class="nav-item"><a class="nav-link<?= $active("login") ?>" href="<?= url("login") ?>">Login</a></li>
                <li class="nav-item"><a class="btn btn-warn btn-sm nav-cta" href="<?= url("register") ?>">Join free</a></li>
                <li class="nav-item">
                    <button type="button" class="theme-toggle js-theme-toggle" aria-label="Switch light and dark theme"></button>
                </li>

                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<?php if($announcement != "") { ?>
<div class="announcement" role="status">
    <div class="container-xl">📣 <?= e($announcement) ?></div>
</div>
<?php } ?>

<!-- Flash messages as Bootstrap toasts -->
<div class="toast-container position-fixed end-0 p-3 lostly-toasts" aria-live="polite">
    <?php foreach(take_flashes() as $flash_item) { ?>
    <div class="toast show lostly-toast toast-<?= e($flash_item["type"]) ?>" role="alert" data-bs-delay="5000">
        <div class="d-flex">
            <div class="toast-body"><?= e($flash_item["message"]) ?></div>
            <button type="button" class="btn-close me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    </div>
    <?php } ?>
</div>

<main>
<?= $content ?>
</main>

<footer class="site-footer">
    <div class="container-xl">
        <div class="row gy-4">
            <div class="col-lg-4">
                <span class="logo small"><span class="logo-pin"></span>Lostly</span>
                <p class="mt-2 mb-0 footer-about">The lost and found notice board for Bangladesh. Free to use, run by the community.</p>
            </div>

            <div class="col-6 col-md-4 col-lg-2">
                <h2 class="footer-title">Platform</h2>
                <ul class="footer-links">
                    <li><a href="<?= url("items") ?>">Browse reports</a></li>
                    <li><a href="<?= url("items/new") ?>">Report an item</a></li>
                    <li><a href="<?= url("reunited") ?>">Reunited</a></li>
                </ul>
            </div>

            <div class="col-6 col-md-4 col-lg-2">
                <h2 class="footer-title">Help</h2>
                <ul class="footer-links">
                    <li><a href="<?= url("faq") ?>">Questions &amp; answers</a></li>
                    <li><a href="<?= url("safety") ?>">Safety tips</a></li>
                    <li><a href="<?= url("contact") ?>">Contact</a></li>
                </ul>
            </div>

            <div class="col-6 col-md-4 col-lg-2">
                <h2 class="footer-title">Lostly</h2>
                <ul class="footer-links">
                    <li><a href="<?= url("about") ?>">About</a></li>
                    <li><a href="<?= url("terms") ?>">Terms of use</a></li>
                    <li><a href="<?= url("privacy") ?>">Privacy</a></li>
                </ul>
            </div>

            <div class="col-6 col-md-12 col-lg-2">
                <h2 class="footer-title">Emergency</h2>
                <ul class="footer-links">
                    <li>National helpline <b>999</b></li>
                    <li>Lost documents? File a GD at your nearest police station.</li>
                </ul>
            </div>
        </div>

        <div class="footer-bottom">
            <span>© <?= date("Y") ?> Lostly · Group 6</span>
            <span>Made in Bangladesh</span>
        </div>
    </div>
</footer>

<!-- One shared "are you sure?" dialog (Bootstrap modal) for every destructive form -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title fs-5" id="confirmModalTitle">Are you sure?</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body js-confirm-text"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-lost js-confirm-yes">Yes, continue</button>
            </div>
        </div>
    </div>
</div>

<script src="<?= asset("vendor/bootstrap/bootstrap.bundle.min.js") ?>"></script>
<script src="<?= asset("js/main.js") ?>"></script>
</body>
</html>
