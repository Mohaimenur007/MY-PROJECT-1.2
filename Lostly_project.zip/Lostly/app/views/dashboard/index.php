<div class="container-xl page">

    <section class="page-hero">
        <p class="eyebrow">Your dashboard</p>
        <h1>Hey <?= e($me["Username"]) ?> 👋</h1>
        <p>Here's what's happening with your notices today.</p>

        <div class="d-flex flex-wrap gap-3 mt-3">
            <a href="<?= url("items/new", ["type" => "lost"]) ?>" class="btn btn-lost">I lost something</a>
            <a href="<?= url("items/new", ["type" => "found"]) ?>" class="btn btn-found">I found something</a>
            <a href="<?= url("items") ?>" class="btn btn-ghost">Browse the board</a>
        </div>
    </section>

    <?php View::partial("partials/stat_tiles", ["tiles" => [
        "reports posted" => $stats["total"],
        "still active" => $stats["active"],
        "resolved" => $stats["resolved"],
        "views on your notices" => $stats["views"]
    ]]); ?>

    <?php if(count($incoming_claims) > 0) { ?>
    <section class="panel panel-alert">
        <div class="section-header">
            <h2>Claims waiting for you <span class="badge rounded-pill badge-count"><?= count($incoming_claims) ?></span></h2>
        </div>

        <div class="list-rows">
            <?php foreach($incoming_claims as $claim) { ?>
            <div class="list-row">
                <div class="list-row-info">
                    <strong><?= e($claim["Username"]) ?></strong>
                    <span><?= $claim["Type"] == "Found" ? "says this is theirs" : "says they found it" ?> ·
                        <a href="<?= url("items/" . (int)$claim["ItemID"]) ?>"><?= e($claim["ItemName"]) ?></a></span>
                    <span class="quote">“<?= e($claim["Message"]) ?>”</span>
                </div>
                <div class="list-row-actions">
                    <a href="<?= url("items/" . (int)$claim["ItemID"]) ?>#claims" class="btn btn-ink btn-sm">Review</a>
                </div>
            </div>
            <?php } ?>
        </div>
    </section>
    <?php } ?>

    <?php if(count($match_groups) > 0) { ?>
    <section class="panel">
        <div class="section-header">
            <h2>Possible matches ✨</h2>
            <span class="text-body-secondary">Reports that look like yours</span>
        </div>

        <?php foreach($match_groups as $group) { ?>
        <p class="match-for">
            For your <?= strtolower($group["item"]["Type"]) ?> report
            <a href="<?= url("items/" . (int)$group["item"]["ID"]) ?>"><?= e($group["item"]["ItemName"]) ?></a>
        </p>

        <div class="item-grid">
            <?php foreach($group["matches"] as $match) { View::partial("partials/item_card", ["item" => $match, "score" => $match["Score"]]); } ?>
        </div>
        <?php } ?>
    </section>
    <?php } ?>

    <section class="panel">
        <div class="section-header">
            <h2>My reports</h2>
            <a href="<?= url("items/new") ?>" class="btn btn-ink btn-sm">+ New report</a>
        </div>

        <?php if(count($my_items) == 0) { ?>

        <div class="empty">
            <span class="empty-icon">📌</span>
            <p>You haven't pinned any notices yet.</p>
        </div>

        <?php } else { ?>

        <div class="list-rows">
            <?php foreach($my_items as $item) { ?>
            <div class="list-row">
                <div class="list-row-info">
                    <span>
                        <span class="badge rounded-pill badge-<?= strtolower($item["Type"]) ?>"><?= e($item["Type"]) ?></span>
                        <?php if($item["Status"] == "Resolved") { ?>
                        <span class="badge rounded-pill badge-resolved">Resolved</span>
                        <?php } ?>
                    </span>
                    <strong><?= e($item["ItemName"]) ?></strong>
                    <span><?= e($item["Category"]) ?> · <?= date("M j, Y", strtotime($item["EventDate"])) ?> · <?= (int)$item["Views"] ?> views</span>
                </div>

                <div class="list-row-actions">
                    <a href="<?= url("items/" . (int)$item["ID"]) ?>" class="btn btn-ghost btn-sm">View</a>
                    <a href="<?= url("items/" . (int)$item["ID"] . "/edit") ?>" class="btn btn-ghost btn-sm">Edit</a>
                    <form method="post" action="<?= url("items/" . (int)$item["ID"] . "/delete") ?>" class="d-inline js-confirm" data-confirm-message="Delete this report? This cannot be undone.">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-danger-ghost btn-sm">Delete</button>
                    </form>
                </div>
            </div>
            <?php } ?>
        </div>

        <?php } ?>
    </section>

    <div class="row g-4">

        <div class="col-lg-6">
            <section class="panel h-100">
                <div class="section-header">
                    <h2>Claims I sent</h2>
                </div>

                <?php if(count($my_claims) == 0) { ?>
                <p class="text-body-secondary">Nothing yet. Open a notice and press “Claim” if it's yours or you found it.</p>
                <?php } else { ?>
                <div class="list-rows">
                    <?php foreach($my_claims as $claim) { ?>
                    <div class="list-row">
                        <div class="list-row-info">
                            <strong><a href="<?= url("items/" . (int)$claim["ItemID"]) ?>"><?= e($claim["ItemName"]) ?></a></strong>
                            <span><?= time_ago($claim["CreatedAt"]) ?></span>
                        </div>
                        <span class="badge rounded-pill badge-<?= strtolower($claim["Status"]) ?>"><?= e($claim["Status"]) ?></span>
                    </div>
                    <?php } ?>
                </div>
                <?php } ?>
            </section>
        </div>

        <div class="col-lg-6">
            <section class="panel h-100">
                <div class="section-header">
                    <h2>Your information</h2>
                    <a href="<?= url("profile") ?>" class="btn btn-ghost btn-sm">Edit</a>
                </div>

                <div class="row row-cols-1 row-cols-sm-2 g-3">
                    <div class="col"><div class="info-item"><span>Username</span><strong><?= e($me["Username"]) ?></strong></div></div>
                    <div class="col"><div class="info-item"><span>Email</span><strong><?= e($me["Email"]) ?></strong></div></div>
                    <div class="col"><div class="info-item"><span>Phone</span><strong><?= e($me["Phone"]) ?></strong></div></div>
                    <div class="col"><div class="info-item"><span>Location</span><strong><?= e($me["District"]) ?>, <?= e($me["Division"]) ?></strong></div></div>
                </div>
            </section>
        </div>

    </div>

</div>
