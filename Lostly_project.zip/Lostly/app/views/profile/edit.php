<div class="container-xl page page-narrow">

    <section class="page-hero">
        <p class="eyebrow">Account settings</p>
        <h1>Edit Profile</h1>
        <p>Keep your contact and location details up to date so other users can reach you when needed.</p>
    </section>

    <form method="post" action="<?= url("profile") ?>" class="panel js-validate">
        <?= csrf_field() ?>

        <div class="profile-head">
            <span class="avatar avatar-lg"><?= e(initial($me["Username"])) ?></span>
            <div>
                <strong><?= e($me["Username"]) ?></strong>
                <span class="text-body-secondary"><?= Auth::isAdmin() ? "Administrator" : "Member" ?> · joined <?= date("M Y", strtotime($me["CreatedAt"])) ?></span>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-6">
                <label for="username" class="form-label">Username</label>
                <input type="text" class="form-control" id="username" name="username" maxlength="100" value="<?= e($old["username"]) ?>" data-required="Enter Username">
            </div>

            <div class="col-md-6">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" maxlength="150" value="<?= e($old["email"]) ?>" data-required="Enter Email">
            </div>

            <div class="col-md-6">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="phone" name="phone" maxlength="20" value="<?= e($old["phone"]) ?>" data-required="Enter Phone Number">
            </div>

            <div class="col-md-6">
                <label for="division" class="form-label">Division</label>
                <select class="form-select" id="division" name="division" data-required="Select Division">
                    <?php foreach(config("divisions") as $div) { ?>
                    <option value="<?= e($div) ?>" <?= selected($old["division"], $div) ?>><?= e($div) ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="col-12">
                <label for="district" class="form-label">District</label>
                <input type="text" class="form-control" id="district" name="district" maxlength="100" list="district-list" value="<?= e($old["district"]) ?>" data-required="Enter District" autocomplete="off">
                <?php View::partial("partials/district_list"); ?>
            </div>
        </div>

        <h2 class="sub-heading">Privacy</h2>

        <div class="form-check form-switch">
            <input class="form-check-input" type="checkbox" role="switch" id="show_contact" name="show_contact" value="1" <?= $old["show_contact"] ? "checked" : "" ?>>
            <label class="form-check-label plain-label" for="show_contact">
                Show my phone and email on my reports
                <small class="d-block text-body-secondary">Only logged-in members can see them. Switched off, people reach you through private messages.</small>
            </label>
        </div>

        <h2 class="sub-heading">Change password <span class="text-body-secondary fw-normal">(optional)</span></h2>

        <div class="row g-3">
            <div class="col-12">
                <label for="current_password" class="form-label">Current Password</label>
                <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Only needed to set a new password" autocomplete="current-password">
            </div>

            <div class="col-md-6">
                <label for="new_password" class="form-label">New Password</label>
                <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Leave blank to keep current" autocomplete="new-password">
            </div>

            <div class="col-md-6">
                <label for="confirm_password" class="form-label">Confirm New Password</label>
                <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Repeat new password" data-match="new_password" data-match-message="New passwords do not match" autocomplete="new-password">
            </div>
        </div>

        <?php if($error != "") { ?>
        <div class="alert alert-lost form-message mt-3" role="alert"><?= e($error) ?></div>
        <?php } ?>

        <div class="d-flex flex-wrap justify-content-end gap-3 mt-4 form-actions">
            <a href="<?= url("dashboard") ?>" class="btn btn-ghost">Cancel</a>
            <button type="submit" class="btn btn-ink">Save Changes</button>
        </div>
    </form>

</div>
