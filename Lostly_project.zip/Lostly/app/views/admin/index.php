<?php

// Draws a list of horizontal bars (Bootstrap progress) from rows of Label / Total.
$bar_list = function ($rows) {
    $max = 1;

    foreach($rows as $row)
    {
        $max = max($max, (int)$row["Total"]);
    }

    foreach($rows as $row)
    {
        ?>
        <div class="bar-row">
            <span class="bar-label"><?= e($row["Label"]) ?></span>
            <div class="progress flex-grow-1" role="progressbar" aria-label="<?= e($row["Label"]) ?>" aria-valuenow="<?= (int)$row["Total"] ?>" aria-valuemin="0" aria-valuemax="<?= $max ?>">
                <div class="progress-bar" style="width: <?= round($row["Total"] * 100 / $max) ?>%"></div>
            </div>
            <b><?= (int)$row["Total"] ?></b>
        </div>
        <?php
    }

    if(count($rows) == 0)
    {
        echo '<p class="text-body-secondary">No data yet.</p>';
    }
};

$tabs = ["overview" => "Overview", "items" => "Reports", "users" => "Members", "flags" => "Flags",
         "inbox" => "Inbox", "log" => "Activity log", "settings" => "Settings"];

?>
<div class="container-xl page">

    <section class="page-hero">
        <p class="eyebrow">Control room</p>
        <h1>Admin panel</h1>
        <p>Keep the board clean: review flagged posts, remove spam and manage members.</p>
    </section>

    <ul class="nav nav-pills admin-tabs">
        <?php foreach($tabs as $key => $label) { ?>
        <li class="nav-item">
            <a class="nav-link <?= $tab == $key ? "active" : "" ?>" href="<?= url("admin", ["tab" => $key]) ?>" <?= $tab == $key ? 'aria-current="page"' : "" ?>>
                <?= $label ?><?php if($key == "flags" && $open_flags > 0) { ?> <span class="badge rounded-pill badge-count"><?= $open_flags ?></span><?php } ?><?php if($key == "inbox" && $unread_inbox > 0) { ?> <span class="badge rounded-pill badge-count"><?= $unread_inbox ?></span><?php } ?>
            </a>
        </li>
        <?php } ?>
    </ul>

<?php if($tab == "overview") { ?>

    <?php View::partial("partials/stat_tiles", ["tiles" => $totals, "cols" => "row-cols-2 row-cols-md-3 row-cols-xl-6"]); ?>

    <div class="row g-4">

        <div class="col-lg-6">
            <section class="panel h-100">
                <h2>Reports in the last 7 days</h2>

                <?php $days_max = max(1, max($days)); ?>
                <div class="day-chart">
                    <?php foreach($days as $day => $count) { ?>
                    <div class="day-col" title="<?= $count ?> report<?= $count == 1 ? "" : "s" ?> on <?= date("M j", strtotime($day)) ?>">
                        <b><?= $count ?></b>
                        <span class="day-bar"><i style="height: <?= round($count * 100 / $days_max) ?>%"></i></span>
                        <small><?= date("D", strtotime($day)) ?></small>
                    </div>
                    <?php } ?>
                </div>
            </section>
        </div>

        <div class="col-lg-6">
            <section class="panel h-100">
                <h2>Lost vs found</h2>

                <div class="progress progress-stacked split-bar" title="<?= $lost_count ?> lost, <?= $found_count ?> found">
                    <?php $all = max(1, $lost_count + $found_count); ?>
                    <div class="progress" role="progressbar" aria-label="Lost" aria-valuenow="<?= $lost_count ?>" aria-valuemin="0" aria-valuemax="<?= $all ?>" style="width: <?= $lost_count * 100 / $all ?>%">
                        <div class="progress-bar bar-lost"></div>
                    </div>
                    <div class="progress" role="progressbar" aria-label="Found" aria-valuenow="<?= $found_count ?>" aria-valuemin="0" aria-valuemax="<?= $all ?>" style="width: <?= $found_count * 100 / $all ?>%">
                        <div class="progress-bar bar-found"></div>
                    </div>
                </div>

                <p class="d-flex gap-4 mt-2">
                    <span><i class="dot dot-lost"></i> Lost <b><?= $lost_count ?></b></span>
                    <span><i class="dot dot-found"></i> Found <b><?= $found_count ?></b></span>
                </p>

                <h2 class="sub-heading">Resolution rate</h2>
                <div class="bar-row">
                    <div class="progress flex-grow-1 tall" role="progressbar" aria-label="Resolution rate" aria-valuenow="<?= $resolve_rate ?>" aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar bar-found" style="width: <?= $resolve_rate ?>%"></div>
                    </div>
                    <b><?= $resolve_rate ?>%</b>
                </div>
                <p class="text-body-secondary small mb-0"><?= $totals["Resolved"] ?> of <?= $totals["Reports"] ?> reports ended with the item back home.</p>
            </section>
        </div>

        <div class="col-lg-6">
            <section class="panel h-100">
                <h2>By category</h2>
                <?php $bar_list($by_category); ?>
            </section>
        </div>

        <div class="col-lg-6">
            <section class="panel h-100">
                <h2>By division</h2>
                <?php $bar_list($by_division); ?>
            </section>
        </div>

    </div>

<?php } else if($tab == "items") { ?>

    <form method="get" action="<?= url("admin") ?>" class="panel filter-bar">
        <input type="hidden" name="tab" value="items">
        <div class="input-group">
            <input type="search" class="form-control" name="q" placeholder="Search by item name or username…" value="<?= e($q) ?>" aria-label="Search reports">
            <button type="submit" class="btn btn-ink">Search</button>
        </div>
    </form>

    <section class="panel">
        <?php if(count($rows) == 0) { ?>
        <p class="text-body-secondary mb-0">No reports found.</p>
        <?php } ?>

        <div class="list-rows">
            <?php foreach($rows as $row) { ?>
            <div class="list-row">
                <div class="list-row-info">
                    <span>
                        <span class="badge rounded-pill badge-<?= strtolower($row["Type"]) ?>"><?= e($row["Type"]) ?></span>
                        <?php if($row["Status"] == "Resolved") { ?><span class="badge rounded-pill badge-resolved">Resolved</span><?php } ?>
                    </span>
                    <strong><?= e($row["ItemName"]) ?></strong>
                    <span>by <?= e($row["Username"]) ?> · <?= e($row["Category"]) ?> · <?= e($row["District"]) ?>, <?= e($row["Division"]) ?> · <?= time_ago($row["CreatedAt"]) ?></span>
                </div>

                <div class="list-row-actions">
                    <a href="<?= url("items/" . (int)$row["ID"]) ?>" class="btn btn-ghost btn-sm">View</a>
                    <form method="post" action="<?= url("admin/items/" . (int)$row["ID"] . "/delete") ?>" class="d-inline js-confirm" data-confirm-message="Remove this report for everyone? This cannot be undone.">
                        <?= csrf_field() ?>
                        <input type="hidden" name="tab" value="items">
                        <button type="submit" class="btn btn-danger-ghost btn-sm">Remove</button>
                    </form>
                </div>
            </div>
            <?php } ?>
        </div>
    </section>

<?php } else if($tab == "users") { ?>

    <section class="panel">
        <div class="list-rows">
            <?php foreach($rows as $row) { ?>
            <?php $is_admin = $row["Role"] == "admin"; ?>
            <div class="list-row">
                <span class="avatar"><?= e(initial($row["Username"])) ?></span>

                <div class="list-row-info">
                    <strong><a href="<?= url("members/" . (int)$row["ID"]) ?>"><?= e($row["Username"]) ?></a>
                        <?php if($is_admin) { ?><span class="badge rounded-pill badge-approved">Admin</span><?php } ?>
                        <?php if($row["IsBanned"]) { ?><span class="badge rounded-pill badge-rejected">Suspended</span><?php } ?>
                    </strong>
                    <span><?= e($row["Email"]) ?> · <?= e($row["Phone"]) ?></span>
                    <span><?= e($row["District"]) ?>, <?= e($row["Division"]) ?> · <?= (int)$row["ReportCount"] ?> report<?= $row["ReportCount"] == 1 ? "" : "s" ?></span>
                </div>

                <div class="list-row-actions">
                    <?php if($row["ID"] == Auth::id()) { ?>

                    <span class="text-body-secondary small">This is you</span>

                    <?php } else { ?>

                    <form method="post" action="<?= url("admin/users/" . (int)$row["ID"] . "/" . ($is_admin ? "demote" : "promote")) ?>" class="d-inline js-confirm"
                          data-confirm-message="<?= $is_admin ? "Remove admin rights from this member?" : "Give this member full admin rights?" ?>">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-ghost btn-sm"><?= $is_admin ? "Remove admin" : "Make admin" ?></button>
                    </form>

                    <?php if(!$is_admin) { ?>
                    <form method="post" action="<?= url("admin/users/" . (int)$row["ID"] . "/" . ($row["IsBanned"] ? "unban" : "ban")) ?>" class="d-inline js-confirm"
                          data-confirm-message="<?= $row["IsBanned"] ? "Let this member log in again?" : "Suspend this member? They will be logged out and their reports hidden." ?>">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm <?= $row["IsBanned"] ? "btn-found" : "btn-danger-ghost" ?>"><?= $row["IsBanned"] ? "Unsuspend" : "Suspend" ?></button>
                    </form>
                    <?php } ?>

                    <?php } ?>
                </div>
            </div>
            <?php } ?>
        </div>
    </section>

<?php } else if($tab == "flags") { ?>

    <section class="panel">
        <?php if(count($rows) == 0) { ?>
        <div class="empty">
            <span class="empty-icon">🛡️</span>
            <p>No open flags. The board is clean.</p>
        </div>
        <?php } ?>

        <div class="list-rows">
            <?php foreach($rows as $row) { ?>
            <div class="list-row">
                <div class="list-row-info">
                    <strong><?= e($row["ItemName"]) ?> <span class="text-body-secondary fw-normal">by <?= e($row["OwnerName"]) ?></span></strong>
                    <span class="quote">“<?= e($row["Reason"]) ?>”</span>
                    <span>flagged by <?= e($row["ReporterName"]) ?> · <?= time_ago($row["CreatedAt"]) ?></span>
                </div>

                <div class="list-row-actions">
                    <a href="<?= url("items/" . (int)$row["ItemID"]) ?>" class="btn btn-ghost btn-sm">View</a>

                    <form method="post" action="<?= url("admin/flags/" . (int)$row["FlagID"] . "/dismiss") ?>" class="d-inline">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-ghost btn-sm">Dismiss</button>
                    </form>

                    <form method="post" action="<?= url("admin/items/" . (int)$row["ItemID"] . "/delete") ?>" class="d-inline js-confirm" data-confirm-message="Remove this report for everyone? This cannot be undone.">
                        <?= csrf_field() ?>
                        <input type="hidden" name="tab" value="flags">
                        <button type="submit" class="btn btn-danger-ghost btn-sm">Remove post</button>
                    </form>
                </div>
            </div>
            <?php } ?>
        </div>
    </section>

<?php } else if($tab == "inbox") { ?>

    <section class="panel">
        <?php if(count($rows) == 0) { ?>
        <div class="empty">
            <span class="empty-icon">📭</span>
            <p>No messages from the Contact page yet.</p>
        </div>
        <?php } ?>

        <div class="list-rows">
            <?php foreach($rows as $row) { ?>
            <div class="list-row align-items-start <?= $row["IsRead"] ? "" : "unread" ?>">
                <span class="avatar"><?= e(initial($row["Name"])) ?></span>
                <div class="list-row-info">
                    <strong><?= e($row["Subject"]) ?> <?php if(!$row["IsRead"]) { ?><span class="badge rounded-pill badge-count">new</span><?php } ?></strong>
                    <span><?= e($row["Name"]) ?> · <a href="mailto:<?= e($row["Email"]) ?>"><?= e($row["Email"]) ?></a> · <?= time_ago($row["CreatedAt"]) ?></span>
                    <span class="tip-body"><?= nl2br(e($row["Body"])) ?></span>
                </div>
                <div class="list-row-actions">
                    <form method="post" action="<?= url("admin/inbox/" . (int)$row["ID"] . "/delete") ?>" class="d-inline js-confirm" data-confirm-message="Delete this message?">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-danger-ghost btn-sm">Delete</button>
                    </form>
                </div>
            </div>
            <?php } ?>
        </div>
    </section>

<?php } else if($tab == "log") { ?>

    <section class="panel">
        <?php if(count($rows) == 0) { ?>
        <p class="text-body-secondary mb-0">Nothing has been done in the admin panel yet.</p>
        <?php } else { ?>
        <div class="table-responsive">
            <table class="table log-table align-middle mb-0">
                <thead>
                    <tr><th scope="col">When</th><th scope="col">Admin</th><th scope="col">Action</th><th scope="col">Detail</th></tr>
                </thead>
                <tbody>
                    <?php foreach($rows as $row) { ?>
                    <tr>
                        <td class="text-nowrap"><?= date("M j, g:i a", strtotime($row["CreatedAt"])) ?></td>
                        <td><?= e($row["Username"]) ?></td>
                        <td><b><?= e($row["Action"]) ?></b></td>
                        <td class="text-break"><?= e($row["Detail"]) ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
        <?php } ?>
    </section>

<?php } else { ?>

    <div class="row g-4">
        <div class="col-lg-7">
            <form method="post" action="<?= url("admin/announcement") ?>" class="panel h-100">
                <?= csrf_field() ?>
                <h2>Announcement banner</h2>
                <p class="text-body-secondary">Shown at the top of every page to everyone. Leave it empty to remove the banner.</p>

                <label for="announcement" class="form-label">Message</label>
                <textarea class="form-control" id="announcement" name="announcement" rows="3" maxlength="300" placeholder="e.g. Lostly will be offline on Friday night from 11pm to 1am for maintenance."><?= e($announcement) ?></textarea>

                <div class="d-flex justify-content-end mt-3">
                    <button type="submit" class="btn btn-ink">Save</button>
                </div>
            </form>
        </div>

        <div class="col-lg-5">
            <section class="panel h-100">
                <h2>Export data</h2>
                <p class="text-body-secondary">Download every report as a CSV file that opens in Excel or Google Sheets.</p>
                <a href="<?= url("admin/export") ?>" class="btn btn-ghost">⬇ Download reports.csv</a>
            </section>
        </div>
    </div>

<?php } ?>

</div>
