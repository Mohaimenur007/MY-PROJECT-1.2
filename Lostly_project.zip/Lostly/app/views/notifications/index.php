<?php $icons = ["match" => "✨", "claim" => "🤝", "admin" => "🛡️", "tip" => "💡", "search" => "🔔", "saved" => "🔖"]; ?>
<div class="container-xl page page-narrow">

    <section class="page-hero">
        <p class="eyebrow">Alerts</p>
        <h1>What you missed</h1>
        <p>New matches, claims and decisions on your reports.</p>
    </section>

    <section class="panel">
        <?php if(count($list) == 0) { ?>

        <div class="empty">
            <span class="empty-icon">🔔</span>
            <p>You're all caught up.</p>
        </div>

        <?php } else { ?>

        <div class="section-header">
            <h2>Recent</h2>
            <form method="post" action="<?= url("alerts/clear") ?>" class="js-confirm" data-confirm-message="Clear all alerts?">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-ghost btn-sm">Clear all</button>
            </form>
        </div>

        <div class="list-rows">
            <?php foreach($list as $row) { ?>
            <a class="list-row list-row-link <?= $row["IsRead"] ? "" : "unread" ?>" href="<?= e(url($row["Link"])) ?>">
                <span class="avatar"><?= isset($icons[$row["Type"]]) ? $icons[$row["Type"]] : "🔔" ?></span>
                <div class="list-row-info">
                    <strong><?= e($row["Body"]) ?></strong>
                    <span><?= time_ago($row["CreatedAt"]) ?></span>
                </div>
                <?php if(!$row["IsRead"]) { ?><span class="badge rounded-pill badge-count">new</span><?php } ?>
            </a>
            <?php } ?>
        </div>

        <?php } ?>
    </section>

    <section class="panel" id="searches">
        <div class="section-header">
            <h2>Saved searches</h2>
            <a href="<?= url("items") ?>" class="btn btn-ghost btn-sm">+ Add from Browse</a>
        </div>

        <?php if(count($searches) == 0) { ?>
        <p class="text-body-secondary mb-0">Set filters or a keyword on the Browse page, then press “Alert me about new reports like this”. You'll get an alert here whenever a matching report is posted.</p>
        <?php } else { ?>
        <div class="list-rows">
            <?php foreach($searches as $search) { ?>
            <div class="list-row">
                <span class="avatar">🔔</span>
                <div class="list-row-info">
                    <strong><?= e(SearchAlert::describe($search)) ?></strong>
                    <span>saved <?= time_ago($search["CreatedAt"]) ?></span>
                </div>
                <div class="list-row-actions">
                    <a class="btn btn-ghost btn-sm" href="<?= e(url("items", array_filter(["search" => $search["Keyword"], "type" => $search["Type"], "category" => $search["Category"], "division" => $search["Division"]], "strlen"))) ?>">Run</a>
                    <form method="post" action="<?= url("alerts/searches/" . (int)$search["ID"] . "/delete") ?>" class="d-inline">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-danger-ghost btn-sm">Remove</button>
                    </form>
                </div>
            </div>
            <?php } ?>
        </div>
        <?php } ?>
    </section>

</div>
