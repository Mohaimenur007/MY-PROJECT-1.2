<div class="container-xl landing">

    <section class="row align-items-center gy-5 gx-lg-5 hero">
        <div class="col-lg-7">
            <p class="eyebrow">Lost &amp; found · all 8 divisions · 64 districts</p>
            <h1>Lost it?<br><span class="hl hl-lost">Post it.</span><br>Found it?<br><span class="hl hl-found">Return it.</span></h1>
            <p class="hero-sub">Lostly is the community notice board for Bangladesh. Report what you lost or found, get matched automatically, and chat safely with the other person.</p>

            <form method="get" action="<?= url("items") ?>" class="hero-search" role="search">
                <input type="search" class="form-control form-control-lg" name="search" placeholder="Try “wallet”, “Mirpur” or a reference like LF-00012" aria-label="Search reports">
                <button type="submit" class="btn btn-ink btn-lg">Search</button>
            </form>

            <div class="d-flex flex-wrap gap-3 mt-3">
                <a href="<?= url("items/new", ["type" => "lost"]) ?>" class="btn btn-lost">I lost something</a>
                <a href="<?= url("items/new", ["type" => "found"]) ?>" class="btn btn-found">I found something</a>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="hero-board" aria-hidden="true">
                <div class="poster poster-lost">
                    <span class="tape"></span>
                    <b>LOST</b>
                    <span class="poster-emoji">🐾</span>
                    <p>Grey cat, answers to "Tom"</p>
                    <small>Dhanmondi · Dhaka</small>
                </div>
                <div class="poster poster-found">
                    <span class="tape"></span>
                    <b>FOUND</b>
                    <span class="poster-emoji">🔑</span>
                    <p>Key ring with 3 keys</p>
                    <small>GEC Circle · Chattogram</small>
                </div>
                <div class="poster poster-match">
                    <span class="tape"></span>
                    <b>92% MATCH</b>
                    <span class="poster-emoji">🤝</span>
                    <p>We think these two belong together</p>
                </div>
            </div>
        </div>
    </section>

    <?php if(count($recent) > 0) { ?>
    <!-- Scrolling ticker of the newest notices (decorative: the same reports are listed below) -->
    <section class="ticker" aria-hidden="true">
        <div class="ticker-track">
            <?php for($loop = 0; $loop < 2; $loop++) { ?>
            <div class="ticker-group">
                <?php foreach($recent as $item) { ?>
                <span class="ticker-item">
                    <b class="ticker-<?= strtolower($item["Type"]) ?>"><?= e($item["Type"]) ?></b>
                    <?= e($item["ItemName"]) ?> · <?= e($item["District"]) ?>
                </span>
                <?php } ?>
            </div>
            <?php } ?>
        </div>
    </section>
    <?php } ?>

    <section>
        <?php View::partial("partials/stat_tiles", [
            "cols" => "row-cols-1 row-cols-md-3",
            "tiles" => ["reports posted" => $total_reports, "items reunited" => $total_resolved, "members helping" => $total_members]
        ]); ?>
    </section>

    <section>
        <div class="section-header">
            <h2 class="section-title mb-0">Browse by category</h2>
            <a href="<?= url("items") ?>" class="text-link">See all reports →</a>
        </div>

        <div class="row row-cols-2 row-cols-md-4 g-3">
            <?php foreach(config("categories") as $cat) { ?>
            <?php $n = isset($category_counts[$cat]) ? $category_counts[$cat] : 0; ?>
            <div class="col">
                <a class="category-tile" href="<?= e(url("items", ["category" => $cat])) ?>">
                    <span class="category-icon"><?= category_icon($cat) ?></span>
                    <strong><?= e($cat) ?></strong>
                    <small><?= $n ?> active report<?= $n == 1 ? "" : "s" ?></small>
                </a>
            </div>
            <?php } ?>
        </div>
    </section>

    <?php if(count($recent) > 0) { ?>
    <section>
        <div class="section-header">
            <h2 class="section-title mb-0">Fresh on the board</h2>
            <a href="<?= url("items") ?>" class="text-link">Browse everything →</a>
        </div>

        <div class="item-grid">
            <?php foreach($recent as $item) { View::partial("partials/item_card", ["item" => $item]); } ?>
        </div>
    </section>
    <?php } ?>

    <section>
        <h2 class="section-title">How it works</h2>
        <div class="row row-cols-1 row-cols-md-3 g-4">
            <div class="col">
                <div class="how-step h-100">
                    <span class="how-num">1</span>
                    <h3>Pin a notice</h3>
                    <p>Describe the item, add up to four photos and say where it happened. Lost something valuable? Add a reward.</p>
                </div>
            </div>
            <div class="col">
                <div class="how-step h-100">
                    <span class="how-num">2</span>
                    <h3>Get matched</h3>
                    <p>Lostly compares every lost report with every found report, and alerts you about matches and saved searches.</p>
                </div>
            </div>
            <div class="col">
                <div class="how-step h-100">
                    <span class="how-num">3</span>
                    <h3>Claim &amp; chat</h3>
                    <p>Send a claim with proof, message each other privately, and mark it resolved when it's home.</p>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="section-header">
            <h2 class="section-title mb-0">Where are you looking?</h2>
        </div>

        <div class="d-flex flex-wrap gap-2">
            <?php foreach(config("divisions") as $div) { ?>
            <a class="division-chip" href="<?= e(url("items", ["division" => $div])) ?>">
                📍 <?= e($div) ?> <b><?= isset($division_counts[$div]) ? $division_counts[$div] : 0 ?></b>
            </a>
            <?php } ?>
        </div>
    </section>

    <?php if(count($reunited) > 0) { ?>
    <section>
        <div class="section-header">
            <h2 class="section-title mb-0">Recently reunited</h2>
            <a href="<?= url("reunited") ?>" class="text-link">All reunited items →</a>
        </div>

        <div class="row row-cols-1 row-cols-md-3 g-4">
            <?php foreach($reunited as $item) { ?>
            <div class="col">
                <?php View::partial("partials/reunited_card", ["item" => $item]); ?>
            </div>
            <?php } ?>
        </div>
    </section>
    <?php } ?>

    <section class="row gy-4 gx-lg-5">
        <div class="col-lg-5">
            <h2 class="section-title">Questions people ask</h2>
            <p class="text-body-secondary">The short version. The <a href="<?= url("faq") ?>">full list is here</a>, and <a href="<?= url("safety") ?>">safety tips</a> are worth two minutes before you meet anyone.</p>
        </div>

        <div class="col-lg-7">
            <div class="accordion" id="homeFaq">
                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#faq1" aria-expanded="true" aria-controls="faq1">Does it cost anything?</button>
                    </h3>
                    <div id="faq1" class="accordion-collapse collapse show" data-bs-parent="#homeFaq">
                        <div class="accordion-body">No. Posting, searching, claiming and messaging are all free.</div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2" aria-expanded="false" aria-controls="faq2">Who can see my phone number?</button>
                    </h3>
                    <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#homeFaq">
                        <div class="accordion-body">Only logged-in members, and only if you leave “show my contact details” switched on in your account settings. With it off, people reach you through private messages.</div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h3 class="accordion-header">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3" aria-expanded="false" aria-controls="faq3">How do I know a claim is real?</button>
                    </h3>
                    <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#homeFaq">
                        <div class="accordion-body">Every claim must include proof in words: something only the owner or finder would know. You decide whether to approve it, and you can chat first.</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if(!Auth::check()) { ?>
    <section class="cta-band">
        <div>
            <h2>Lost or found something today?</h2>
            <p class="mb-0">It takes about a minute to pin a notice.</p>
        </div>
        <a href="<?= url("register") ?>" class="btn btn-ink btn-lg">Create free account</a>
    </section>
    <?php } ?>

</div>
