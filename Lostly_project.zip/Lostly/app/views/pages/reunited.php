<div class="container-xl page">

    <section class="page-hero">
        <p class="eyebrow">Back home</p>
        <h1>Reunited</h1>
        <p><?= $total ?> report<?= $total == 1 ? " has" : "s have" ?> been resolved on Lostly so far. These are the most recent.</p>
    </section>

    <?php if(count($items) == 0) { ?>

    <div class="empty">
        <span class="empty-icon">🤝</span>
        <h2>Nothing here yet</h2>
        <p>When a report is marked resolved it shows up on this wall.</p>
    </div>

    <?php } else { ?>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
        <?php foreach($items as $item) { ?>
        <div class="col">
            <?php View::partial("partials/reunited_card", ["item" => $item]); ?>
        </div>
        <?php } ?>
    </div>

    <?php } ?>

</div>
