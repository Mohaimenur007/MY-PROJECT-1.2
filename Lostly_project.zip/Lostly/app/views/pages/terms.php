<?php ob_start(); ?>
<p class="text-body-secondary">These terms describe how this project works today. If you run Lostly for the public, have them reviewed for your situation.</p>

<h2>1. Your account</h2>
<p>Give accurate details when you register and keep your password private. You are responsible for what is posted from your account.</p>

<h2>2. What you may post</h2>
<ul>
    <li>Real lost or found items only. No advertising, sales or unrelated posts.</li>
    <li>Photos you are allowed to share, with no private information about other people.</li>
    <li>No false claims on items that are not yours.</li>
</ul>

<h2>3. What Lostly does and does not do</h2>
<p>Lostly lets members find each other. It does not hold items, verify ownership or take part in handovers. Any reward is a private arrangement between members.</p>

<h2>4. Moderation</h2>
<p>Administrators may remove reports or tips and suspend accounts that break these rules. You can report a post from its page.</p>

<h2>5. Responsibility</h2>
<p>Meet and exchange items at your own risk and follow the <a href="<?= url("safety") ?>">safety tips</a>. Lostly is provided as it is, without guarantees that an item will be recovered.</p>

<h2>6. Changes</h2>
<p>These terms may be updated. Continuing to use Lostly after a change means you accept the new terms.</p>
<?php
View::partial("partials/prose_page", [
    "eyebrow" => "Legal",
    "heading" => "Terms of use",
    "intro" => "The rules for using Lostly, in plain language.",
    "body" => ob_get_clean()
]);
