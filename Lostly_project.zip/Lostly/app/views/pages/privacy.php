<?php ob_start(); ?>
<p class="text-body-secondary">This page describes what the software actually does. If you run Lostly for the public, have it reviewed for your situation.</p>

<h2>What we store</h2>
<ul>
    <li><b>Account:</b> username, email, phone number, division and district, and your password as a one-way hash (never the password itself).</li>
    <li><b>Reports:</b> the details and photos you post.</li>
    <li><b>Activity:</b> claims, tips, private messages, saved reports, saved searches and alerts.</li>
    <li><b>Contact form:</b> the name, email and message you send.</li>
</ul>

<h2>Who can see what</h2>
<ul>
    <li><b>Everyone:</b> your username, your reports and tips, and your public profile (join date and report counts).</li>
    <li><b>Logged-in members:</b> your phone and email on your reports, only while “show my contact details” is on.</li>
    <li><b>The other person in a conversation:</b> your private messages with them.</li>
    <li><b>Administrators:</b> account details and reports, in order to moderate the site.</li>
</ul>

<h2>Cookies</h2>
<p>Lostly uses one session cookie to keep you logged in. Your light or dark theme choice is stored in your own browser. There are no advertising or tracking cookies.</p>

<h2>Outside services</h2>
<p>Pages load fonts from Google Fonts and the Bootstrap stylesheet from the jsDelivr network, so those services receive your IP address when a page loads.</p>

<h2>Removing your information</h2>
<p>You can edit your account details and delete your reports at any time. To close your account completely, use the <a href="<?= url("contact") ?>">contact form</a>.</p>
<?php
View::partial("partials/prose_page", [
    "eyebrow" => "Legal",
    "heading" => "Privacy",
    "intro" => "What Lostly stores about you, who can see it and how to remove it.",
    "body" => ob_get_clean()
]);
