<div class="container-xl page page-narrow">

    <section class="page-hero">
        <p class="eyebrow">Contact</p>
        <h1>Send us a message</h1>
        <p>Questions, problems with a report, or a request to close your account. An administrator reads every message.</p>
    </section>

    <form method="post" action="<?= url("contact") ?>" class="panel js-validate">
        <?= csrf_field() ?>

        <!-- Hidden from people; bots that fill it in are ignored. -->
        <div class="visually-hidden" aria-hidden="true">
            <label for="website">Leave this empty</label>
            <input type="text" id="website" name="website" tabindex="-1" autocomplete="off">
        </div>

        <div class="row g-3">
            <div class="col-md-6">
                <label for="name" class="form-label">Your name</label>
                <input type="text" class="form-control" id="name" name="name" maxlength="100" value="<?= e($old["name"]) ?>" data-required="Enter your name">
            </div>

            <div class="col-md-6">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" maxlength="150" value="<?= e($old["email"]) ?>" data-required="Enter a valid email">
            </div>

            <div class="col-12">
                <label for="subject" class="form-label">Subject</label>
                <input type="text" class="form-control" id="subject" name="subject" maxlength="150" value="<?= e($old["subject"]) ?>" data-required="Enter a subject (up to 150 characters)">
            </div>

            <div class="col-12">
                <label for="message" class="form-label">Message</label>
                <textarea class="form-control" id="message" name="message" rows="6" maxlength="3000" data-required="Write a message of at least 10 characters" data-minlength="10" data-minlength-message="Write a message of at least 10 characters"><?= e($old["message"]) ?></textarea>
            </div>
        </div>

        <?php if($error != "") { ?>
        <div class="alert alert-lost form-message mt-3" role="alert"><?= e($error) ?></div>
        <?php } ?>

        <div class="d-flex justify-content-end mt-4 form-actions">
            <button type="submit" class="btn btn-ink">Send message</button>
        </div>
    </form>

</div>
