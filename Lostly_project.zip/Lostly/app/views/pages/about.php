<?php ob_start(); ?>
<h2>Why Lostly exists</h2>
<p>When something goes missing, the person who lost it and the person who found it usually have no way to reach each other. Posters only cover one street, and social media posts sink within a day. Lostly keeps every lost and found report in one searchable place, sorted by division and district.</p>

<h2>What you can do here</h2>
<ul>
    <li><b>Report</b> a lost or found item with photos, a location and a date.</li>
    <li><b>Search</b> every report without an account.</li>
    <li><b>Get matched</b>: Lostly compares lost and found reports and alerts both sides when two look alike.</li>
    <li><b>Claim</b> an item with proof, and let the reporter approve or reject it.</li>
    <li><b>Talk privately</b> without publishing your phone number.</li>
    <li><b>Print a poster</b> of your report for your neighbourhood.</li>
</ul>

<h2>Who runs it</h2>
<p>Lostly is built and maintained by Group 6 as a community project. It is free to use and carries no advertising.</p>

<p><a class="btn btn-ink" href="<?= url("items/new") ?>">Report an item</a> <a class="btn btn-ghost" href="<?= url("contact") ?>">Contact us</a></p>
<?php
View::partial("partials/prose_page", [
    "eyebrow" => "About",
    "heading" => "A notice board for a whole country",
    "intro" => "Lostly helps people in Bangladesh get their belongings back, and helps finders return what they pick up.",
    "body" => ob_get_clean()
]);
