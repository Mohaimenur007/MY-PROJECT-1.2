<?php ob_start(); ?>
<h2>Using Lostly</h2>
<h3>Do I need an account?</h3>
<p>Not to search or read reports. You need a free account to post a report, send a claim, leave a tip or message someone.</p>

<h3>Does it cost anything?</h3>
<p>No. Everything on Lostly is free.</p>

<h3>What is the LF number on a report?</h3>
<p>Every report has a reference such as <b>LF-00042</b>. Type it into the search box to jump straight to that report. It is also printed on the poster.</p>

<h2>Matching and alerts</h2>
<h3>How does matching work?</h3>
<p>Each lost report is scored against active found reports (and the other way round) using category, division, district, dates and shared words. Strong matches appear on your dashboard and on the report, and both people get an alert.</p>

<h3>Can I be told when something like my item is posted?</h3>
<p>Yes. Set filters or a keyword on the Browse page and press “Alert me about new reports like this”. You can keep up to ten saved searches.</p>

<h2>Claims</h2>
<h3>How do I claim an item?</h3>
<p>Open the report and send a claim describing your proof. The reporter approves or rejects it. Approving a claim marks the report resolved.</p>

<h3>What are “sightings &amp; tips”?</h3>
<p>Public notes anyone logged in can leave on a report, for example “I saw a cat like this near the lake on Friday”. The reporter is alerted.</p>

<h2>Privacy</h2>
<h3>Who can see my phone number and email?</h3>
<p>Only logged-in members, and only while “show my contact details on my reports” is switched on in your account settings. Visitors without an account never see them.</p>

<h3>How do I remove a report?</h3>
<p>Open it from your dashboard and press Delete. Its photos, claims, tips and messages are removed with it.</p>

<p>Still stuck? <a href="<?= url("contact") ?>">Send us a message</a>.</p>
<?php
View::partial("partials/prose_page", [
    "eyebrow" => "Help",
    "heading" => "Questions & answers",
    "intro" => "How reporting, matching, claims and privacy work on Lostly.",
    "body" => ob_get_clean()
]);
