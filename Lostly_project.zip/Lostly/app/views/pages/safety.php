<?php ob_start(); ?>
<h2>Before you meet</h2>
<ul>
    <li><b>Ask for proof.</b> A real owner can describe marks, contents, a lock screen or a serial number. Do not accept “trust me”.</li>
    <li><b>Keep one detail back.</b> If you found something, leave one identifying detail out of your report so only the owner can name it.</li>
    <li><b>Use private messages first.</b> You do not have to share your phone number to arrange a handover.</li>
</ul>

<h2>At the handover</h2>
<ul>
    <li><b>Meet in a public place</b> in daylight: a shop, a bank lobby, a police station front desk.</li>
    <li><b>Bring someone</b> or tell someone where you are going.</li>
    <li><b>Check the item</b> before you mark the report resolved.</li>
</ul>

<h2>Money and rewards</h2>
<ul>
    <li><b>Never pay in advance.</b> Nobody honest needs a “delivery fee”, bKash transfer or deposit before returning an item.</li>
    <li>A reward is the owner's choice and is paid in person, after the item is back.</li>
</ul>

<h2>Documents, cards and phones</h2>
<ul>
    <li>For a lost NID, passport or other official document, file a General Diary (GD) at your nearest police station. You will usually need it for a replacement.</li>
    <li>Block lost bank cards and SIMs with your bank and mobile operator straight away.</li>
    <li>Do not post full ID numbers or card numbers in a report.</li>
</ul>

<h2>If something feels wrong</h2>
<p>Use “Report this post to admins” on the report, or the <a href="<?= url("contact") ?>">contact form</a>. In an emergency call <b>999</b>.</p>
<?php
View::partial("partials/prose_page", [
    "eyebrow" => "Safety",
    "heading" => "Safety tips",
    "intro" => "Most handovers go smoothly. These habits keep it that way.",
    "body" => ob_get_clean()
]);
