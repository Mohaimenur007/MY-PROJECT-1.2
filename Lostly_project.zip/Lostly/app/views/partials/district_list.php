<?php
// Suggestions for a District field. main.js refills the list whenever the
// Division select (id="division") on the same form changes.
?>
<datalist id="district-list" data-districts="<?= e(json_encode(config("districts"))) ?>"></datalist>
