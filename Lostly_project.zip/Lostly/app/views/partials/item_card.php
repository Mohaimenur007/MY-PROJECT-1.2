<?php
// One report drawn as a pinned notice card.
// Needs $item; pass $score to show a "92% match" strip.
$score = isset($score) ? $score : null;
?>
<a href="<?= url("items/" . (int)$item["ID"]) ?>" class="item-card card-<?= strtolower($item["Type"]) ?>">

    <span class="tape"></span>

    <div class="item-card-media">
        <?php if(!empty($item["ImagePath"])) { ?>
        <img src="<?= e(asset($item["ImagePath"])) ?>" alt="<?= e($item["ItemName"]) ?>">
        <?php } else { ?>
        <div class="item-card-placeholder"><?= category_icon($item["Category"]) ?></div>
        <?php } ?>

        <span class="stamp stamp-<?= strtolower($item["Type"]) ?>"><?= e($item["Type"]) ?></span>

        <?php if($item["Status"] == "Resolved") { ?>
        <span class="stamp stamp-resolved">Resolved</span>
        <?php } else if(!empty($item["Reward"])) { ?>
        <span class="reward-chip">Reward <?= taka($item["Reward"]) ?></span>
        <?php } ?>
    </div>

    <div class="item-card-body">
        <?php if($score !== null) { ?>
        <div class="match-meter" title="How closely this report matches yours">
            <div class="progress flex-grow-1" role="progressbar" aria-label="Match score" aria-valuenow="<?= (int)$score ?>" aria-valuemin="0" aria-valuemax="100">
                <div class="progress-bar" style="width: <?= (int)$score ?>%"></div>
            </div>
            <b><?= (int)$score ?>% match</b>
        </div>
        <?php } ?>

        <h3><?= e($item["ItemName"]) ?></h3>

        <p class="item-card-meta">
            <span><?= category_icon($item["Category"]) ?> <?= e($item["Category"]) ?></span>
            <span>📍 <?= e($item["District"]) ?>, <?= e($item["Division"]) ?></span>
        </p>

        <p class="item-card-foot">
            <span><?= date("M j, Y", strtotime($item["EventDate"])) ?> · <?= Item::code($item["ID"]) ?></span>
            <span class="view-link">Open →</span>
        </p>
    </div>

</a>
