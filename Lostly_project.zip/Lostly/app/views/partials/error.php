<div class="container-xl page text-center">
    <div class="empty">
        <span class="empty-icon">📌</span>
        <h1><?= e($heading) ?></h1>
        <p><?= e($text) ?></p>
        <a href="<?= url(Auth::check() ? "dashboard" : "") ?>" class="btn btn-ink mt-3">Back to the board</a>
    </div>
</div>
