<?php // Shell for the information pages. Needs $eyebrow, $heading, $intro and $body (HTML). ?>
<div class="container-xl page page-narrow">
    <section class="page-hero">
        <p class="eyebrow"><?= e($eyebrow) ?></p>
        <h1><?= e($heading) ?></h1>
        <p><?= e($intro) ?></p>
    </section>

    <article class="panel prose">
        <?= $body ?>
    </article>
</div>
