<?php // One resolved report with its thank-you note. Needs $item. ?>
<a class="reunited-card h-100" href="<?= url("items/" . (int)$item["ID"]) ?>">
    <span class="stamp stamp-resolved">Reunited</span>
    <span class="reunited-icon"><?= category_icon($item["Category"]) ?></span>
    <strong><?= e($item["ItemName"]) ?></strong>
    <small><?= e($item["District"]) ?>, <?= e($item["Division"]) ?><?= $item["ResolvedAt"] ? " · " . date("M j, Y", strtotime($item["ResolvedAt"])) : "" ?></small>
    <?php if(!empty($item["ResolvedNote"])) { ?>
    <span class="quote">“<?= e(shorten($item["ResolvedNote"], 160)) ?>”</span>
    <span class="reunited-by">— <?= e($item["Username"]) ?></span>
    <?php } ?>
</a>
