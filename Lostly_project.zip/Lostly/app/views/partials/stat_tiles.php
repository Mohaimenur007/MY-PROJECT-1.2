<?php // Row of big-number tiles. Needs $tiles: label => number, and optionally $cols (Bootstrap row-cols classes). ?>
<div class="row <?= isset($cols) ? $cols : "row-cols-2 row-cols-lg-4" ?> g-3 stat-strip">
    <?php foreach($tiles as $label => $value) { ?>
    <div class="col">
        <div class="stat-tile">
            <strong class="js-count" data-count="<?= (int)$value ?>"><?= (int)$value ?></strong>
            <span><?= e($label) ?></span>
        </div>
    </div>
    <?php } ?>
</div>
