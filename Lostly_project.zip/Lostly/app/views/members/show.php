<?php
// Badges are earned from real activity on the site.
$badges = [];
if($stats["returned"] >= 1) { $badges[] = ["🤝", "Returned " . $stats["returned"] . " item" . ($stats["returned"] == 1 ? "" : "s")]; }
if($stats["resolved"] >= 1) { $badges[] = ["✅", $stats["resolved"] . " report" . ($stats["resolved"] == 1 ? "" : "s") . " resolved"]; }
if($stats["tips"] >= 3) { $badges[] = ["💡", "Helpful tipster"]; }
if($member["Role"] == "admin") { $badges[] = ["🛡️", "Lostly admin"]; }
?>
<div class="container-xl page">

    <section class="panel member-head">
        <span class="avatar avatar-lg"><?= e(initial($member["Username"])) ?></span>

        <div class="member-info">
            <h1><?= e($member["Username"]) ?>
                <?php if($member["IsBanned"]) { ?><span class="badge rounded-pill badge-rejected">Suspended</span><?php } ?>
            </h1>
            <p class="text-body-secondary mb-2">📍 <?= e($member["District"]) ?>, <?= e($member["Division"]) ?> · member since <?= date("F Y", strtotime($member["CreatedAt"])) ?></p>

            <?php if(count($badges) > 0) { ?>
            <div class="d-flex flex-wrap gap-2">
                <?php foreach($badges as $badge) { ?>
                <span class="member-badge"><?= $badge[0] ?> <?= e($badge[1]) ?></span>
                <?php } ?>
            </div>
            <?php } ?>
        </div>

        <?php if(Auth::check() && Auth::id() == $member["ID"]) { ?>
        <a href="<?= url("profile") ?>" class="btn btn-ghost btn-sm">Account settings</a>
        <?php } ?>
    </section>

    <?php View::partial("partials/stat_tiles", ["tiles" => [
        "reports posted" => $stats["reports"],
        "reports resolved" => $stats["resolved"],
        "items returned to others" => $stats["returned"],
        "tips left" => $stats["tips"]
    ]]); ?>

    <h2 class="section-title">Active reports</h2>

    <?php if(count($items) == 0) { ?>

    <div class="empty">
        <span class="empty-icon">📌</span>
        <p><?= e($member["Username"]) ?> has no active reports right now.</p>
    </div>

    <?php } else { ?>

    <div class="item-grid">
        <?php foreach($items as $item) { View::partial("partials/item_card", ["item" => $item]); } ?>
    </div>

    <?php } ?>

</div>
