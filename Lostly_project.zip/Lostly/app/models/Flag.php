<?php

// A member reporting a suspicious post to the admins.
class Flag
{
    public static function exists($item_id, $user_id)
    {
        return Database::one("SELECT ID FROM flags WHERE ItemID=? AND UserID=?", "ii", [$item_id, $user_id]) !== null;
    }

    public static function create($item_id, $user_id, $reason)
    {
        Database::run("INSERT INTO flags (ItemID, UserID, Reason) VALUES (?,?,?)", "iis", [$item_id, $user_id, $reason]);
    }

    public static function open()
    {
        return Database::all(
            "SELECT flags.ID AS FlagID, flags.Reason, flags.CreatedAt, flags.ItemID,
                    items.ItemName, reporter.Username AS ReporterName, owner.Username AS OwnerName
             FROM flags
             JOIN items ON flags.ItemID = items.ID
             JOIN users reporter ON flags.UserID = reporter.ID
             JOIN users owner ON items.UserID = owner.ID
             WHERE flags.Status = 'Open'
             ORDER BY flags.ID DESC");
    }

    public static function openCount()
    {
        return (int)Database::value("SELECT COUNT(*) FROM flags WHERE Status='Open'");
    }

    public static function dismiss($id)
    {
        Database::run("UPDATE flags SET Status='Dismissed' WHERE ID=?", "i", [$id]);
    }
}
