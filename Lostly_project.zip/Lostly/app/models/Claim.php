<?php

// A "this is mine" / "I found it" request on a report.
class Claim
{
    public static function find($id)
    {
        return Database::one("SELECT * FROM claims WHERE ID=?", "i", [$id]);
    }

    public static function forItem($item_id)
    {
        return Database::all(
            "SELECT claims.*, users.Username
             FROM claims JOIN users ON claims.ClaimantID = users.ID
             WHERE claims.ItemID = ?
             ORDER BY claims.ID DESC", "i", [$item_id]);
    }

    public static function byUserOnItem($item_id, $user_id)
    {
        return Database::one("SELECT * FROM claims WHERE ItemID=? AND ClaimantID=?", "ii", [$item_id, $user_id]);
    }

    public static function create($item_id, $user_id, $message)
    {
        return Database::insert("INSERT INTO claims (ItemID, ClaimantID, Message) VALUES (?,?,?)",
            "iis", [$item_id, $user_id, $message]);
    }

    public static function setStatus($id, $status)
    {
        Database::run("UPDATE claims SET Status=? WHERE ID=?", "si", [$status == "Approved" ? "Approved" : "Rejected", $id]);
    }

    public static function pendingForItem($item_id)
    {
        return Database::all("SELECT * FROM claims WHERE ItemID=? AND Status='Pending'", "i", [$item_id]);
    }

    public static function rejectPending($item_id)
    {
        Database::run("UPDATE claims SET Status='Rejected' WHERE ItemID=? AND Status='Pending'", "i", [$item_id]);
    }

    // Claims other people sent on this user's reports, still waiting.
    public static function incomingFor($user_id)
    {
        return Database::all(
            "SELECT claims.ID AS ClaimID, claims.Message, claims.CreatedAt, claims.ClaimantID,
                    items.ID AS ItemID, items.ItemName, items.Type, users.Username
             FROM claims
             JOIN items ON claims.ItemID = items.ID
             JOIN users ON claims.ClaimantID = users.ID
             WHERE items.UserID = ? AND claims.Status = 'Pending'
             ORDER BY claims.ID DESC", "i", [$user_id]);
    }

    public static function sentBy($user_id)
    {
        return Database::all(
            "SELECT claims.Status, claims.CreatedAt, items.ID AS ItemID, items.ItemName, items.Type
             FROM claims
             JOIN items ON claims.ItemID = items.ID
             WHERE claims.ClaimantID = ?
             ORDER BY claims.ID DESC
             LIMIT 10", "i", [$user_id]);
    }

    public static function count()
    {
        return (int)Database::value("SELECT COUNT(*) FROM claims");
    }
}
