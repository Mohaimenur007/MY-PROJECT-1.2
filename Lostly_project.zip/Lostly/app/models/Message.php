<?php

// Private chat between two members about one report.
class Message
{
    // Messages between $me and $other about $item_id, newer than message $after.
    public static function thread($item_id, $me, $other, $after = 0)
    {
        return Database::all(
            "SELECT ID, SenderID, Body, CreatedAt FROM messages
             WHERE ItemID=? AND ID > ?
               AND ((SenderID=? AND ReceiverID=?) OR (SenderID=? AND ReceiverID=?))
             ORDER BY ID ASC",
            "iiiiii", [$item_id, $after, $me, $other, $other, $me]);
    }

    public static function send($item_id, $from, $to, $body)
    {
        return Database::insert("INSERT INTO messages (ItemID, SenderID, ReceiverID, Body) VALUES (?,?,?,?)",
            "iiis", [$item_id, $from, $to, $body]);
    }

    // Everything $other sent $me in this conversation is now read.
    public static function markRead($item_id, $me, $other)
    {
        Database::run("UPDATE messages SET IsRead=1 WHERE ItemID=? AND SenderID=? AND ReceiverID=? AND IsRead=0",
            "iii", [$item_id, $other, $me]);
    }

    public static function unreadCount($user_id)
    {
        return (int)Database::value("SELECT COUNT(*) FROM messages WHERE ReceiverID=? AND IsRead=0", "i", [$user_id]);
    }

    // Inbox: one entry per conversation, showing its newest message.
    public static function inbox($user_id)
    {
        $rows = Database::all(
            "SELECT messages.*, items.ItemName, items.Type,
                    sender.Username AS SenderName, receiver.Username AS ReceiverName
             FROM messages
             JOIN items ON messages.ItemID = items.ID
             JOIN users sender ON messages.SenderID = sender.ID
             JOIN users receiver ON messages.ReceiverID = receiver.ID
             WHERE messages.SenderID = ? OR messages.ReceiverID = ?
             ORDER BY messages.ID DESC
             LIMIT 500", "ii", [$user_id, $user_id]);

        $threads = [];

        foreach($rows as $row)
        {
            $mine = $row["SenderID"] == $user_id;
            $other_id = $mine ? $row["ReceiverID"] : $row["SenderID"];
            $key = $row["ItemID"] . "-" . $other_id;

            if(!isset($threads[$key]))
            {
                $threads[$key] = [
                    "item_id" => $row["ItemID"],
                    "item_name" => $row["ItemName"],
                    "type" => $row["Type"],
                    "other_id" => $other_id,
                    "other_name" => $mine ? $row["ReceiverName"] : $row["SenderName"],
                    "last_body" => $row["Body"],
                    "last_mine" => $mine,
                    "last_time" => $row["CreatedAt"],
                    "unread" => 0
                ];
            }

            if(!$mine && !$row["IsRead"])
            {
                $threads[$key]["unread"]++;
            }
        }

        return array_values($threads);
    }

    public static function count()
    {
        return (int)Database::value("SELECT COUNT(*) FROM messages");
    }
}
