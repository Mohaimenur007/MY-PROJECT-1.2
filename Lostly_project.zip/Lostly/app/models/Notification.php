<?php

// Alerts shown under "Alerts" in the menu.
class Notification
{
    // $link is a route such as "items/7" (turned into a full address when shown).
    public static function send($user_id, $type, $body, $link)
    {
        // The Body column holds 255 characters.
        $body = function_exists("mb_substr") ? mb_substr($body, 0, 250, "UTF-8") : substr($body, 0, 250);

        Database::run("INSERT INTO notifications (UserID, Type, Body, Link) VALUES (?,?,?,?)",
            "isss", [$user_id, $type, $body, $link]);
    }

    public static function forUser($user_id)
    {
        return Database::all("SELECT * FROM notifications WHERE UserID=? ORDER BY ID DESC LIMIT 100", "i", [$user_id]);
    }

    public static function markAllRead($user_id)
    {
        Database::run("UPDATE notifications SET IsRead=1 WHERE UserID=? AND IsRead=0", "i", [$user_id]);
    }

    public static function clear($user_id)
    {
        Database::run("DELETE FROM notifications WHERE UserID=?", "i", [$user_id]);
    }

    public static function unreadCount($user_id)
    {
        return (int)Database::value("SELECT COUNT(*) FROM notifications WHERE UserID=? AND IsRead=0", "i", [$user_id]);
    }
}
