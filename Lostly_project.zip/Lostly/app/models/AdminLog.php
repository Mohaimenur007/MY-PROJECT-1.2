<?php

// A record of what was done in the admin panel, and by whom.
class AdminLog
{
    public static function add($action, $detail)
    {
        $detail = function_exists("mb_substr") ? mb_substr($detail, 0, 250, "UTF-8") : substr($detail, 0, 250);

        Database::run("INSERT INTO admin_log (AdminID, Action, Detail) VALUES (?,?,?)",
            "iss", [Auth::id(), $action, $detail]);
    }

    public static function recent()
    {
        return Database::all(
            "SELECT admin_log.*, users.Username
             FROM admin_log JOIN users ON admin_log.AdminID = users.ID
             ORDER BY admin_log.ID DESC
             LIMIT 100");
    }
}
