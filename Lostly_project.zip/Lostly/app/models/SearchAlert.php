<?php

// A saved search: "tell me when a report like this appears".
class SearchAlert
{
    public static function forUser($user_id)
    {
        return Database::all("SELECT * FROM search_alerts WHERE UserID=? ORDER BY ID DESC", "i", [$user_id]);
    }

    public static function countFor($user_id)
    {
        return (int)Database::value("SELECT COUNT(*) FROM search_alerts WHERE UserID=?", "i", [$user_id]);
    }

    public static function exists($user_id, $f)
    {
        return Database::one(
            "SELECT ID FROM search_alerts WHERE UserID=? AND Type=? AND Category=? AND Division=? AND Keyword=?",
            "issss", [$user_id, $f["type"], $f["category"], $f["division"], $f["keyword"]]) !== null;
    }

    public static function create($user_id, $f)
    {
        Database::run("INSERT INTO search_alerts (UserID, Type, Category, Division, Keyword) VALUES (?,?,?,?,?)",
            "issss", [$user_id, $f["type"], $f["category"], $f["division"], $f["keyword"]]);
    }

    public static function delete($id, $user_id)
    {
        Database::run("DELETE FROM search_alerts WHERE ID=? AND UserID=?", "ii", [$id, $user_id]);
    }

    // Members (other than the reporter) whose saved search fits a new report.
    public static function subscribersFor($item)
    {
        $rows = Database::all(
            "SELECT search_alerts.UserID, search_alerts.Keyword
             FROM search_alerts
             JOIN users ON search_alerts.UserID = users.ID
             WHERE search_alerts.UserID != ?
               AND users.IsBanned = 0
               AND (search_alerts.Type = '' OR search_alerts.Type = ?)
               AND (search_alerts.Category = '' OR search_alerts.Category = ?)
               AND (search_alerts.Division = '' OR search_alerts.Division = ?)
             LIMIT 1000",
            "isss", [$item["UserID"], $item["Type"], $item["Category"], $item["Division"]]);

        $text = $item["ItemName"] . " " . $item["Description"] . " " . $item["District"];
        $users = [];

        foreach($rows as $row)
        {
            // The keyword (if any) must appear somewhere in the report.
            $hit = $row["Keyword"] == ""
                || (function_exists("mb_stripos") ? mb_stripos($text, $row["Keyword"], 0, "UTF-8") : stripos($text, $row["Keyword"])) !== false;

            if($hit)
            {
                $users[$row["UserID"]] = true;
            }
        }

        return array_keys($users);
    }

    // "Lost · Keys · Dhaka · wallet"
    public static function describe($row)
    {
        $parts = array_filter([$row["Type"], $row["Category"], $row["Division"], $row["Keyword"] != "" ? "“" . $row["Keyword"] . "”" : ""], "strlen");
        return implode(" · ", $parts);
    }
}
