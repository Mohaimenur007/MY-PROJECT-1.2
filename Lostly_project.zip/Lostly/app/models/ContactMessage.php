<?php

// Messages sent through the public Contact page.
class ContactMessage
{
    public static function create($name, $email, $subject, $body)
    {
        Database::run("INSERT INTO contact_messages (Name, Email, Subject, Body) VALUES (?,?,?,?)",
            "ssss", [$name, $email, $subject, $body]);
    }

    public static function all()
    {
        return Database::all("SELECT * FROM contact_messages ORDER BY ID DESC LIMIT 200");
    }

    public static function unreadCount()
    {
        return (int)Database::value("SELECT COUNT(*) FROM contact_messages WHERE IsRead=0");
    }

    public static function markAllRead()
    {
        Database::run("UPDATE contact_messages SET IsRead=1 WHERE IsRead=0");
    }

    public static function delete($id)
    {
        Database::run("DELETE FROM contact_messages WHERE ID=?", "i", [$id]);
    }
}
