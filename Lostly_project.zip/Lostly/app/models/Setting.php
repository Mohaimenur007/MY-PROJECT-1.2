<?php

// Site-wide values an admin can change (for example the announcement banner).
class Setting
{
    public static function get($name, $default = "")
    {
        $value = Database::value("SELECT Value FROM settings WHERE Name=?", "s", [$name]);
        return $value === null ? $default : $value;
    }

    public static function set($name, $value)
    {
        Database::run("DELETE FROM settings WHERE Name=?", "s", [$name]);
        Database::run("INSERT INTO settings (Name, Value) VALUES (?,?)", "ss", [$name, $value]);
    }
}
