<?php

// Public sightings and tips left on a report.
class Comment
{
    public static function find($id)
    {
        return Database::one("SELECT * FROM comments WHERE ID=?", "i", [$id]);
    }

    public static function forItem($item_id)
    {
        return Database::all(
            "SELECT comments.*, users.Username
             FROM comments JOIN users ON comments.UserID = users.ID
             WHERE comments.ItemID = ? AND users.IsBanned = 0
             ORDER BY comments.ID ASC", "i", [$item_id]);
    }

    public static function create($item_id, $user_id, $body)
    {
        return Database::insert("INSERT INTO comments (ItemID, UserID, Body) VALUES (?,?,?)", "iis", [$item_id, $user_id, $body]);
    }

    public static function delete($id)
    {
        Database::run("DELETE FROM comments WHERE ID=?", "i", [$id]);
    }
}
