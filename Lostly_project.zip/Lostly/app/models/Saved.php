<?php

// A member's watchlist of reports.
class Saved
{
    public static function has($user_id, $item_id)
    {
        return Database::one("SELECT ItemID FROM saved_items WHERE UserID=? AND ItemID=?", "ii", [$user_id, $item_id]) !== null;
    }

    // Saves the report, or removes it if it was already saved. Returns the new state.
    public static function toggle($user_id, $item_id)
    {
        if(self::has($user_id, $item_id))
        {
            Database::run("DELETE FROM saved_items WHERE UserID=? AND ItemID=?", "ii", [$user_id, $item_id]);
            return false;
        }

        Database::run("INSERT INTO saved_items (UserID, ItemID) VALUES (?,?)", "ii", [$user_id, $item_id]);
        return true;
    }

    public static function forUser($user_id)
    {
        return Database::all(
            "SELECT items.*, users.Username
             FROM saved_items
             JOIN items ON saved_items.ItemID = items.ID
             JOIN users ON items.UserID = users.ID
             WHERE saved_items.UserID = ? AND users.IsBanned = 0
             ORDER BY saved_items.CreatedAt DESC, items.ID DESC", "i", [$user_id]);
    }

    // Everyone watching a report (to tell them when it is resolved).
    public static function watchers($item_id)
    {
        return array_column(Database::all("SELECT UserID FROM saved_items WHERE ItemID=?", "i", [$item_id]), "UserID");
    }
}
