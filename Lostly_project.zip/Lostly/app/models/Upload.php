<?php

// Stores and removes item photos in uploads/items/.
class Upload
{
    // How many files were actually chosen in a "multiple" file field.
    public static function countSent($field)
    {
        $count = 0;

        if(isset($_FILES[$field]) && is_array($_FILES[$field]["error"]))
        {
            foreach($_FILES[$field]["error"] as $error)
            {
                if($error != UPLOAD_ERR_NO_FILE)
                {
                    $count++;
                }
            }
        }

        return $count;
    }

    // Stores every photo sent in a "multiple" file field (name="photos[]").
    // Returns [paths, error]. If any file is bad, nothing is kept.
    public static function storeMany($field)
    {
        $paths = [];

        if(!isset($_FILES[$field]) || !is_array($_FILES[$field]["error"]))
        {
            return [$paths, ""];
        }

        $files = $_FILES[$field];

        foreach($files["error"] as $i => $error)
        {
            if($error == UPLOAD_ERR_NO_FILE)
            {
                continue;
            }

            list($path, $message) = self::storeOne($error, $files["size"][$i], $files["tmp_name"][$i]);

            if($message != "")
            {
                foreach($paths as $done)
                {
                    self::delete($done);
                }

                return [[], $message];
            }

            $paths[] = $path;
        }

        return [$paths, ""];
    }

    private static function storeOne($error, $size, $tmp_name)
    {
        if($error != UPLOAD_ERR_OK)
        {
            return [null, "Image upload failed, please try again"];
        }

        if($size > config("max_upload_bytes"))
        {
            return [null, "Each image must be smaller than 5MB"];
        }

        // Trust the file's real contents, not the name the browser sent.
        $info = @getimagesize($tmp_name);
        $allowed = [IMAGETYPE_JPEG => "jpg", IMAGETYPE_PNG => "png", IMAGETYPE_WEBP => "webp"];

        if(!$info || !isset($allowed[$info[2]]))
        {
            return [null, "Images must be real JPG, PNG, or WEBP files"];
        }

        $folder = ROOT . "/uploads/items/";

        if(!is_dir($folder))
        {
            mkdir($folder, 0755, true);
        }

        $name = "item_" . bin2hex(random_bytes(12)) . "." . $allowed[$info[2]];

        if(!move_uploaded_file($tmp_name, $folder . $name))
        {
            return [null, "Image upload failed, please try again"];
        }

        return ["uploads/items/" . $name, ""];
    }

    public static function delete($path)
    {
        // Only ever remove files that live inside uploads/items/.
        if($path && strpos($path, "uploads/items/") === 0 && strpos($path, "..") === false)
        {
            $full = ROOT . "/" . $path;

            if(is_file($full))
            {
                unlink($full);
            }
        }
    }
}
