<?php

class User
{
    public static function find($id)
    {
        return Database::one("SELECT * FROM users WHERE ID=?", "i", [$id]);
    }

    public static function findByUsername($username)
    {
        return Database::one("SELECT * FROM users WHERE Username=?", "s", [$username]);
    }

    // Is this username or email already used (by someone other than $except_id)?
    public static function taken($username, $email, $except_id = 0)
    {
        return Database::one("SELECT ID FROM users WHERE (Username=? OR Email=?) AND ID!=?",
            "ssi", [$username, $email, $except_id]) !== null;
    }

    public static function create($data)
    {
        return Database::insert(
            "INSERT INTO users (Username, Email, Phone, Division, District, Password) VALUES (?,?,?,?,?,?)",
            "ssssss",
            [$data["username"], $data["email"], $data["phone"], $data["division"], $data["district"],
             password_hash($data["password"], PASSWORD_DEFAULT)]);
    }

    public static function updateProfile($id, $data)
    {
        Database::run("UPDATE users SET Username=?, Email=?, Phone=?, Division=?, District=?, ShowContact=? WHERE ID=?",
            "sssssii", [$data["username"], $data["email"], $data["phone"], $data["division"], $data["district"],
                        $data["show_contact"] ? 1 : 0, $id]);
    }

    public static function updatePassword($id, $password)
    {
        Database::run("UPDATE users SET Password=? WHERE ID=?", "si", [password_hash($password, PASSWORD_DEFAULT), $id]);
    }

    // Checks a login password. Very old accounts stored the password as plain
    // text; those are let in once and upgraded to a secure hash straight away.
    public static function passwordMatches($user, $password)
    {
        if(password_verify($password, $user["Password"]))
        {
            return true;
        }

        if(password_get_info($user["Password"])["algo"] === null && hash_equals($user["Password"], $password))
        {
            self::updatePassword($user["ID"], $password);
            return true;
        }

        return false;
    }

    public static function setBanned($id, $banned)
    {
        Database::run("UPDATE users SET IsBanned=? WHERE ID=?", "ii", [$banned ? 1 : 0, $id]);
    }

    public static function setRole($id, $role)
    {
        Database::run("UPDATE users SET Role=? WHERE ID=?", "si", [$role == "admin" ? "admin" : "user", $id]);
    }

    public static function allWithReportCounts()
    {
        return Database::all(
            "SELECT users.*, (SELECT COUNT(*) FROM items WHERE items.UserID = users.ID) AS ReportCount
             FROM users
             ORDER BY users.ID ASC");
    }

    // Numbers shown on a member's public profile.
    public static function stats($id)
    {
        return [
            "reports" => (int)Database::value("SELECT COUNT(*) FROM items WHERE UserID=?", "i", [$id]),
            "resolved" => (int)Database::value("SELECT COUNT(*) FROM items WHERE UserID=? AND Status='Resolved'", "i", [$id]),
            "returned" => (int)Database::value("SELECT COUNT(*) FROM claims WHERE ClaimantID=? AND Status='Approved'", "i", [$id]),
            "tips" => (int)Database::value("SELECT COUNT(*) FROM comments WHERE UserID=?", "i", [$id])
        ];
    }

    public static function count($only_active = false)
    {
        return (int)Database::value("SELECT COUNT(*) FROM users" . ($only_active ? " WHERE IsBanned = 0" : ""));
    }
}
