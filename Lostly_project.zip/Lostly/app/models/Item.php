<?php

class Item
{
    // One report together with its reporter's details.
    public static function find($id)
    {
        return Database::one(
            "SELECT items.*, users.Username, users.Email, users.Phone, users.IsBanned, users.ShowContact
             FROM items JOIN users ON items.UserID = users.ID
             WHERE items.ID = ?", "i", [$id]);
    }

    // Only returns the report if it belongs to $user_id.
    public static function findOwned($id, $user_id)
    {
        return Database::one("SELECT * FROM items WHERE ID=? AND UserID=?", "ii", [$id, $user_id]);
    }

    public static function byUser($user_id)
    {
        return Database::all("SELECT * FROM items WHERE UserID=? ORDER BY CreatedAt DESC, ID DESC", "i", [$user_id]);
    }

    public static function recent($limit)
    {
        return Database::all(
            "SELECT items.*, users.Username
             FROM items JOIN users ON items.UserID = users.ID
             WHERE items.Status = 'Active' AND users.IsBanned = 0
             ORDER BY items.CreatedAt DESC, items.ID DESC
             LIMIT ?", "i", [$limit]);
    }

    // Browse page. $filters: search, type, division, category, status, sort.
    // Returns ["items" => rows for this page, "total" => all matching rows].
    public static function search($filters, $page, $per_page)
    {
        $where = " FROM items
                   JOIN users ON items.UserID = users.ID
                   WHERE users.IsBanned = 0";

        $params = [];
        $types = "";

        if($filters["status"] == "Active" || $filters["status"] == "Resolved")
        {
            $where .= " AND items.Status = ?";
            $params[] = $filters["status"];
            $types .= "s";
        }

        if($filters["search"] != "")
        {
            $where .= " AND (
                items.ItemName LIKE ?
                OR items.Description LIKE ?
                OR items.Category LIKE ?
                OR items.District LIKE ?
                OR items.Division LIKE ?
            )";

            $value = "%" . $filters["search"] . "%";
            array_push($params, $value, $value, $value, $value, $value);
            $types .= "sssss";
        }

        foreach(["type" => "items.Type", "division" => "items.Division", "category" => "items.Category"] as $key => $column)
        {
            if($filters[$key] != "")
            {
                $where .= " AND " . $column . " = ?";
                $params[] = $filters[$key];
                $types .= "s";
            }
        }

        $total = (int)Database::value("SELECT COUNT(*)" . $where, $types, $params);

        // Sort order comes from this fixed list, never from user text.
        $orders = [
            "newest" => "items.CreatedAt DESC, items.ID DESC",
            "oldest" => "items.CreatedAt ASC, items.ID ASC",
            "date" => "items.EventDate DESC, items.ID DESC",
            "popular" => "items.Views DESC, items.ID DESC"
        ];

        $order = isset($orders[$filters["sort"]]) ? $orders[$filters["sort"]] : $orders["newest"];

        $params[] = $per_page;
        $params[] = (max(1, $page) - 1) * $per_page;
        $types .= "ii";

        $items = Database::all(
            "SELECT items.*, users.Username" . $where . " ORDER BY " . $order . " LIMIT ? OFFSET ?",
            $types, $params);

        return ["items" => $items, "total" => $total];
    }

    public static function create($user_id, $data)
    {
        return Database::insert(
            "INSERT INTO items (UserID, Type, ItemName, Category, Description, Division, District, EventDate, ImagePath, Reward) VALUES (?,?,?,?,?,?,?,?,?,?)",
            "issssssssi",
            [$user_id, $data["type"], $data["item_name"], $data["category"], $data["description"],
             $data["division"], $data["district"], $data["event_date"], $data["image_path"], $data["reward"]]);
    }

    public static function update($id, $user_id, $data)
    {
        Database::run(
            "UPDATE items SET Type=?, ItemName=?, Category=?, Description=?, Division=?, District=?, EventDate=?, ImagePath=?, Reward=? WHERE ID=? AND UserID=?",
            "ssssssssiii",
            [$data["type"], $data["item_name"], $data["category"], $data["description"],
             $data["division"], $data["district"], $data["event_date"], $data["image_path"], $data["reward"], $id, $user_id]);
    }

    // Marks a report resolved, with an optional public thank-you note.
    public static function resolve($id, $note = null)
    {
        Database::run("UPDATE items SET Status='Resolved', ResolvedAt=?, ResolvedNote=? WHERE ID=?",
            "ssi", [date("Y-m-d H:i:s"), $note, $id]);
    }

    public static function reopen($id)
    {
        Database::run("UPDATE items SET Status='Active', ResolvedAt=NULL, ResolvedNote=NULL WHERE ID=?", "i", [$id]);
    }

    // Removes a report and every photo file that belonged to it.
    public static function delete($item)
    {
        $files = array_merge([$item["ImagePath"]], array_column(self::extraPhotos($item["ID"]), "Path"));

        Database::run("DELETE FROM items WHERE ID=?", "i", [$item["ID"]]);

        foreach($files as $file)
        {
            Upload::delete($file);
        }
    }

    // ---- photos ---------------------------------------------------------
    // The cover photo is items.ImagePath; any further photos are rows in item_images.

    public static function extraPhotos($id)
    {
        return Database::all("SELECT ID, Path FROM item_images WHERE ItemID=? ORDER BY ID ASC", "i", [$id]);
    }

    // Every photo of a report, cover first.
    public static function photos($item)
    {
        $paths = $item["ImagePath"] ? [$item["ImagePath"]] : [];
        return array_merge($paths, array_column(self::extraPhotos($item["ID"]), "Path"));
    }

    // Replaces the report's photo list: first path becomes the cover.
    public static function setPhotos($id, $paths)
    {
        $paths = array_values($paths);

        Database::run("UPDATE items SET ImagePath=? WHERE ID=?", "si", [count($paths) > 0 ? $paths[0] : null, $id]);
        Database::run("DELETE FROM item_images WHERE ItemID=?", "i", [$id]);

        for($i = 1; $i < count($paths); $i++)
        {
            Database::run("INSERT INTO item_images (ItemID, Path) VALUES (?,?)", "is", [$id, $paths[$i]]);
        }
    }

    // Public reference such as LF-00042, shown on reports and posters.
    public static function code($id)
    {
        return "LF-" . str_pad((string)$id, 5, "0", STR_PAD_LEFT);
    }

    public static function activeByUser($user_id)
    {
        return Database::all(
            "SELECT items.*, users.Username
             FROM items JOIN users ON items.UserID = users.ID
             WHERE items.UserID = ? AND items.Status = 'Active'
             ORDER BY items.CreatedAt DESC, items.ID DESC", "i", [$user_id]);
    }

    // Resolved reports, newest first (the "Reunited" page).
    public static function reunited($limit)
    {
        return Database::all(
            "SELECT items.*, users.Username
             FROM items JOIN users ON items.UserID = users.ID
             WHERE items.Status = 'Resolved' AND users.IsBanned = 0
             ORDER BY items.ResolvedAt DESC, items.ID DESC
             LIMIT ?", "i", [$limit]);
    }

    // Active reports per category or division, for the home page tiles.
    public static function activeCounts($column)
    {
        $column = $column == "Division" ? "Division" : "Category";
        $counts = [];

        $rows = Database::all(
            "SELECT items." . $column . " AS Label, COUNT(*) AS Total
             FROM items JOIN users ON items.UserID = users.ID
             WHERE items.Status = 'Active' AND users.IsBanned = 0
             GROUP BY items." . $column);

        foreach($rows as $row)
        {
            $counts[$row["Label"]] = (int)$row["Total"];
        }

        return $counts;
    }

    public static function all()
    {
        return Database::all(
            "SELECT items.*, users.Username
             FROM items JOIN users ON items.UserID = users.ID
             ORDER BY items.ID ASC");
    }

    public static function addView($id)
    {
        Database::run("UPDATE items SET Views = Views + 1 WHERE ID=?", "i", [$id]);
    }

    public static function adminSearch($q)
    {
        $like = "%" . $q . "%";

        return Database::all(
            "SELECT items.*, users.Username
             FROM items JOIN users ON items.UserID = users.ID
             WHERE items.ItemName LIKE ? OR users.Username LIKE ?
             ORDER BY items.ID DESC
             LIMIT 100", "ss", [$like, $like]);
    }

    // ---- statistics -----------------------------------------------------

    // $where is one of the fixed conditions below, never user input.
    public static function count($where = "")
    {
        $conditions = [
            "" => "",
            "active" => " WHERE Status='Active'",
            "resolved" => " WHERE Status='Resolved'",
            "lost" => " WHERE Type='Lost'"
        ];

        return (int)Database::value("SELECT COUNT(*) FROM items" . $conditions[$where]);
    }

    // Counts that leave out reports from suspended accounts (for the public page).
    public static function publicCount($resolved_only = false)
    {
        return (int)Database::value(
            "SELECT COUNT(*) FROM items JOIN users ON items.UserID = users.ID WHERE users.IsBanned = 0"
            . ($resolved_only ? " AND items.Status = 'Resolved'" : ""));
    }

    public static function countBy($column)
    {
        $column = $column == "Division" ? "Division" : "Category";

        return Database::all("SELECT " . $column . " AS Label, COUNT(*) AS Total FROM items GROUP BY " . $column . " ORDER BY Total DESC");
    }

    // Reports posted on each of the last 7 days: ["2026-10-01" => 3, ...]
    public static function lastSevenDays()
    {
        $days = [];

        for($i = 6; $i >= 0; $i--)
        {
            $days[date("Y-m-d", strtotime("-" . $i . " days"))] = 0;
        }

        $since = date("Y-m-d 00:00:00", strtotime("-6 days"));

        foreach(Database::all("SELECT CreatedAt FROM items WHERE CreatedAt >= ?", "s", [$since]) as $row)
        {
            $day = date("Y-m-d", strtotime($row["CreatedAt"]));

            if(isset($days[$day]))
            {
                $days[$day]++;
            }
        }

        return $days;
    }

    // ---- smart matching -------------------------------------------------

    // For a Lost report, look through active Found reports (and the other
    // way round) and keep the ones likely to be the same item.
    public static function matches($item, $limit = 6)
    {
        $opposite = $item["Type"] == "Lost" ? "Found" : "Lost";

        $candidates = Database::all(
            "SELECT items.*, users.Username
             FROM items
             JOIN users ON items.UserID = users.ID
             WHERE items.Type = ?
               AND items.Status = 'Active'
               AND items.UserID != ?
               AND items.ID != ?
               AND users.IsBanned = 0
               AND (items.Category = ? OR items.Division = ?)
             ORDER BY items.CreatedAt DESC
             LIMIT 300",
            "siiss",
            [$opposite, $item["UserID"], $item["ID"], $item["Category"], $item["Division"]]);

        $matches = [];

        foreach($candidates as $candidate)
        {
            $score = self::score($item, $candidate);

            if($score >= config("match_threshold"))
            {
                $candidate["Score"] = $score;
                $matches[] = $candidate;
            }
        }

        usort($matches, function ($a, $b) {
            return $b["Score"] - $a["Score"];
        });

        return array_slice($matches, 0, $limit);
    }

    // Scores two reports from 0 to 100.
    //   same category 35 · same division 15 · same district 15
    //   dates that make sense together up to 15 · shared words up to 30
    public static function score($a, $b)
    {
        $score = 0;

        if($a["Category"] == $b["Category"])
        {
            $score += 35;
        }

        if($a["Division"] == $b["Division"])
        {
            $score += 15;

            if(self::lower(trim($a["District"])) == self::lower(trim($b["District"])))
            {
                $score += 15;
            }
        }

        // An item can only be found on or after the day it was lost.
        $lost = $a["Type"] == "Lost" ? $a : $b;
        $found = $a["Type"] == "Lost" ? $b : $a;
        $days = (strtotime($found["EventDate"]) - strtotime($lost["EventDate"])) / 86400;

        if($days >= 0 && $days <= 3)
        {
            $score += 15;
        }
        else if($days > 3 && $days <= 14)
        {
            $score += 10;
        }
        else if($days > 14 && $days <= 45)
        {
            $score += 4;
        }
        else if($days < -2)
        {
            $score -= 15;
        }

        $name_a = self::words($a["ItemName"]);
        $name_b = self::words($b["ItemName"]);

        if(count(array_intersect($name_a, $name_b)) > 0)
        {
            $score += 20;
        }

        $all_a = array_unique(array_merge($name_a, self::words($a["Description"])));
        $all_b = array_unique(array_merge($name_b, self::words($b["Description"])));

        $score += min(10, count(array_intersect($all_a, $all_b)) * 4);

        return max(0, min(100, $score));
    }

    private static function lower($text)
    {
        return function_exists("mb_strtolower") ? mb_strtolower($text, "UTF-8") : strtolower($text);
    }

    // Splits text into meaningful lowercase words.
    private static function words($text)
    {
        $stop = ["the", "and", "with", "for", "from", "near", "was", "has", "have", "this", "that",
                 "lost", "found", "item", "its", "not", "but", "are", "had", "color", "colour"];

        $parts = preg_split('/[^\p{L}\p{N}]+/u', self::lower((string)$text), -1, PREG_SPLIT_NO_EMPTY);
        $words = [];

        foreach($parts ? $parts : [] as $part)
        {
            $length = function_exists("mb_strlen") ? mb_strlen($part, "UTF-8") : strlen($part);

            if($length >= 3 && !in_array($part, $stop))
            {
                $words[] = $part;
            }
        }

        return array_unique($words);
    }
}
