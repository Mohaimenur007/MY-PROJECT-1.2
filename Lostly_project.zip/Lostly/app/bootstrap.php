<?php

// Starts the framework: settings, class autoloading, session, security checks.

$GLOBALS["config"] = require(APP . "/config.php");

require(APP . "/core/helpers.php");

date_default_timezone_set(config("timezone"));

// Classes load themselves the first time they are used:
// core/Router.php, controllers/ItemController.php, models/Item.php ...
spl_autoload_register(function ($class) {
    foreach(["core", "controllers", "models"] as $folder)
    {
        $file = APP . "/" . $folder . "/" . $class . ".php";

        if(is_file($file))
        {
            require($file);
            return;
        }
    }
});

if(session_status() === PHP_SESSION_NONE)
{
    session_set_cookie_params([
        "lifetime" => 0,
        "path" => "/",
        "httponly" => true,
        "samesite" => "Lax"
    ]);
    session_start();
}

header("X-Frame-Options: SAMEORIGIN");
header("X-Content-Type-Options: nosniff");
header("Referrer-Policy: same-origin");

Database::connect(config("db"));

// Every POST on the site must carry the session's CSRF token.
Csrf::verify();

// Load the logged-in user (and end the session if they were suspended or deleted).
Auth::boot();
